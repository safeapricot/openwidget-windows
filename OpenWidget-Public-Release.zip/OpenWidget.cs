using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shell;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;
using System.Device.Location;

namespace OpenWidget
{
    // CoreAudio COM Interfaces for Native Windows Microphone Control
    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioEndpointVolume
    {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out int pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, ref Guid pguidEventContext);
        int SetMasterVolumeLevelScalar(float fLevel, ref Guid pguidEventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float pfLevel);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, ref Guid pguidEventContext);
        int GetMute(out bool pbMute);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice
    {
        int Activate(ref Guid id, int clsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
    }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(int dataFlow, int dwStateMask, out IntPtr ppDevices);
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppEndpoint);
    }

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    class MMDeviceEnumeratorComObject { }

    // Direct C-API Interop for NVIDIA Management Library (nvml.dll) - Zero Subprocess Overhead
    internal static class NvmlNative
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct nvmlUtilization_t
        {
            public uint gpu;
            public uint memory;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct nvmlMemory_t
        {
            public ulong total;
            public ulong free;
            public ulong used;
        }

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlInit_v2();

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlShutdown();

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlDeviceGetHandleByIndex_v2(uint index, out IntPtr device);

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlDeviceGetName(IntPtr device, StringBuilder name, uint length);

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlDeviceGetTemperature(IntPtr device, int sensorType, out uint temp);

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlDeviceGetUtilizationRates(IntPtr device, out nvmlUtilization_t util);

        [DllImport("nvml.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int nvmlDeviceGetMemoryInfo(IntPtr device, out nvmlMemory_t mem);
    }

    public class WirelessDeviceReading
    {
        public string IdKey;
        public string Icon;
        public string Name;
        public string Detail;
        public string PctText;
        public int BarPct;
    }

    // Universal Zero-Bloat Wireless Peripherals Detector & Battery Reader (HID, PnP Bluetooth/BLE, XInput, WinMM)
    internal static class WirelessBatteryNative
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct SP_DEVICE_INTERFACE_DATA
        {
            public int cbSize;
            public Guid InterfaceClassGuid;
            public int Flags;
            public IntPtr Reserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct SP_DEVINFO_DATA
        {
            public uint cbSize;
            public Guid ClassGuid;
            public uint DevInst;
            public IntPtr Reserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DEVPROPKEY
        {
            public Guid fmtid;
            public uint pid;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct NativeOverlapped
        {
            public IntPtr InternalLow;
            public IntPtr InternalHigh;
            public int OffsetLow;
            public int OffsetHigh;
            public IntPtr EventHandle;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct XINPUT_BATTERY_INFORMATION
        {
            public byte BatteryType;
            public byte BatteryLevel;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct XINPUT_STATE
        {
            public uint dwPacketNumber;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            public byte[] Gamepad;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct JOYINFOEX
        {
            public int dwSize;
            public int dwFlags;
            public int dwXpos;
            public int dwYpos;
            public int dwZpos;
            public int dwRpos;
            public int dwUpos;
            public int dwVpos;
            public int dwButtons;
            public int dwButtonNumber;
            public int dwPOV;
            public int dwReserved1;
            public int dwReserved2;
        }

        [DllImport("xinput1_4.dll")]
        public static extern uint XInputGetState(uint dwUserIndex, out XINPUT_STATE pState);

        [DllImport("xinput1_4.dll")]
        public static extern uint XInputGetBatteryInformation(uint dwUserIndex, byte devType, out XINPUT_BATTERY_INFORMATION pBatteryInformation);

        [DllImport("winmm.dll")]
        public static extern int joyGetNumDevs();

        [DllImport("winmm.dll")]
        public static extern int joyGetPosEx(int uJoyID, ref JOYINFOEX pji);

        [DllImport("hid.dll")]
        public static extern void HidD_GetHidGuid(out Guid hidGuid);

        [DllImport("hid.dll", CharSet = CharSet.Unicode)]
        public static extern bool HidD_GetProductString(IntPtr HidDeviceObject, StringBuilder Buffer, int BufferLength);

        [DllImport("setupapi.dll", SetLastError = true)]
        public static extern IntPtr SetupDiGetClassDevs(ref Guid ClassGuid, IntPtr Enumerator, IntPtr hwndParent, int Flags);

        [DllImport("setupapi.dll", EntryPoint = "SetupDiGetClassDevs", SetLastError = true)]
        public static extern IntPtr SetupDiGetClassDevsAll(IntPtr ClassGuid, IntPtr Enumerator, IntPtr hwndParent, uint Flags);

        [DllImport("setupapi.dll", SetLastError = true)]
        public static extern bool SetupDiEnumDeviceInterfaces(IntPtr DeviceInfoSet, IntPtr DeviceInfoData, ref Guid InterfaceClassGuid, int MemberIndex, ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);

        [DllImport("setupapi.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr DeviceInfoSet, ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData, IntPtr DeviceInterfaceDetailData, int DeviceInterfaceDetailDataSize, out int RequiredSize, IntPtr DeviceInfoData);

        [DllImport("setupapi.dll", SetLastError = true)]
        public static extern bool SetupDiEnumDeviceInfo(IntPtr DeviceInfoSet, uint MemberIndex, ref SP_DEVINFO_DATA DeviceInfoData);

        [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern bool SetupDiGetDevicePropertyW(IntPtr DeviceInfoSet, ref SP_DEVINFO_DATA DeviceInfoData, ref DEVPROPKEY PropertyKey, out uint PropertyType, byte[] PropertyBuffer, uint PropertyBufferSize, out uint RequiredSize, uint Flags);

        [DllImport("setupapi.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetupDiGetDeviceRegistryProperty(IntPtr DeviceInfoSet, ref SP_DEVINFO_DATA DeviceInfoData, uint Property, out uint PropertyRegDataType, StringBuilder PropertyBuffer, uint PropertyBufferSize, out uint RequiredSize);

        [DllImport("setupapi.dll")]
        public static extern bool SetupDiDestroyDeviceInfoList(IntPtr DeviceInfoSet);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, int dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool WriteFile(IntPtr hFile, IntPtr lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool ReadFile(IntPtr hFile, IntPtr lpBuffer, uint nNumberOfBytesToRead, out uint lpNumberOfBytesRead, IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool GetOverlappedResult(IntPtr hFile, IntPtr lpOverlapped, out uint lpNumberOfBytesTransferred, bool bWait);

        [DllImport("kernel32.dll")]
        public static extern IntPtr CreateEvent(IntPtr lpEventAttributes, bool bManualReset, bool bInitialState, string lpName);

        [DllImport("kernel32.dll")]
        public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

        [DllImport("kernel32.dll")]
        public static extern bool CancelIo(IntPtr hFile);

        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr hObject);

        public static bool OverlappedHidQuery(IntPtr hFile, byte[] tx, out byte[] rx, int len, uint timeoutMs)
        {
            rx = new byte[len];
            IntPtr evW = CreateEvent(IntPtr.Zero, true, false, null);
            IntPtr evR = CreateEvent(IntPtr.Zero, true, false, null);
            int ovSize = Marshal.SizeOf(typeof(NativeOverlapped));
            IntPtr pOvW = Marshal.AllocHGlobal(ovSize);
            IntPtr pOvR = Marshal.AllocHGlobal(ovSize);
            IntPtr pTx = Marshal.AllocHGlobal(len);
            IntPtr pRx = Marshal.AllocHGlobal(len);
            try
            {
                Marshal.Copy(tx, 0, pTx, len);
                for (int i = 0; i < len; i++) Marshal.WriteByte(pRx, i, 0);

                NativeOverlapped ovW = new NativeOverlapped { EventHandle = evW };
                Marshal.StructureToPtr(ovW, pOvW, false);
                uint wBytes;
                if (!WriteFile(hFile, pTx, (uint)len, out wBytes, pOvW))
                {
                    if (WaitForSingleObject(evW, timeoutMs) != 0)
                    {
                        CancelIo(hFile);
                        uint dummyW;
                        GetOverlappedResult(hFile, pOvW, out dummyW, true);
                        return false;
                    }
                }

                Thread.Sleep(20);

                NativeOverlapped ovR = new NativeOverlapped { EventHandle = evR };
                Marshal.StructureToPtr(ovR, pOvR, false);
                uint rBytes;
                if (ReadFile(hFile, pRx, (uint)len, out rBytes, pOvR))
                {
                    Marshal.Copy(pRx, rx, 0, len);
                    return rBytes > 0;
                }
                uint waitRes = WaitForSingleObject(evR, timeoutMs);
                if (waitRes == 0)
                {
                    uint transferred;
                    GetOverlappedResult(hFile, pOvR, out transferred, false);
                    Marshal.Copy(pRx, rx, 0, len);
                    return transferred > 0;
                }
                else
                {
                    CancelIo(hFile);
                    uint dummyR;
                    GetOverlappedResult(hFile, pOvR, out dummyR, true);
                    return false;
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                Marshal.FreeHGlobal(pTx);
                Marshal.FreeHGlobal(pRx);
                Marshal.FreeHGlobal(pOvW);
                Marshal.FreeHGlobal(pOvR);
                if (evW != IntPtr.Zero) CloseHandle(evW);
                if (evR != IntPtr.Zero) CloseHandle(evR);
            }
        }

        private static readonly Dictionary<string, string> usbProdNameCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public static string ReadUsbProductName(string hidPath, string fallback)
        {
            string cached;
            if (usbProdNameCache.TryGetValue(hidPath, out cached)) return cached;
            try
            {
                IntPtr h = CreateFile(hidPath, 0, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
                if (h != IntPtr.Zero && h != new IntPtr(-1))
                {
                    try
                    {
                        StringBuilder sb = new StringBuilder(128);
                        if (HidD_GetProductString(h, sb, 256))
                        {
                            string s = sb.ToString().Trim();
                            if (!string.IsNullOrEmpty(s))
                            {
                                usbProdNameCache[hidPath] = s;
                                return s;
                            }
                        }
                    }
                    finally
                    {
                        CloseHandle(h);
                    }
                }
            }
            catch { }
            return fallback;
        }

        public static void ClassifyDeviceTypeAndIcon(string rawName, string devClass, bool isEn, out string icon, out string typeLabel)
        {
            string lower = ((rawName ?? "") + " " + (devClass ?? "")).ToLowerInvariant();
            if (lower.Contains("keyboard") || lower.Contains("klavye") || lower.Contains("kbd") || lower.Contains("keychron") || lower.Contains("mx keys"))
            {
                icon = "⌨";
                typeLabel = isEn ? "Keyboard" : "Klavye";
            }
            else if (lower.Contains("headset") || lower.Contains("headphone") || lower.Contains("kulaklık") || lower.Contains("airpods") ||
                     lower.Contains("buds") || lower.Contains("cloud") || lower.Contains("arctis") || lower.Contains("nova") ||
                     lower.Contains("kraken") || lower.Contains("blackshark") || lower.Contains("barracuda") || lower.Contains("wh-1000") ||
                     lower.Contains("wf-1000") || lower.Contains("soundcore") || lower.Contains("jbl") || lower.Contains("audio"))
            {
                icon = "🎧";
                typeLabel = isEn ? "Headset" : "Kulaklık";
            }
            else if (lower.Contains("controller") || lower.Contains("gamepad") || lower.Contains("kumanda") || lower.Contains("xbox") ||
                     lower.Contains("dualshock") || lower.Contains("dualsense") || lower.Contains("8bitdo") || lower.Contains("gamesir") ||
                     lower.Contains("flydigi") || lower.Contains("joystick"))
            {
                icon = "🎮";
                typeLabel = isEn ? "Controller" : "Kumanda";
            }
            else
            {
                icon = "🖱";
                typeLabel = isEn ? "Mouse" : "Fare";
            }
        }

        public static List<WirelessDeviceReading> ScanActiveWirelessDevices(bool isEn, Dictionary<string, int> lastKnownPcts, Dictionary<string, string> lastKnownHz)
        {
            List<WirelessDeviceReading> results = new List<WirelessDeviceReading>();
            HashSet<string> addedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 1. Scan Direct USB HID Vendor Wireless Dongles (CompX 4K/8K Mice & Keyboards, HyperX Wireless Headsets)
            try
            {
                Guid hidGuid;
                HidD_GetHidGuid(out hidGuid);
                IntPtr hDevInfo = SetupDiGetClassDevs(ref hidGuid, IntPtr.Zero, IntPtr.Zero, 0x12);
                if (hDevInfo != IntPtr.Zero && hDevInfo != new IntPtr(-1))
                {
                    try
                    {
                        int index = 0;
                        SP_DEVICE_INTERFACE_DATA devData = new SP_DEVICE_INTERFACE_DATA();
                        devData.cbSize = Marshal.SizeOf(devData);
                        while (SetupDiEnumDeviceInterfaces(hDevInfo, IntPtr.Zero, ref hidGuid, index, ref devData))
                        {
                            int reqSize;
                            SetupDiGetDeviceInterfaceDetail(hDevInfo, ref devData, IntPtr.Zero, 0, out reqSize, IntPtr.Zero);
                            if (reqSize > 0)
                            {
                                IntPtr detailBuf = Marshal.AllocHGlobal(reqSize);
                                try
                                {
                                    Marshal.WriteInt32(detailBuf, IntPtr.Size == 8 ? 8 : 6);
                                    if (SetupDiGetDeviceInterfaceDetail(hDevInfo, ref devData, detailBuf, reqSize, out reqSize, IntPtr.Zero))
                                    {
                                        string p = Marshal.PtrToStringAuto(new IntPtr(detailBuf.ToInt64() + 4));
                                        if (p != null)
                                        {
                                            // A) CompX 4K/8K Wireless Mouse/Keyboard Protocol (VID_3554, Col05, Report 0x08)
                                            if (p.IndexOf("vid_3554&pid_f5", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                                p.IndexOf("&col05", StringComparison.OrdinalIgnoreCase) >= 0)
                                            {
                                                string rawProd = ReadUsbProductName(p, "Wireless Mouse");
                                                string cleanName = rawProd;
                                                if (p.IndexOf("pid_f5f7", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                                    rawProd.IndexOf("SCYROX", StringComparison.OrdinalIgnoreCase) >= 0)
                                                {
                                                    cleanName = "Scyrox V8";
                                                }
                                                else
                                                {
                                                    cleanName = Regex.Replace(rawProd, "(?i)\\s*(8k|4k|1k)?\\s*(wireless)?\\s*(dongle|receiver)", "").Trim();
                                                    if (string.IsNullOrEmpty(cleanName)) cleanName = rawProd;
                                                }

                                                string icon, typeLabel;
                                                ClassifyDeviceTypeAndIcon(cleanName, "Mouse", isEn, out icon, out typeLabel);

                                                IntPtr hDev = CreateFile(p, 0xC0000000U, 3, IntPtr.Zero, 3, 0x40000000U, IntPtr.Zero);
                                                if (hDev != IntPtr.Zero && hDev != new IntPtr(-1))
                                                {
                                                    try
                                                    {
                                                        string hzText = lastKnownHz.ContainsKey(p) ? lastKnownHz[p] : "1000 Hz";
                                                        byte[] txHz = new byte[17];
                                                        txHz[0] = 0x08; txHz[1] = 0x08; txHz[3] = 0x00; txHz[4] = 0x00; txHz[5] = 0x02; txHz[16] = 0x43;
                                                        byte[] rxHz;
                                                        if (OverlappedHidQuery(hDev, txHz, out rxHz, 17, 100) && rxHz[0] == 0x08 && rxHz[1] == 0x08)
                                                        {
                                                            byte rc = rxHz[6];
                                                            if (rc == 0x01) hzText = "1000 Hz";
                                                            else if (rc == 0x02) hzText = "500 Hz";
                                                            else if (rc == 0x04) hzText = "250 Hz";
                                                            else if (rc == 0x08) hzText = "125 Hz";
                                                            else if (rc == 0x10) hzText = "2000 Hz";
                                                            else if (rc == 0x20) hzText = "4000 Hz";
                                                            else if (rc == 0x40) hzText = "8000 Hz";
                                                            lastKnownHz[p] = hzText;
                                                        }

                                                        byte[] txBat = new byte[17];
                                                        txBat[0] = 0x08; txBat[1] = 0x04; txBat[16] = 0x49;
                                                        byte[] rxBat;
                                                        int pct = 0;
                                                        bool charging = false;
                                                        int mv = 0;
                                                        if (OverlappedHidQuery(hDev, txBat, out rxBat, 17, 120) && rxBat[0] == 0x08 && rxBat[1] == 0x04)
                                                        {
                                                            pct = rxBat[6];
                                                            charging = rxBat[7] == 1;
                                                            mv = (rxBat[8] << 8) | rxBat[9];
                                                        }

                                                        if (pct > 0 && pct <= 100)
                                                        {
                                                            lastKnownPcts[p] = pct;
                                                            string det = charging
                                                                ? (hzText + " • " + (isEn ? "⚡ Charging" : "⚡ Şarjda"))
                                                                : (mv > 3000 && mv < 4500 ? string.Format("{0} • {1:0.00}V", hzText, mv / 1000.0) : (hzText + " • " + typeLabel));
                                                            results.Add(new WirelessDeviceReading
                                                            {
                                                                IdKey = p,
                                                                Icon = icon,
                                                                Name = cleanName,
                                                                Detail = det,
                                                                PctText = isEn ? (pct + "%") : ("%" + pct),
                                                                BarPct = pct
                                                            });
                                                            addedNames.Add(cleanName);
                                                        }
                                                        else if (lastKnownPcts.ContainsKey(p) && lastKnownPcts[p] > 0)
                                                        {
                                                            int lastPct = lastKnownPcts[p];
                                                            results.Add(new WirelessDeviceReading
                                                            {
                                                                IdKey = p,
                                                                Icon = icon,
                                                                Name = cleanName,
                                                                Detail = hzText + " • " + (isEn ? "Sleep" : "Uyku"),
                                                                PctText = isEn ? (lastPct + "%") : ("%" + lastPct),
                                                                BarPct = lastPct
                                                            });
                                                            addedNames.Add(cleanName);
                                                        }
                                                    }
                                                    finally
                                                    {
                                                        CloseHandle(hDev);
                                                    }
                                                }
                                            }
                                            // B) HyperX / HP Wireless Headsets (VID_03F0 or VID_0951, MI_03 Col01, Report 0x66)
                                            else if ((p.IndexOf("vid_03f0&pid_05b7", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                                      p.IndexOf("vid_03f0&pid_09", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                                      p.IndexOf("vid_0951&pid_17", StringComparison.OrdinalIgnoreCase) >= 0) &&
                                                     p.IndexOf("&mi_03&col01", StringComparison.OrdinalIgnoreCase) >= 0)
                                            {
                                                string rawProd = ReadUsbProductName(p, "HyperX Wireless");
                                                string cleanName = Regex.Replace(rawProd, "(?i)\\s*wireless\\s*$", "").Trim();
                                                if (string.IsNullOrEmpty(cleanName)) cleanName = rawProd;

                                                IntPtr hHeadset = CreateFile(p, 0xC0000000U, 3, IntPtr.Zero, 3, 0x40000000U, IntPtr.Zero);
                                                if (hHeadset != IntPtr.Zero && hHeadset != new IntPtr(-1))
                                                {
                                                    try
                                                    {
                                                        byte[] tx = new byte[62];
                                                        tx[0] = 0x66; tx[1] = 0x89;
                                                        byte[] rx;
                                                        if (OverlappedHidQuery(hHeadset, tx, out rx, 62, 120) && rx[0] == 0x66 && rx[1] == 0x89)
                                                        {
                                                            int pct = (rx[4] > 0 && rx[4] <= 100) ? (int)rx[4] : ((rx[3] > 0 && rx[3] <= 100) ? (int)rx[3] : 0);
                                                            if (pct > 0)
                                                            {
                                                                bool isCharging = false;
                                                                byte[] txChg = new byte[62];
                                                                txChg[0] = 0x66; txChg[1] = 0x8A;
                                                                byte[] rxChg;
                                                                if (OverlappedHidQuery(hHeadset, txChg, out rxChg, 62, 100) && rxChg[0] == 0x66 && rxChg[1] == 0x8A)
                                                                {
                                                                    if (rxChg[4] == 1 || rxChg[3] == 1) isCharging = true;
                                                                }
                                                                results.Add(new WirelessDeviceReading
                                                                {
                                                                    IdKey = p,
                                                                    Icon = "🎧",
                                                                    Name = cleanName,
                                                                    Detail = isCharging ? (isEn ? "Headset • ⚡ Charging" : "Kulaklık • ⚡ Şarjda") : (isEn ? "Headset • 2.4GHz" : "Kulaklık • 2.4GHz"),
                                                                    PctText = isEn ? (pct + "%") : ("%" + pct),
                                                                    BarPct = pct
                                                                });
                                                                addedNames.Add(cleanName);
                                                            }
                                                        }
                                                    }
                                                    finally
                                                    {
                                                        CloseHandle(hHeadset);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                finally
                                {
                                    Marshal.FreeHGlobal(detailBuf);
                                }
                            }
                            index++;
                        }
                    }
                    finally
                    {
                        SetupDiDestroyDeviceInfoList(hDevInfo);
                    }
                }
            }
            catch { }

            // 2. Scan Windows Native PnP / Bluetooth / BLE Battery Service Devices (DEVPKEY_Device_BatteryLife)
            try
            {
                IntPtr hPnp = SetupDiGetClassDevsAll(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0x02 | 0x04);
                if (hPnp != IntPtr.Zero && hPnp != new IntPtr(-1))
                {
                    try
                    {
                        SP_DEVINFO_DATA devInfo = new SP_DEVINFO_DATA();
                        devInfo.cbSize = (uint)Marshal.SizeOf(typeof(SP_DEVINFO_DATA));
                        DEVPROPKEY batKey = new DEVPROPKEY { fmtid = new Guid("104EA319-6EE2-4701-BD47-8DDBF425BBE5"), pid = 2 };

                        uint idx = 0;
                        while (SetupDiEnumDeviceInfo(hPnp, idx, ref devInfo))
                        {
                            uint propType, reqSize;
                            byte[] buf = new byte[16];
                            if (SetupDiGetDevicePropertyW(hPnp, ref devInfo, ref batKey, out propType, buf, 16, out reqSize, 0))
                            {
                                int pct = buf[0];
                                if (pct > 0 && pct <= 100)
                                {
                                    StringBuilder sbName = new StringBuilder(256);
                                    uint regType, regReq;
                                    if (!SetupDiGetDeviceRegistryProperty(hPnp, ref devInfo, 0x0C, out regType, sbName, 256, out regReq) || sbName.Length == 0)
                                    {
                                        SetupDiGetDeviceRegistryProperty(hPnp, ref devInfo, 0x00, out regType, sbName, 256, out regReq);
                                    }
                                    StringBuilder sbClass = new StringBuilder(128);
                                    SetupDiGetDeviceRegistryProperty(hPnp, ref devInfo, 0x07, out regType, sbClass, 128, out regReq);

                                    string devName = sbName.ToString().Trim();
                                    string devClass = sbClass.ToString().Trim();
                                    if (!string.IsNullOrEmpty(devName) && !addedNames.Contains(devName))
                                    {
                                        string icon, typeLabel;
                                        ClassifyDeviceTypeAndIcon(devName, devClass, isEn, out icon, out typeLabel);
                                        results.Add(new WirelessDeviceReading
                                        {
                                            IdKey = "PNP_" + devName,
                                            Icon = icon,
                                            Name = devName,
                                            Detail = typeLabel + " • Bluetooth",
                                            PctText = isEn ? (pct + "%") : ("%" + pct),
                                            BarPct = pct
                                        });
                                        addedNames.Add(devName);
                                    }
                                }
                            }
                            idx++;
                        }
                    }
                    finally
                    {
                        SetupDiDestroyDeviceInfoList(hPnp);
                    }
                }
            }
            catch { }

            // 3. Scan XInput & DirectInput Wireless Controllers (Gamepads)
            bool hasControllerAlready = false;
            foreach (WirelessDeviceReading r in results)
            {
                if (r.Icon == "🎮") { hasControllerAlready = true; break; }
            }

            if (!hasControllerAlready)
            {
                bool padConnected = false;
                string padDetail = "";
                string padPctText = "";
                int padBarPct = 0;

                try
                {
                    for (uint i = 0; i < 4; i++)
                    {
                        XINPUT_STATE st;
                        if (XInputGetState(i, out st) == 0)
                        {
                            padConnected = true;
                            XINPUT_BATTERY_INFORMATION bat;
                            if (XInputGetBatteryInformation(i, 0, out bat) == 0)
                            {
                                if (bat.BatteryType == 1)
                                {
                                    padBarPct = 100;
                                    padPctText = isEn ? "100%" : "%100";
                                    padDetail = isEn ? "Controller • Wired" : "Kumanda • Kablolu";
                                }
                                else if (bat.BatteryType == 2 || bat.BatteryType == 3)
                                {
                                    if (bat.BatteryLevel == 3) { padBarPct = 100; padPctText = isEn ? "100%" : "%100"; padDetail = isEn ? "Controller • Full" : "Kumanda • Tam Dolu"; }
                                    else if (bat.BatteryLevel == 2) { padBarPct = 65; padPctText = isEn ? "65%" : "%65"; padDetail = isEn ? "Controller • Good" : "Kumanda • İyi Seviye"; }
                                    else if (bat.BatteryLevel == 1) { padBarPct = 30; padPctText = isEn ? "30%" : "%30"; padDetail = isEn ? "Controller • Low" : "Kumanda • Düşük Pil"; }
                                    else { padBarPct = 10; padPctText = isEn ? "10%" : "%10"; padDetail = isEn ? "Controller • Critical" : "Kumanda • Çok Düşük!"; }
                                }
                                else
                                {
                                    padBarPct = 100;
                                    padPctText = isEn ? "Active" : "Açık";
                                    padDetail = isEn ? "Controller • Connected" : "Kumanda • Bağlı";
                                }
                            }
                            break;
                        }
                    }
                }
                catch { }

                if (!padConnected)
                {
                    try
                    {
                        int numDevs = Math.Min(16, joyGetNumDevs());
                        for (int i = 0; i < numDevs; i++)
                        {
                            JOYINFOEX ji = new JOYINFOEX();
                            ji.dwSize = Marshal.SizeOf(typeof(JOYINFOEX));
                            ji.dwFlags = 0xFF;
                            if (joyGetPosEx(i, ref ji) == 0)
                            {
                                padConnected = true;
                                padBarPct = 100;
                                padPctText = isEn ? "Active" : "Açık";
                                padDetail = isEn ? "Controller • Wireless" : "Kumanda • Kablosuz";
                                break;
                            }
                        }
                    }
                    catch { }
                }

                if (padConnected && padBarPct > 0)
                {
                    results.Add(new WirelessDeviceReading
                    {
                        IdKey = "GAMEPAD_0",
                        Icon = "🎮",
                        Name = isEn ? "Wireless Controller" : "Kablosuz Kumanda",
                        Detail = padDetail,
                        PctText = padPctText,
                        BarPct = padBarPct
                    });
                }
            }

            return results;
        }
    }

    public class ClipboardEntry
    {
        public string Text { get; set; }
        public string Time { get; set; }
    }

    public class GeoLookupResult
    {
        public bool Success;
        public string DisplayName;
        public double Latitude;
        public double Longitude;
    }

    public static class LocationHelper
    {
        public static GeoLookupResult ResolveAutoLocation(string lang = "TR")
        {
            bool isEn = string.Equals(lang, "EN", StringComparison.OrdinalIgnoreCase);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            // 1. Try Windows Native GeoCoordinateWatcher (GPS / Wi-Fi Location Services) briefly
            try
            {
                using (GeoCoordinateWatcher watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.Default))
                {
                    watcher.TryStart(false, TimeSpan.FromMilliseconds(1200));
                    DateTime waitUntil = DateTime.Now.AddMilliseconds(1200);
                    while (watcher.Position.Location.IsUnknown && DateTime.Now < waitUntil)
                    {
                        Thread.Sleep(100);
                    }
                    if (!watcher.Position.Location.IsUnknown)
                    {
                        double lat = watcher.Position.Location.Latitude;
                        double lon = watcher.Position.Location.Longitude;
                        watcher.Stop();
                        return new GeoLookupResult
                        {
                            Success = true,
                            DisplayName = isEn ? "GPS Location" : "GPS Konumu",
                            Latitude = lat,
                            Longitude = lon
                        };
                    }
                    watcher.Stop();
                }
            }
            catch { }

            // 2. Fallback to fast IP Geolocation
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://ip-api.com/json/?fields=status,city,regionName,lat,lon");
                req.Timeout = 4500;
                req.UserAgent = "OpenWidgetSetup/1.0";
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                {
                    string json = reader.ReadToEnd();
                    if (json.Contains("\"status\":\"success\""))
                    {
                        string city = ExtractString(json, "city", isEn ? "Auto Location" : "Otomatik Konum");
                        double lat = ExtractDouble(json, "lat", 39.9208);
                        double lon = ExtractDouble(json, "lon", 32.8541);
                        return new GeoLookupResult
                        {
                            Success = true,
                            DisplayName = city,
                            Latitude = lat,
                            Longitude = lon
                        };
                    }
                }
            }
            catch { }

            return new GeoLookupResult { Success = false, DisplayName = isEn ? "Istanbul" : "İstanbul", Latitude = 41.0082, Longitude = 28.9784 };
        }

        public static GeoLookupResult SearchCityByName(string query, string lang = "TR")
        {
            if (string.IsNullOrWhiteSpace(query))
                return new GeoLookupResult { Success = false };

            bool isEn = string.Equals(lang, "EN", StringComparison.OrdinalIgnoreCase);

            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string cleanQuery = query.Trim();
                // If user typed "İl / İlçe" like "Kütahya / Merkez" or "İstanbul / Kadıköy", search the most specific part or city
                string searchPart = cleanQuery;
                if (cleanQuery.Contains("/"))
                {
                    string[] split = cleanQuery.Split('/');
                    string p0 = split[0].Trim();
                    string p1 = split[1].Trim();
                    searchPart = (p1.Equals("Merkez", StringComparison.OrdinalIgnoreCase) || string.IsNullOrEmpty(p1)) ? p0 : p1;
                }

                string apiLang = isEn ? "en" : "tr";
                string url = "https://geocoding-api.open-meteo.com/v1/search?name=" + Uri.EscapeDataString(searchPart) + "&count=1&language=" + apiLang + "&format=json";
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Timeout = 5000;
                req.UserAgent = "OpenWidgetSetup/1.0";

                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                {
                    string json = reader.ReadToEnd();
                    if (json.Contains("\"results\":"))
                    {
                        string name = ExtractString(json, "name", searchPart);
                        string admin1 = ExtractString(json, "admin1", "");
                        double lat = ExtractDouble(json, "latitude", 41.0082);
                        double lon = ExtractDouble(json, "longitude", 28.9784);

                        string label = cleanQuery.Contains("/")
                            ? cleanQuery
                            : (!string.IsNullOrEmpty(admin1) && !admin1.Equals(name, StringComparison.OrdinalIgnoreCase) ? admin1 + " / " + name : name);

                        return new GeoLookupResult
                        {
                            Success = true,
                            DisplayName = label,
                            Latitude = lat,
                            Longitude = lon
                        };
                    }
                }
            }
            catch { }

            return new GeoLookupResult { Success = false };
        }

        private static string ExtractString(string json, string key, string fallback)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\"([^\"]+)\"");
            return m.Success ? m.Groups[1].Value : fallback;
        }

        private static double ExtractDouble(string json, string key, double fallback)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*(-?\\d+(\\.\\d+)?)");
            if (m.Success)
            {
                double v;
                if (double.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out v))
                    return v;
            }
            return fallback;
        }
    }

    public class Program
    {
        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        [DllImport("shcore.dll")]
        private static extern int SetProcessDpiAwareness(int value);

        private static ImageSource cachedWindowIcon;
        public static void TryApplyWindowIcon(Window w)
        {
            try
            {
                if (cachedWindowIcon == null)
                {
                    string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    using (System.Drawing.Icon ico = System.Drawing.Icon.ExtractAssociatedIcon(exePath))
                    {
                        if (ico != null)
                        {
                            ImageSource img = Imaging.CreateBitmapSourceFromHIcon(ico.Handle, Int32Rect.Empty, System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());
                            img.Freeze();
                            cachedWindowIcon = img;
                        }
                    }
                }
                if (cachedWindowIcon != null) w.Icon = cachedWindowIcon;
            }
            catch { }
        }

        public static void ApplyThinScrollBarStyle(ScrollViewer sv, string accentHex)
        {
            if (sv == null) return;
            try
            {
                string thumbHex = string.IsNullOrEmpty(accentHex) ? "#E2925C" : accentHex;
                string xaml = string.Format(@"
<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
       xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
       TargetType='{{x:Type ScrollBar}}'>
    <Setter Property='Width' Value='5'/>
    <Setter Property='MinWidth' Value='5'/>
    <Setter Property='Margin' Value='2,2,0,2'/>
    <Setter Property='Background' Value='Transparent'/>
    <Setter Property='Template'>
        <Setter.Value>
            <ControlTemplate TargetType='{{x:Type ScrollBar}}'>
                <Border Background='#261A1411' CornerRadius='2.5' Width='5'>
                    <Track x:Name='PART_Track' IsDirectionReversed='True'>
                        <Track.DecreaseRepeatButton>
                            <RepeatButton Command='ScrollBar.PageUpCommand' Opacity='0' Focusable='False'/>
                        </Track.DecreaseRepeatButton>
                        <Track.IncreaseRepeatButton>
                            <RepeatButton Command='ScrollBar.PageDownCommand' Opacity='0' Focusable='False'/>
                        </Track.IncreaseRepeatButton>
                        <Track.Thumb>
                            <Thumb Cursor='Hand'>
                                <Thumb.Template>
                                    <ControlTemplate TargetType='{{x:Type Thumb}}'>
                                        <Border CornerRadius='2.5' Background='{0}' Opacity='0.85'/>
                                    </ControlTemplate>
                                </Thumb.Template>
                            </Thumb>
                        </Track.Thumb>
                    </Track>
                </Border>
            </ControlTemplate>
        </Setter.Value>
    </Setter>
</Style>", thumbHex);
                Style sbStyle = (Style)System.Windows.Markup.XamlReader.Parse(xaml);
                sv.Resources[typeof(ScrollBar)] = sbStyle;
            }
            catch { }
        }

        [STAThread]
        public static void Main(string[] args)
        {
            // Multi-core background JIT profile for faster cold-boot launches
            try
            {
                System.Runtime.ProfileOptimization.SetProfileRoot(AppDomain.CurrentDomain.BaseDirectory);
                System.Runtime.ProfileOptimization.StartProfile("OpenWidget.jit.profile");
            }
            catch { }

            try { SetProcessDpiAwareness(2); }
            catch { try { SetProcessDPIAware(); } catch { } }

            bool forceSetup = false;
            if (args != null)
            {
                foreach (string a in args)
                {
                    if (a.Equals("--setup", StringComparison.OrdinalIgnoreCase) || a.Equals("/setup", StringComparison.OrdinalIgnoreCase))
                        forceSetup = true;
                }
            }

            string cfgPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "settings.cfg");
            Application app = new Application();

            if (forceSetup || !File.Exists(cfgPath))
            {
                SetupWizardWindow wizard = new SetupWizardWindow(cfgPath);
                bool? res = wizard.ShowDialog();
                if (res != true && !File.Exists(cfgPath))
                {
                    return;
                }
            }

            bool createdNew;
            using (Mutex mutex = new Mutex(true, "OpenWidget_Public_Edition_Mutex", out createdNew))
            {
                if (!createdNew)
                {
                    return;
                }
                MainWindow win = new MainWindow();
                app.Run(win);
            }
        }
    }

    // ========================================================
    // INTERACTIVE SETUP WIZARD (KURULUM YARDIMCISI - TR / EN)
    // ========================================================
    public class SetupWizardWindow : Window
    {
        private string configFilePath;
        private string selectedLanguage = "TR";
        private Button btnLangTr;
        private Button btnLangEn;
        private TextBlock txtWizTitle;
        private TextBlock txtWizSubtitle;
        private TextBlock txtStepLang;
        private TextBlock txtStep1;
        private TextBlock txtStep2;
        private TextBlock txtStep3;
        private TextBlock txtStep4;
        private RadioButton rbAutoGps;
        private RadioButton rbManualCity;
        private TextBox txtCityInput;
        private Button btnTestCity;
        private TextBlock txtStatusFeedback;
        private Button btnCustomWizardColor;
        private CheckBox chkWizardCalendar;
        private CheckBox chkWizardTimer;
        private CheckBox chkDesktopShortcut;
        private CheckBox chkStartupRun;
        private string selectedAccent = "#E2925C";
        private GeoLookupResult resolvedLocation;
        private Button btnFinish;

        public SetupWizardWindow(string cfgPath)
        {
            this.configFilePath = cfgPath;
            this.Title = "OpenWidget Setup / Kurulum Yardımcısı";
            this.Width = 480;
            this.Height = Math.Max(480, Math.Min(650, SystemParameters.WorkArea.Height - 40));
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            this.WindowStyle = WindowStyle.None;
            this.AllowsTransparency = true;
            this.Background = Brushes.Transparent;
            this.ResizeMode = ResizeMode.NoResize;
            this.UseLayoutRounding = true;
            this.SnapsToDevicePixels = true;
            this.FontFamily = new FontFamily("Segoe UI");
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
            TextOptions.SetTextRenderingMode(this, TextRenderingMode.ClearType);
            Program.TryApplyWindowIcon(this);

            BuildWizardUi();
        }

        private bool IsEn
        {
            get { return string.Equals(selectedLanguage, "EN", StringComparison.OrdinalIgnoreCase); }
        }

        private Brush HexBrush(string hex)
        {
            return (SolidColorBrush)new BrushConverter().ConvertFromString(hex);
        }

        private void BuildWizardUi()
        {
            Border card = new Border
            {
                CornerRadius = new CornerRadius(16),
                Background = HexBrush("#F71B1714"),
                BorderBrush = HexBrush("#E2925C"),
                BorderThickness = new Thickness(1.5),
                Padding = new Thickness(22, 16, 22, 18),
                Margin = new Thickness(10)
            };
            card.Effect = new DropShadowEffect { Color = Colors.Black, BlurRadius = 18, Opacity = 0.7 };

            Grid rootGrid = new Grid();
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Header
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Scrollable steps
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // Finish footer

            // Row 0: Draggable Header
            Grid hdr = new Grid { Margin = new Thickness(0, 0, 0, 10), Background = Brushes.Transparent, Cursor = Cursors.SizeAll };
            hdr.MouseLeftButtonDown += (s, e) =>
            {
                if (e.ButtonState == MouseButtonState.Pressed)
                {
                    try { this.DragMove(); } catch { }
                }
            };
            hdr.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdr.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel titleStack = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };
            txtWizTitle = new TextBlock { Text = "✨ OpenWidget Kurulum Yardımcısı", Foreground = HexBrush("#FAF6F2"), FontSize = 16.5, FontWeight = FontWeights.Bold };
            txtWizSubtitle = new TextBlock { Text = "Masaüstü widget'ınızı kullanmaya başlamadan önce tercihlerinizi seçin.", Foreground = HexBrush("#B8A99E"), FontSize = 11.5, Margin = new Thickness(0, 3, 0, 0), TextWrapping = TextWrapping.Wrap };
            titleStack.Children.Add(txtWizTitle);
            titleStack.Children.Add(txtWizSubtitle);
            Grid.SetColumn(titleStack, 0);
            hdr.Children.Add(titleStack);

            Button btnClose = new Button
            {
                Content = "✕",
                Foreground = HexBrush("#B8A99E"),
                Background = Brushes.Transparent,
                BorderThickness = new Thickness(0),
                FontSize = 13,
                Cursor = Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Top
            };
            btnClose.Click += (s, e) => { this.DialogResult = false; this.Close(); };
            Grid.SetColumn(btnClose, 1);
            hdr.Children.Add(btnClose);
            Grid.SetRow(hdr, 0);
            rootGrid.Children.Add(hdr);

            // Row 1: Smooth ScrollViewer containing Setup Steps
            ScrollViewer wizScroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                PanningMode = PanningMode.VerticalOnly,
                Margin = new Thickness(0, 0, 0, 12)
            };
            Program.ApplyThinScrollBarStyle(wizScroll, selectedAccent);
            StackPanel root = new StackPanel { Margin = new Thickness(0, 0, 4, 0) };
            wizScroll.Content = root;
            Grid.SetRow(wizScroll, 1);
            rootGrid.Children.Add(wizScroll);

            root.Children.Add(new Border { Height = 1, Background = HexBrush("#362C26"), Margin = new Thickness(0, 0, 0, 12) });

            // Language Selection Row (TR / EN)
            Grid langRow = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            langRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            langRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            langRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtStepLang = new TextBlock
            {
                Text = "🌐 Arayüz Dili / Language",
                Foreground = HexBrush("#E2925C"),
                FontSize = 12.5,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(txtStepLang, 0);
            langRow.Children.Add(txtStepLang);

            btnLangTr = new Button
            {
                Content = "🇹🇷 Türkçe",
                Background = HexBrush("#38281E"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#E2925C"),
                BorderThickness = new Thickness(1.5),
                Padding = new Thickness(12, 5, 12, 5),
                Margin = new Thickness(0, 0, 6, 0),
                Cursor = Cursors.Hand,
                FontSize = 11.5,
                FontWeight = FontWeights.SemiBold
            };
            btnLangTr.Click += (s, e) => SetWizardLanguage("TR");
            Grid.SetColumn(btnLangTr, 1);
            langRow.Children.Add(btnLangTr);

            btnLangEn = new Button
            {
                Content = "🇬🇧 English",
                Background = HexBrush("#26201C"),
                Foreground = HexBrush("#B8A99E"),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(12, 5, 12, 5),
                Cursor = Cursors.Hand,
                FontSize = 11.5,
                FontWeight = FontWeights.SemiBold
            };
            btnLangEn.Click += (s, e) => SetWizardLanguage("EN");
            Grid.SetColumn(btnLangEn, 2);
            langRow.Children.Add(btnLangEn);
            root.Children.Add(langRow);

            // Step 1: Weather Location Choice
            txtStep1 = new TextBlock { Text = "1. Hava Durumu Konumu Nasıl Belirlensin?", Foreground = HexBrush("#E2925C"), FontSize = 13, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 8) };
            root.Children.Add(txtStep1);

            Border locBox = new Border
            {
                CornerRadius = new CornerRadius(10),
                Background = HexBrush("#26201C"),
                BorderBrush = HexBrush("#3D322C"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(12, 10, 12, 10),
                Margin = new Thickness(0, 0, 0, 12)
            };
            StackPanel locStack = new StackPanel();

            rbAutoGps = new RadioButton
            {
                Content = "📍 Otomatik Algıla (GPS / Konum Servisi ile bul)",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12,
                FontWeight = FontWeights.Medium,
                IsChecked = true,
                Margin = new Thickness(0, 2, 0, 8),
                Cursor = Cursors.Hand
            };

            rbManualCity = new RadioButton
            {
                Content = "🏙 Sabit İl / İlçe Yazarak Belirle (Örn: İstanbul, Ankara, Kütahya / Merkez)",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12,
                FontWeight = FontWeights.Medium,
                Margin = new Thickness(0, 0, 0, 8),
                Cursor = Cursors.Hand
            };

            Grid manualInputGrid = new Grid { Margin = new Thickness(20, 0, 0, 4), IsEnabled = false, Opacity = 0.5 };
            manualInputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            manualInputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtCityInput = new TextBox
            {
                Text = "İstanbul / Kadıköy",
                Background = HexBrush("#1C1714"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 5, 8, 5),
                FontSize = 12
            };
            Grid.SetColumn(txtCityInput, 0);
            manualInputGrid.Children.Add(txtCityInput);

            btnTestCity = new Button
            {
                Content = "Doğrula",
                Background = HexBrush("#38281E"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#E2925C"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(10, 5, 10, 5),
                Margin = new Thickness(6, 0, 0, 0),
                Cursor = Cursors.Hand,
                FontSize = 11.5
            };
            btnTestCity.Click += (s, e) => VerifyLocationAsync();
            Grid.SetColumn(btnTestCity, 1);
            manualInputGrid.Children.Add(btnTestCity);

            rbAutoGps.Checked += (s, e) =>
            {
                if (manualInputGrid != null) { manualInputGrid.IsEnabled = false; manualInputGrid.Opacity = 0.5; }
                VerifyLocationAsync();
            };
            rbManualCity.Checked += (s, e) =>
            {
                if (manualInputGrid != null) { manualInputGrid.IsEnabled = true; manualInputGrid.Opacity = 1.0; txtCityInput.Focus(); }
            };

            txtStatusFeedback = new TextBlock
            {
                Text = "Konum algılanıyor...",
                Foreground = HexBrush("#34D399"),
                FontSize = 11,
                Margin = new Thickness(2, 4, 0, 0)
            };

            locStack.Children.Add(rbAutoGps);
            locStack.Children.Add(rbManualCity);
            locStack.Children.Add(manualInputGrid);
            locStack.Children.Add(txtStatusFeedback);
            locBox.Child = locStack;
            root.Children.Add(locBox);

            // Step 2: Theme Color
            txtStep2 = new TextBlock { Text = "2. Başlangıç Tema Rengi", Foreground = HexBrush("#E2925C"), FontSize = 13, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 8) };
            root.Children.Add(txtStep2);
            string[] presets = { "#E2925C", "#D97706", "#10B981", "#38BDF8", "#A78BFA", "#F43F5E" };
            Grid themeSelectRow = new Grid { Margin = new Thickness(0, 0, 0, 14) };
            themeSelectRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            themeSelectRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            UniformGrid swatchGrid = new UniformGrid { Columns = 6 };
            List<Border> swatchBorders = new List<Border>();
            for (int i = 0; i < presets.Length; i++)
            {
                string hex = presets[i];
                Border sw = new Border
                {
                    Width = 30,
                    Height = 30,
                    CornerRadius = new CornerRadius(15),
                    Background = HexBrush(hex),
                    BorderBrush = Brushes.White,
                    BorderThickness = new Thickness(i == 0 ? 2.5 : 0.5),
                    Cursor = Cursors.Hand
                };
                swatchBorders.Add(sw);
                sw.MouseLeftButtonDown += (s, e) =>
                {
                    selectedAccent = hex;
                    foreach (Border b in swatchBorders) b.BorderThickness = new Thickness(0.5);
                    sw.BorderThickness = new Thickness(2.5);
                    card.BorderBrush = HexBrush(hex);
                    if (btnFinish != null) btnFinish.Background = HexBrush(hex);
                    Program.ApplyThinScrollBarStyle(wizScroll, selectedAccent);
                };
                swatchGrid.Children.Add(sw);
            }
            Grid.SetColumn(swatchGrid, 0);
            themeSelectRow.Children.Add(swatchGrid);

            btnCustomWizardColor = new Button
            {
                Content = "🎨 Özel Renk Seç...",
                Background = HexBrush("#2A221E"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(10, 5, 10, 5),
                Margin = new Thickness(8, 0, 0, 0),
                Cursor = Cursors.Hand,
                FontSize = 11.5
            };
            btnCustomWizardColor.Click += (s, e) =>
            {
                Color cur = (Color)ColorConverter.ConvertFromString(selectedAccent);
                using (var dlg = new System.Windows.Forms.ColorDialog())
                {
                    dlg.FullOpen = true;
                    dlg.AnyColor = true;
                    dlg.Color = System.Drawing.Color.FromArgb(cur.R, cur.G, cur.B);
                    if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        selectedAccent = string.Format("#{0:X2}{1:X2}{2:X2}", dlg.Color.R, dlg.Color.G, dlg.Color.B);
                        foreach (Border b in swatchBorders) b.BorderThickness = new Thickness(0.5);
                        card.BorderBrush = HexBrush(selectedAccent);
                        if (btnFinish != null) btnFinish.Background = HexBrush(selectedAccent);
                        Program.ApplyThinScrollBarStyle(wizScroll, selectedAccent);
                    }
                }
            };
            Grid.SetColumn(btnCustomWizardColor, 1);
            themeSelectRow.Children.Add(btnCustomWizardColor);
            root.Children.Add(themeSelectRow);

            // Step 3: Companion Desktop Widgets (Optional, Default Off)
            txtStep3 = new TextBlock { Text = "3. Ek Masaüstü Widget'ları (İsteğe Bağlı)", Foreground = HexBrush("#E2925C"), FontSize = 13, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 8) };
            root.Children.Add(txtStep3);

            Border compBox = new Border
            {
                CornerRadius = new CornerRadius(10),
                Background = HexBrush("#26201C"),
                BorderBrush = HexBrush("#3D322C"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(12, 9, 12, 9),
                Margin = new Thickness(0, 0, 0, 12)
            };
            StackPanel compStack = new StackPanel();
            chkWizardCalendar = new CheckBox
            {
                Content = "📅 Google Takvim Widget'ını Aç (Aylık takvim, iCal & etkinlikler)",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 11.5,
                IsChecked = false,
                Margin = new Thickness(0, 0, 0, 6),
                Cursor = Cursors.Hand
            };
            chkWizardTimer = new CheckBox
            {
                Content = "⏱ Timer Widgeti'ni Aç (Zamanlayıcı, Oyun Modu, Pomodoro & Yıllık Aktivite)",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 11.5,
                IsChecked = false,
                Cursor = Cursors.Hand
            };
            compStack.Children.Add(chkWizardCalendar);
            compStack.Children.Add(chkWizardTimer);
            compBox.Child = compStack;
            root.Children.Add(compBox);

            // Step 4: System Integration Options
            txtStep4 = new TextBlock { Text = "4. Sistem ve Kısayol Seçenekleri", Foreground = HexBrush("#E2925C"), FontSize = 13, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 8) };
            root.Children.Add(txtStep4);

            chkDesktopShortcut = new CheckBox
            {
                Content = "Masaüstüne OpenWidget kısayolu oluştur",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12,
                IsChecked = true,
                Margin = new Thickness(0, 0, 0, 6),
                Cursor = Cursors.Hand
            };
            chkStartupRun = new CheckBox
            {
                Content = "Bilgisayar açıldığında otomatik olarak başlat (Önerilen)",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12,
                IsChecked = true,
                Margin = new Thickness(0, 0, 0, 4),
                Cursor = Cursors.Hand
            };
            root.Children.Add(chkDesktopShortcut);
            root.Children.Add(chkStartupRun);

            // Row 2: Sticky Finish Button Footer
            btnFinish = new Button
            {
                Content = "🚀 Kurulumu Tamamla ve OpenWidget'ı Başlat",
                Background = HexBrush("#E2925C"),
                Foreground = HexBrush("#181310"),
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                Padding = new Thickness(14, 10, 14, 10),
                BorderThickness = new Thickness(0),
                Cursor = Cursors.Hand
            };
            btnFinish.Click += BtnFinish_Click;
            Grid.SetRow(btnFinish, 2);
            rootGrid.Children.Add(btnFinish);

            card.Child = rootGrid;
            this.Content = card;

            VerifyLocationAsync();
        }

        private void SetWizardLanguage(string lang)
        {
            selectedLanguage = lang;
            bool en = IsEn;

            btnLangTr.Background = HexBrush(en ? "#26201C" : "#38281E");
            btnLangTr.Foreground = HexBrush(en ? "#B8A99E" : "#FAF6F2");
            btnLangTr.BorderBrush = HexBrush(en ? "#4A3C34" : "#E2925C");
            btnLangTr.BorderThickness = new Thickness(en ? 1 : 1.5);

            btnLangEn.Background = HexBrush(en ? "#38281E" : "#26201C");
            btnLangEn.Foreground = HexBrush(en ? "#FAF6F2" : "#B8A99E");
            btnLangEn.BorderBrush = HexBrush(en ? "#E2925C" : "#4A3C34");
            btnLangEn.BorderThickness = new Thickness(en ? 1.5 : 1);

            txtWizTitle.Text = en ? "✨ OpenWidget Setup Wizard" : "✨ OpenWidget Kurulum Yardımcısı";
            txtWizSubtitle.Text = en
                ? "Choose your preferences before launching your desktop widget."
                : "Masaüstü widget'ınızı kullanmaya başlamadan önce tercihlerinizi seçin.";
            txtStepLang.Text = en ? "🌐 Interface Language / Dil" : "🌐 Arayüz Dili / Language";
            txtStep1.Text = en ? "1. How Should Weather Location Be Determined?" : "1. Hava Durumu Konumu Nasıl Belirlensin?";
            rbAutoGps.Content = en
                ? "📍 Auto-Detect (Find via GPS / Location Services)"
                : "📍 Otomatik Algıla (GPS / Konum Servisi ile bul)";
            rbManualCity.Content = en
                ? "🏙 Enter City / District Manually (e.g., London, New York, Istanbul)"
                : "🏙 Sabit İl / İlçe Yazarak Belirle (Örn: İstanbul, Ankara, Kütahya / Merkez)";
            btnTestCity.Content = en ? "Verify" : "Doğrula";
            txtStep2.Text = en ? "2. Initial Theme Accent Color" : "2. Başlangıç Tema Rengi";
            btnCustomWizardColor.Content = en ? "🎨 Custom Color..." : "🎨 Özel Renk Seç...";
            txtStep3.Text = en ? "3. Companion Desktop Widgets (Optional)" : "3. Ek Masaüstü Widget'ları (İsteğe Bağlı)";
            chkWizardCalendar.Content = en
                ? "📅 Enable Calendar Widget (Monthly view, iCal sync & events)"
                : "📅 Google Takvim Widget'ını Aç (Aylık takvim, iCal & etkinlikler)";
            chkWizardTimer.Content = en
                ? "⏱ Enable Timer Widget (Stopwatch, Auto Game Mode, Pomodoro & Heatmap)"
                : "⏱ Timer Widgeti'ni Aç (Zamanlayıcı, Oyun Modu, Pomodoro & Yıllık Aktivite)";
            txtStep4.Text = en ? "4. System & Shortcut Options" : "4. Sistem ve Kısayol Seçenekleri";
            chkDesktopShortcut.Content = en
                ? "Create OpenWidget shortcut on Desktop"
                : "Masaüstüne OpenWidget kısayolu oluştur";
            chkStartupRun.Content = en
                ? "Launch automatically when Windows starts (Recommended)"
                : "Bilgisayar açıldığında otomatik olarak başlat (Önerilen)";
            btnFinish.Content = en
                ? "🚀 Complete Setup & Launch OpenWidget"
                : "🚀 Kurulumu Tamamla ve OpenWidget'ı Başlat";

            if (resolvedLocation != null && resolvedLocation.Success)
            {
                txtStatusFeedback.Text = en
                    ? string.Format("✓ Selected Location: {0} ({1:0.00}, {2:0.00})", resolvedLocation.DisplayName, resolvedLocation.Latitude, resolvedLocation.Longitude)
                    : string.Format("✓ Seçilen Konum: {0} ({1:0.00}, {2:0.00})", resolvedLocation.DisplayName, resolvedLocation.Latitude, resolvedLocation.Longitude);
            }
        }

        private void VerifyLocationAsync()
        {
            bool isAuto = rbAutoGps.IsChecked == true;
            string manualQuery = txtCityInput.Text.Trim();
            bool en = IsEn;
            txtStatusFeedback.Text = en ? "⏳ Checking location coordinates..." : "⏳ Konum koordinatları kontrol ediliyor...";
            txtStatusFeedback.Foreground = HexBrush("#FBBF24");

            Task.Run(() =>
            {
                GeoLookupResult res = isAuto
                    ? LocationHelper.ResolveAutoLocation(selectedLanguage)
                    : LocationHelper.SearchCityByName(manualQuery, selectedLanguage);

                Dispatcher.Invoke(() =>
                {
                    if (res.Success)
                    {
                        resolvedLocation = res;
                        txtStatusFeedback.Text = IsEn
                            ? string.Format("✓ Selected Location: {0} ({1:0.00}, {2:0.00})", res.DisplayName, res.Latitude, res.Longitude)
                            : string.Format("✓ Seçilen Konum: {0} ({1:0.00}, {2:0.00})", res.DisplayName, res.Latitude, res.Longitude);
                        txtStatusFeedback.Foreground = HexBrush("#34D399");
                    }
                    else
                    {
                        txtStatusFeedback.Text = IsEn
                            ? "⚠ City not found, please enter a valid city or district name."
                            : "⚠ Şehir bulunamadı, lütfen geçerli bir il/ilçe adı yazın.";
                        txtStatusFeedback.Foreground = HexBrush("#FB7185");
                    }
                });
            });
        }

        private void BtnFinish_Click(object sender, RoutedEventArgs e)
        {
            btnFinish.IsEnabled = false;
            btnFinish.Content = IsEn ? "Preparing..." : "Hazırlanıyor...";

            bool isAuto = rbAutoGps.IsChecked == true;
            string manualQuery = txtCityInput.Text.Trim();
            bool enableCalendar = chkWizardCalendar != null && chkWizardCalendar.IsChecked == true;
            bool enableTimer = chkWizardTimer != null && chkWizardTimer.IsChecked == true;
            bool createDesktop = chkDesktopShortcut.IsChecked == true;
            bool enableStartup = chkStartupRun.IsChecked == true;
            string langToSave = selectedLanguage;

            Task.Run(() =>
            {
                GeoLookupResult finalLoc = resolvedLocation;
                if (!isAuto)
                {
                    GeoLookupResult manualRes = LocationHelper.SearchCityByName(manualQuery, langToSave);
                    if (manualRes.Success) finalLoc = manualRes;
                }
                else if (finalLoc == null || !finalLoc.Success)
                {
                    finalLoc = LocationHelper.ResolveAutoLocation(langToSave);
                }

                if (finalLoc == null || !finalLoc.Success)
                {
                    finalLoc = new GeoLookupResult { Success = true, DisplayName = IsEn ? "Istanbul" : "İstanbul", Latitude = 41.0082, Longitude = 28.9784 };
                }

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Language=" + langToSave);
                sb.AppendLine("Accent=" + selectedAccent);
                sb.AppendLine("Opacity=88");
                sb.AppendLine("LocationMode=" + (isAuto ? "Auto" : "Manual"));
                sb.AppendLine("LocationName=" + finalLoc.DisplayName);
                sb.AppendLine("Latitude=" + finalLoc.Latitude.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("Longitude=" + finalLoc.Longitude.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("ShowCalendarWidget=" + (enableCalendar ? "1" : "0"));
                sb.AppendLine("ShowTimerWidget=" + (enableTimer ? "1" : "0"));
                File.WriteAllText(configFilePath, sb.ToString());

                // Create shortcuts if requested
                try
                {
                    string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                    {
                        if (key != null)
                        {
                            if (enableStartup) key.SetValue("OpenWidgetPublic", "\"" + exePath + "\"");
                            else key.DeleteValue("OpenWidgetPublic", false);
                        }
                    }
                    if (enableStartup)
                    {
                        using (RegistryKey serKey = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize"))
                        {
                            if (serKey != null)
                            {
                                serKey.SetValue("StartupDelayInMSec", 0, RegistryValueKind.DWord);
                                serKey.SetValue("WaitForIdleState", 0, RegistryValueKind.DWord);
                            }
                        }
                    }

                    if (createDesktop)
                    {
                        string deskDir = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                        CreateShortcut(System.IO.Path.Combine(deskDir, "OpenWidget.lnk"), exePath);
                    }
                }
                catch { }

                Dispatcher.Invoke(() =>
                {
                    this.DialogResult = true;
                    this.Close();
                });
            });
        }

        private static void CreateShortcut(string shortcutPath, string targetExe)
        {
            try
            {
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                object shell = Activator.CreateInstance(t);
                object shortcut = t.InvokeMember("CreateShortcut", System.Reflection.BindingFlags.InvokeMethod, null, shell, new object[] { shortcutPath });
                Type st = shortcut.GetType();
                st.InvokeMember("TargetPath", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { targetExe });
                st.InvokeMember("WorkingDirectory", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { System.IO.Path.GetDirectoryName(targetExe) });
                st.InvokeMember("Description", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { "OpenWidget Desktop Widget" });
                st.InvokeMember("Save", System.Reflection.BindingFlags.InvokeMethod, null, shortcut, null);
            }
            catch { }
        }
    }

    // ========================================================
    // MONITOR DDC/CI & WINDOWS SDR WHITE LEVEL NATIVE ENGINE
    // ========================================================
    internal static class MonitorDdcNative
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int left, top, right, bottom;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct MONITORINFOEX
        {
            public int cbSize;
            public RECT rcMonitor;
            public RECT rcWork;
            public uint dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string szDevice;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct PHYSICAL_MONITOR
        {
            public IntPtr hPhysicalMonitor;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string szPhysicalMonitorDescription;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct LUID
        {
            public uint LowPart;
            public int HighPart;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_PATH_SOURCE_INFO
        {
            public LUID adapterId;
            public uint id;
            public uint modeInfoIdx;
            public uint statusFlags;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_PATH_TARGET_INFO
        {
            public LUID adapterId;
            public uint id;
            public uint modeInfoIdx;
            public uint outputTechnology;
            public uint rotation;
            public uint scaling;
            public uint refreshRateNumerator;
            public uint refreshRateDenominator;
            public uint scanLineOrdering;
            public int targetAvailable;
            public uint statusFlags;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_PATH_INFO
        {
            public DISPLAYCONFIG_PATH_SOURCE_INFO sourceInfo;
            public DISPLAYCONFIG_PATH_TARGET_INFO targetInfo;
            public uint flags;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_MODE_INFO
        {
            public uint infoType;
            public uint id;
            public LUID adapterId;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 48)]
            public byte[] data;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_DEVICE_INFO_HEADER
        {
            public int type;
            public uint size;
            public LUID adapterId;
            public uint id;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DISPLAYCONFIG_SOURCE_DEVICE_NAME
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string viewGdiDeviceName;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DISPLAYCONFIG_TARGET_DEVICE_NAME
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            public uint flags;
            public uint outputTechnology;
            public ushort edidManufactureId;
            public ushort edidProductCodeId;
            public uint connectorInstance;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
            public string monitorFriendlyDeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string monitorDevicePath;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_SDR_WHITE_LEVEL
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            public uint SDRWhiteLevel;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_SET_SDR_WHITE_LEVEL
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            public uint SDRWhiteLevel;
            public byte finalValue;
            public byte pad1;
            public byte pad2;
            public byte pad3;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DISPLAYCONFIG_GET_ADVANCED_COLOR_INFO
        {
            public DISPLAYCONFIG_DEVICE_INFO_HEADER header;
            public uint value;
            public int colorEncoding;
            public uint bitsPerColorChannel;
        }

        public delegate bool MonitorEnumProc(IntPtr hMonitor, IntPtr hdcMonitor, ref RECT lprcMonitor, IntPtr dwData);

        [DllImport("user32.dll")]
        public static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr lprcClip, MonitorEnumProc lpfnEnum, IntPtr dwData);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFOEX lpmi);

        [DllImport("user32.dll")]
        public static extern int GetDisplayConfigBufferSizes(uint flags, out uint numPathArrayElements, out uint numModeInfoArrayElements);

        [DllImport("user32.dll")]
        public static extern int QueryDisplayConfig(uint flags, ref uint numPathArrayElements, [Out] DISPLAYCONFIG_PATH_INFO[] pathArray, ref uint numModeInfoArrayElements, [Out] DISPLAYCONFIG_MODE_INFO[] modeInfoArray, IntPtr currentTopologyId);

        [DllImport("user32.dll")]
        public static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_SOURCE_DEVICE_NAME requestPacket);

        [DllImport("user32.dll")]
        public static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_TARGET_DEVICE_NAME requestPacket);

        [DllImport("user32.dll")]
        public static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_SDR_WHITE_LEVEL requestPacket);

        [DllImport("user32.dll")]
        public static extern int DisplayConfigGetDeviceInfo(ref DISPLAYCONFIG_GET_ADVANCED_COLOR_INFO requestPacket);

        [DllImport("user32.dll")]
        public static extern int DisplayConfigSetDeviceInfo(ref DISPLAYCONFIG_SET_SDR_WHITE_LEVEL setPacket);

        [DllImport("dxva2.dll", SetLastError = true)]
        public static extern bool GetNumberOfPhysicalMonitorsFromHMONITOR(IntPtr hMonitor, out uint pdwNumberOfPhysicalMonitors);

        [DllImport("dxva2.dll", SetLastError = true)]
        public static extern bool GetPhysicalMonitorsFromHMONITOR(IntPtr hMonitor, uint dwPhysicalMonitorArraySize, [Out] PHYSICAL_MONITOR[] pPhysicalMonitorArray);

        [DllImport("dxva2.dll", SetLastError = true)]
        public static extern bool GetVCPFeatureAndVCPFeatureReply(IntPtr hMonitor, byte bVCPCode, out uint pvct, out uint pdwCurrentValue, out uint pdwMaximumValue);

        [DllImport("dxva2.dll", SetLastError = true)]
        public static extern bool SetVCPFeature(IntPtr hMonitor, byte bVCPCode, uint dwNewValue);

        [DllImport("dxva2.dll", SetLastError = true)]
        public static extern bool DestroyPhysicalMonitor(IntPtr hMonitor);

        public const byte VCP_BRIGHTNESS = 0x10;

        public class WinDisplayTargetInfo
        {
            public string GdiDeviceName;
            public string FriendlyName;
            public LUID AdapterId;
            public uint TargetId;
            public bool HdrEnabled;
            public int SdrBrightnessPct;
        }

        public static List<WinDisplayTargetInfo> QueryActiveDisplayTargets()
        {
            List<WinDisplayTargetInfo> list = new List<WinDisplayTargetInfo>();
            try
            {
                uint np, nm;
                if (GetDisplayConfigBufferSizes(2, out np, out nm) != 0) return list;
                DISPLAYCONFIG_PATH_INFO[] paths = new DISPLAYCONFIG_PATH_INFO[np];
                DISPLAYCONFIG_MODE_INFO[] modes = new DISPLAYCONFIG_MODE_INFO[nm];
                if (QueryDisplayConfig(2, ref np, paths, ref nm, modes, IntPtr.Zero) != 0) return list;

                for (int i = 0; i < np; i++)
                {
                    var p = paths[i];
                    var srcName = new DISPLAYCONFIG_SOURCE_DEVICE_NAME();
                    srcName.header.type = 1;
                    srcName.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_SOURCE_DEVICE_NAME));
                    srcName.header.adapterId = p.sourceInfo.adapterId;
                    srcName.header.id = p.sourceInfo.id;
                    DisplayConfigGetDeviceInfo(ref srcName);

                    var tName = new DISPLAYCONFIG_TARGET_DEVICE_NAME();
                    tName.header.type = 2;
                    tName.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_TARGET_DEVICE_NAME));
                    tName.header.adapterId = p.targetInfo.adapterId;
                    tName.header.id = p.targetInfo.id;
                    DisplayConfigGetDeviceInfo(ref tName);

                    var adv = new DISPLAYCONFIG_GET_ADVANCED_COLOR_INFO();
                    adv.header.type = 9;
                    adv.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_GET_ADVANCED_COLOR_INFO));
                    adv.header.adapterId = p.targetInfo.adapterId;
                    adv.header.id = p.targetInfo.id;
                    DisplayConfigGetDeviceInfo(ref adv);
                    bool hdrActive = ((adv.value & 0x2) != 0);

                    var sdr = new DISPLAYCONFIG_SDR_WHITE_LEVEL();
                    sdr.header.type = 11;
                    sdr.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_SDR_WHITE_LEVEL));
                    sdr.header.adapterId = p.targetInfo.adapterId;
                    sdr.header.id = p.targetInfo.id;
                    int sdrRc = DisplayConfigGetDeviceInfo(ref sdr);

                    int pct = 60;
                    if (sdrRc == 0 && sdr.SDRWhiteLevel >= 1000)
                    {
                        pct = (int)Math.Round((sdr.SDRWhiteLevel - 1000) / 50.0);
                        pct = Math.Max(0, Math.Min(100, pct));
                    }

                    list.Add(new WinDisplayTargetInfo
                    {
                        GdiDeviceName = srcName.viewGdiDeviceName,
                        FriendlyName = tName.monitorFriendlyDeviceName,
                        AdapterId = p.targetInfo.adapterId,
                        TargetId = p.targetInfo.id,
                        HdrEnabled = hdrActive,
                        SdrBrightnessPct = pct
                    });
                }
            }
            catch { }
            return list;
        }

        public static bool SetSdrWhiteLevelPercent(LUID adapterId, uint targetId, int pct)
        {
            try
            {
                int clamped = Math.Max(0, Math.Min(100, pct));
                uint rawWhiteLevel = (uint)(1000 + clamped * 50);

                var setPkt = new DISPLAYCONFIG_SET_SDR_WHITE_LEVEL();
                setPkt.header.type = -18;
                setPkt.header.size = (uint)Marshal.SizeOf(typeof(DISPLAYCONFIG_SET_SDR_WHITE_LEVEL));
                setPkt.header.adapterId = adapterId;
                setPkt.header.id = targetId;
                setPkt.SDRWhiteLevel = rawWhiteLevel;
                setPkt.finalValue = 1;
                return DisplayConfigSetDeviceInfo(ref setPkt) == 0;
            }
            catch
            {
                return false;
            }
        }
    }

    internal class PhysicalMonitorSlot
    {
        public IntPtr Handle = IntPtr.Zero;
        public string Name = "Monitor";
        public uint MinVal = 0;
        public uint MaxVal = 100;
        public int CurrentBrightness = 60;
        public int PendingBrightness = -1;
        public int WorkerBusy = 0;
        public bool UseWindowsSdrWhiteLevel = false;
        public MonitorDdcNative.LUID AdapterId;
        public uint TargetId = 0;
    }

    // ========================================================
    // MAIN WIDGET WINDOW (PUBLIC EDITION - NO BULB BLOAT)
    // ========================================================
    public class MainWindow : Window
    {
        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);
        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtr")]
        private static extern IntPtr SetWindowLongPtr64(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")]
        private static extern bool AddClipboardFormatListener(IntPtr hwnd);
        [DllImport("user32.dll")]
        private static extern bool RemoveClipboardFormatListener(IntPtr hwnd);
        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
        [DllImport("user32.dll")]
        private static extern IntPtr GetWindow(IntPtr hWnd, uint uCmd);
        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")]
        private static extern bool IsIconic(IntPtr hWnd);
        [DllImport("kernel32.dll")]
        private static extern ulong GetTickCount64();
        [DllImport("kernel32.dll")]
        private static extern bool SetProcessWorkingSetSize(IntPtr proc, IntPtr min, IntPtr max);
        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr hObject);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern bool QueryFullProcessImageName(IntPtr hProcess, int dwFlags, StringBuilder lpExeName, ref int lpdwSize);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetExitCodeProcess(IntPtr hProcess, out uint lpExitCode);

        private const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
        private const uint STILL_ACTIVE = 259;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private class MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
            public MEMORYSTATUSEX() { this.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX)); }
        }
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

        private const int GWL_EXSTYLE = -20;
        private const int GWLP_HWNDPARENT = -8;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int HOTKEY_ID_MIC = 9001;
        private const uint MOD_CONTROL = 0x0002;
        private const uint MOD_SHIFT = 0x0004;
        private const uint VK_M = 0x4D;
        private const uint WM_NCLBUTTONDOWN = 0x00A1;
        private const int HT_CAPTION = 0x02;
        private const int WM_CLIPBOARDUPDATE = 0x031D;

        private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        private static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
        private static readonly IntPtr HWND_BOTTOM = new IntPtr(1);
        private const int WS_EX_TOPMOST = 0x00000008;
        private const uint GW_HWNDPREV = 3;
        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOMOVE = 0x0002;
        private const uint SWP_NOZORDER = 0x0004;
        private const uint SWP_NOACTIVATE = 0x0010;
        private const uint SWP_SHOWWINDOW = 0x0040;
        private const int SW_SHOWNOACTIVATE = 4;

        [StructLayout(LayoutKind.Sequential)]
        private struct WINDOWPOS
        {
            public IntPtr hwnd;
            public IntPtr hwndInsertAfter;
            public int x;
            public int y;
            public int cx;
            public int cy;
            public uint flags;
        }

        private bool userHidden = false;
        private bool isShowDesktopActive = false;
        private IntPtr cachedMainHwnd = IntPtr.Zero;
        private IntPtr cachedCalHwnd = IntPtr.Zero;
        private IntPtr cachedTimerHwnd = IntPtr.Zero;
        private IntPtr lastVerifiedFgHwnd = IntPtr.Zero;
        private readonly StringBuilder fgClassBuilder = new StringBuilder(64);
        private DispatcherTimer saveSettingsDebounceTimer;

        // Theme, Language, Location & Window State
        private string settingsFilePath;
        private string appLanguage = "TR";
        private string accentColorHex = "#E2925C";
        private int bgOpacityPercent = 88;
        private string locationMode = "Auto";
        private string locationName = "İstanbul";
        private double locationLat = 41.0082;
        private double locationLon = 28.9784;

        private bool IsEn
        {
            get { return string.Equals(appLanguage, "EN", StringComparison.OrdinalIgnoreCase); }
        }

        private string L(string tr, string en)
        {
            return IsEn ? en : tr;
        }

        private bool isDraggable = false;
        private double savedFreeWidth = 370;
        private double savedFreeHeight = 620;
        private double savedLeft = double.NaN;
        private double savedTop = double.NaN;
        private bool hasSavedDimensions = false;
        private bool isWindowInitialized = false;
        private bool isCalWindowInitialized = false;
        private bool isTimerWindowInitialized = false;

        // Audio / Tray State (Cached Single COM Endpoint)
        private bool isMicMuted = false;
        private IAudioEndpointVolume cachedMicVolumeConsole;
        private IAudioEndpointVolume cachedMicVolumeComm;
        private System.Windows.Forms.NotifyIcon trayIcon;
        private System.Drawing.Icon iconMicUnmuted;
        private System.Drawing.Icon iconMicMuted;
        private System.Windows.Forms.ToolStripMenuItem trayMuteItem;
        private System.Windows.Forms.ToolStripMenuItem traySettingsItem;
        private System.Windows.Forms.ToolStripMenuItem trayLockItem;
        private System.Windows.Forms.ToolStripMenuItem trayFitHeightItem;
        private System.Windows.Forms.ToolStripMenuItem trayDockRightItem;
        private System.Windows.Forms.ToolStripMenuItem trayDockLeftItem;
        private System.Windows.Forms.ToolStripMenuItem trayToggleVisItem;
        private System.Windows.Forms.ToolStripMenuItem trayAutoStartItem;
        private System.Windows.Forms.ToolStripMenuItem trayExitItem;
        private Window settingsWindow;

        // Telemetry Counters & Direct NVML Handle (Dynamic Hardware Detection for Any User's PC)
        private PerformanceCounter cpuCounter;
        private bool nvmlInitialized = false;
        private IntPtr nvmlDeviceHandle = IntPtr.Zero;
        private Ping sharedPing;
        private MEMORYSTATUSEX sharedMemStatus = new MEMORYSTATUSEX();
        private List<DriveInfo> fixedDrives = new List<DriveInfo>();

        private List<double> cpuHistory = new List<double>(20);
        private List<double> gpuHistory = new List<double>(20);
        private long lastBytesRecv = 0;
        private long lastBytesSent = 0;
        private DateTime lastNetTime = DateTime.Now;
        private double lastPingMs = 10;
        private double cpuTemp = 46;
        private string cpuShortName = "CPU";
        private string gpuModelName = "GPU";
        private double gpuTemp = 45;
        private double gpuLoad = 0;
        private double vramUsedGb = 1.5;
        private double vramTotalGb = 8.0;

        // Clipboard History
        private List<ClipboardEntry> clipboardHistory = new List<ClipboardEntry>();
        private string lastClipboardText = "";

        // Dynamic Theme UI References
        private Border outerBorder;
        private List<Border> glassCards = new List<Border>();
        private List<Border> subBoxes = new List<Border>();
        private List<TextBlock> accentTextBlocks = new List<TextBlock>();
        private List<Polyline> accentSparklines = new List<Polyline>();
        private List<Border> accentBarFills = new List<Border>();
        private Border weatherIconBox;
        private Border resizeGripIndicator;
        private WindowChrome windowChrome;

        // Specific UI Elements
        private TextBlock txtClockAndUptime;
        private Button btnLockDrag;
        private Button btnSettingsHeader;
        private Button btnMicHeader;
        private TextBlock txtMicHeaderIcon;

        // Weather UI & Unit State
        private bool useFahrenheit = false;
        private double lastWeatherTempC = 14;
        private double lastWeatherFeelsC = 13;
        private double[] lastWeatherMinC = new double[] { 8, 6, 8 };
        private double[] lastWeatherMaxC = new double[] { 16, 14, 16 };
        private TextBlock txtWeatherSectionTitle;
        private TextBlock txtLocationBadge;
        private TextBlock txtWeatherTemp;
        private TextBlock txtWeatherDesc;
        private TextBlock txtWeatherFeels;
        private TextBlock txtWeatherMainIcon;
        private TextBlock txtHumidityLabel;
        private TextBlock txtWindLabel;
        private TextBlock txtRainLabel;
        private TextBlock txtWeatherHumidity;
        private TextBlock txtWeatherWind;
        private TextBlock txtWeatherRain;
        private TextBlock[] txtDayNames = new TextBlock[3];
        private TextBlock[] txtDayIcons = new TextBlock[3];
        private TextBlock[] txtDayTemps = new TextBlock[3];

        // Wireless Peripherals Battery UI & State (Auto-Detects Mouse, Keyboard, Headset, Controller)
        private class WirelessRowUi
        {
            public Grid Row;
            public TextBlock Label;
            public TextBlock Detail;
            public Border Fill;
            public TextBlock Pct;
        }
        private Grid wirelessHeaderGrid;
        private TextBlock txtWirelessSectionTitle;
        private Button btnRefreshWireless;
        private StackPanel panelWirelessContent;
        private Dictionary<string, WirelessRowUi> wirelessRowCache = new Dictionary<string, WirelessRowUi>(StringComparer.OrdinalIgnoreCase);
        private Dictionary<string, int> wirelessLastPcts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private Dictionary<string, string> wirelessLastHz = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private int wirelessPollingBusy = 0;
        private int lastWirelessCount = 0;

        // Monitor Brightness UI & State (Auto-Detects Connected Displays, HDR SDRWhiteLevel + DDC/CI)
        private readonly List<PhysicalMonitorSlot> monitorSlots = new List<PhysicalMonitorSlot>();
        private readonly object monitorHandleLock = new object();
        private bool monitorLinkSync = false;
        private bool isUpdatingMonitorUi = false;
        private Grid monHeaderGrid;
        private TextBlock txtMonitorSectionTitle;
        private Button btnMonitorLink;
        private Button btnRefreshMonitors;
        private Border monitorCard;
        private StackPanel monRowsHostStack;
        private List<TextBlock> txtMonitorNames = new List<TextBlock>();
        private List<TextBlock> txtMonitorPercents = new List<TextBlock>();
        private List<Slider> sliderMonitors = new List<Slider>();
        private List<Border> monitorSliderContainers = new List<Border>();

        // Layout Order & Visibility State
        private List<string> sectionOrder = new List<string> { "weather", "monitors", "wireless", "telemetry", "clipboard" };
        private bool showSecWeather = true;
        private bool showSecMonitors = true;
        private bool showSecWireless = true;
        private bool showSecTelemetry = true;
        private bool showSecClipboard = true;
        private bool showTeleCpu = true;
        private bool showTeleRam = true;
        private bool showTeleGpu = true;
        private bool showTeleVram = true;
        private bool showTeleNet = true;
        private bool showTeleDisks = true;
        private int currentSettingsTab = 0;

        // Section Root Containers for Dynamic Reordering
        private StackPanel modulesHostPanel;
        private StackPanel secContainerWeather;
        private StackPanel secContainerMonitors;
        private StackPanel secContainerWireless;
        private StackPanel secContainerTelemetry;
        private StackPanel secContainerClipboard;

        // Telemetry UI
        private TextBlock txtTelemetrySectionTitle;
        private StackPanel panelTelemetryContent;
        private Grid rowTeleCpu;
        private Grid rowTeleRam;
        private Grid rowTeleGpu;
        private Grid rowTeleVram;
        private Grid rowTeleNet;
        private List<Grid> rowsTeleDisks = new List<Grid>();
        private TextBlock txtCpuRowLabel;
        private TextBlock txtCpuDetail;
        private TextBlock txtCpuPct;
        private Polyline sparkCpu;
        private TextBlock txtRamRowLabel;
        private TextBlock txtRamDetail;
        private TextBlock txtRamPct;
        private Border barRamFill;
        private TextBlock txtGpuRowLabel;
        private TextBlock txtGpuDetail;
        private TextBlock txtGpuPct;
        private Polyline sparkGpu;
        private TextBlock txtVramRowLabel;
        private TextBlock txtVramDetail;
        private TextBlock txtVramPct;
        private Border barVramFill;
        private TextBlock txtNetRowLabel;
        private TextBlock txtNetSpeed;
        private TextBlock txtNetBadge;
        private TextBlock txtNetPing;
        private List<TextBlock> diskRowLabels = new List<TextBlock>();
        private List<TextBlock> diskDetailBlocks = new List<TextBlock>();
        private List<Border> diskFillBars = new List<Border>();
        private List<TextBlock> diskPctBlocks = new List<TextBlock>();

        // Clipboard UI
        private TextBlock txtClipboardSectionTitle;
        private Button btnClearClip;
        private TextBlock txtClipCount;
        private StackPanel panelClipItems;
        private Popup toastPopup;
        private Border toastBorder;
        private TextBlock txtToastMessage;
        private DispatcherTimer toastTimer;

        // Standalone Google Calendar Desktop Widget (Default Off for Public)
        private bool showCalendarWidget = false;
        private double savedCalWidth = 468;
        private double savedCalHeight = 258;
        private double savedCalLeft = double.NaN;
        private double savedCalTop = double.NaN;
        private string calendarSecretIcalUrl = "";
        private Window calendarWindow;
        private Border calOuterBorder;
        private WindowChrome calWindowChrome;
        private Border calResizeGrip;
        private Button btnCalLockDrag;
        private TextBlock txtCalDayOfWeekHeader;
        private TextBlock txtCalBigDayNum;
        private TextBlock txtCalMonthYearLabel;
        private StackPanel calMiniMonthGrid;
        private TextBlock txtCalRightScheduleTitle;
        private ScrollViewer calEventsScroll;
        private StackPanel calEventsListPanel;
        private Border calQuickAddPanel;
        private TextBox txtCalQuickTitle;
        private TextBox txtCalQuickTime;
        private TextBox txtCalQuickLoc;
        private DateTime calDisplayedMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
        private DateTime calSelectedDate = DateTime.Today;
        private readonly List<CalendarEventItem> allCalendarEvents = new List<CalendarEventItem>();
        private Dictionary<DateTime, byte> calEventDotsByDate = new Dictionary<DateTime, byte>();
        private int calEventsVersion = 0;
        private string lastLeftColumnSignature = "";
        private string lastRightScheduleSignature = "";
        private DateTime lastCalDatWriteUtc = DateTime.MinValue;
        private DateTime lastCustomDatWriteUtc = DateTime.MinValue;
        private readonly object calEventsLock = new object();
        private System.Windows.Forms.ToolStripMenuItem trayCalendarItem;

        // Standalone Timer Widget (Modes, Auto Game Detection, Pomodoro & Yearly Heatmap - Default Off for Public)
        private bool showTimerWidget = false;
        private double savedTimerWidth = 540;
        private double savedTimerHeight = 310;
        private double savedTimerLeft = double.NaN;
        private double savedTimerTop = double.NaN;
        private int timerCurrentMode = 0;
        private bool defaultTimerIsRunning = false;
        private int defaultTimerSeconds = 0;
        private bool gameTimerIsRunning = false;
        private int pomoFocusMinutes = 25;
        private int pomoBreakMinutes = 5;
        private bool pomoIsRunning = false;
        private bool pomoIsBreakPhase = false;
        private int pomoRemainingSeconds = 25 * 60;
        private int timerGameSessionSeconds = 0;
        private int timerSaveTickCounter = 0;
        private DateTime activeTrackingDate = DateTime.Today;
        private string activityDataFilePath;
        private Window timerWindow;
        private Border timerOuterBorder;
        private WindowChrome timerWindowChrome;
        private Border timerResizeGrip;
        private Button btnTimerLockDrag;
        private Button[] btnTimerModes = new Button[3];
        private Border timerPomoSettingsPopup;
        private TextBlock txtTimerDialPhase;
        private TextBlock txtTimerDialCenter;
        private TextBlock txtTimerDialSub;
        private TextBlock txtPomoFocusSettingVal;
        private TextBlock txtPomoBreakSettingVal;
        private Border timerDialInnerCircle;
        private Line[] timerDialTicks = new Line[24];
        private Button btnPomoPlayPause;
        private TextBlock txtPomoPlayPauseIcon;
        private Button btnPomoReset;
        private TextBlock txtTodayStudyVal;
        private TextBlock txtTodayGameVal;
        private TextBlock txtTodayPcVal;
        private Grid timerHeatmapHost;
        private Canvas timerHeatmapCanvas;
        private int lastHeatmapLayoutWidth = 0;
        private int lastHeatmapLayoutHeight = 0;
        private readonly List<Border> heatmapCellPool = new List<Border>(400);
        private readonly List<TextBlock> heatmapMonthPool = new List<TextBlock>(16);
        private string lastPlayBtnBrushKey = "";
        private Brush cachedPlayBtnBg = null;
        private Brush cachedPlayBtnBd = null;
        private int lastRenderedLitTicks = -1;
        private string lastRenderedTickHex = "";
        private Border todayHeatmapCell;
        private Brush[] cachedHeatmapTierBrushes = new Brush[6];
        private string cachedHeatmapAccentHex = "";
        private DispatcherTimer timerWidgetTickTimer;
        private System.Windows.Forms.ToolStripMenuItem trayTimerItem;
        private readonly Dictionary<DateTime, DailyActivityRecord> activityByDate = new Dictionary<DateTime, DailyActivityRecord>();
        private uint activeGamePid = 0;
        private string activeGameName = "";
        private uint lastCheckedNonGamePid = 0;
        private bool lastCheckedWasJava = false;
        private int autoGameCheckTick = 0;
        private readonly StringBuilder procPathSb = new StringBuilder(512);
        private readonly StringBuilder windowTitleSb = new StringBuilder(256);

        private static readonly HashSet<string> ExcludedNonGameExes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "explorer", "searchhost", "searchapp", "shellexperiencehost", "startmenuexperiencehost",
            "textinputhost", "applicationframehost", "systemsettings", "taskmgr", "dwm", "csrss", "svchost",
            "lockapp", "snippingtool", "screenclippinghost", "mspaint", "notepad", "calc", "calculatorapp",
            "cmd", "powershell", "pwsh", "windowsterminal", "conhost", "regedit", "mmc", "control", "msiexec", "rundll32",
            "chrome", "msedge", "firefox", "opera", "opera_gx", "brave", "vivaldi",
            "discord", "discordptb", "discordcanary", "spotify", "vlc", "mpv", "potplayermini64",
            "telegram", "whatsapp", "teams", "ms-teams", "slack", "zoom",
            "code", "devenv", "rider64", "idea64", "pycharm64", "clion64", "sublime_text", "notepad++",
            "openwidget", "wallpaper32", "wallpaper64", "ui32", "obs64", "obs32", "sharex", "nvidia overlay", "geforceexperience",
            "steam", "steamwebhelper", "steamservice", "gameoverlayui", "epicgameslauncher", "epicwebhelper",
            "eosoverlayrenderer-win64-shipping", "riotclientservices", "riotclientux", "riotclientuxrender", "riotclientelectron",
            "battle.net", "agent", "eaapp", "eadesktop", "eabackgroundservice", "ealocalhostsvc", "origin",
            "ubisoftconnect", "upc", "ubisoftgamelauncher", "galaxyclient", "xboxpcapp", "gamingservices",
            "curseforge", "overwolf", "overwolfbrowser", "modrinth app", "prismlauncher", "multimc", "tlauncher",
            "vgc", "vgtray", "easyanticheat", "easyanticheat_eos"
        };

        private static readonly Dictionary<string, string> KnownGameFriendlyNames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "cs2", "Counter-Strike 2" },
            { "csgo", "CS:GO" },
            { "valorant", "VALORANT" },
            { "valorant-win64-shipping", "VALORANT" },
            { "league of legends", "League of Legends" },
            { "r5apex", "Apex Legends" },
            { "r5apex_dx12", "Apex Legends" },
            { "eldenring", "ELDEN RING" },
            { "gta5", "GTA V" },
            { "gta5_enhanced", "GTA V" },
            { "playgtav", "GTA V" },
            { "rdr2", "Red Dead Redemption 2" },
            { "cyberpunk2077", "Cyberpunk 2077" },
            { "witcher3", "The Witcher 3" },
            { "fortniteclient-win64-shipping", "Fortnite" },
            { "overwatch", "Overwatch 2" },
            { "dota2", "Dota 2" },
            { "rocketleague", "Rocket League" },
            { "tslgame", "PUBG" },
            { "bg3", "Baldur's Gate 3" },
            { "bg3_dx11", "Baldur's Gate 3" },
            { "fc24", "EA FC 24" },
            { "fc25", "EA FC 25" },
            { "forzahorizon5", "Forza Horizon 5" },
            { "eurotrucks2", "Euro Truck Sim 2" },
            { "amtrucks", "American Truck Sim" },
            { "rustclient", "Rust" },
            { "deadbydaylight-win64-shipping", "Dead by Daylight" },
            { "genshinimpact", "Genshin Impact" },
            { "starrail", "Honkai: Star Rail" },
            { "palworld-win64-shipping", "Palworld" },
            { "helldivers2", "HELLDIVERS 2" },
            { "marvel-win64-shipping", "Marvel Rivals" },
            { "marvelrivals-win64-shipping", "Marvel Rivals" },
            { "b1-win64-shipping", "Black Myth: Wukong" },
            { "pathofexile", "Path of Exile" },
            { "pathofexile_x64", "Path of Exile" },
            { "pathofexile2", "Path of Exile 2" },
            { "pathofexile2steam", "Path of Exile 2" },
            { "escapefromtarkov", "Escape from Tarkov" },
            { "rainbowsix", "Rainbow Six Siege" },
            { "rainbowsix_vulkan", "Rainbow Six Siege" },
            { "rainbowsix_be", "Rainbow Six Siege" },
            { "robloxplayerbeta", "Roblox" },
            { "minecraft.windows", "Minecraft Bedrock" },
            { "stardew valley", "Stardew Valley" },
            { "hades", "Hades" },
            { "hades2", "Hades II" },
            { "hollow_knight", "Hollow Knight" },
            { "terraria", "Terraria" },
            { "factorio", "Factorio" },
            { "factorygame-win64-shipping", "Satisfactory" },
            { "factorygamesteam-win64-shipping", "Satisfactory" },
            { "valheim", "Valheim" },
            { "sekiro", "Sekiro" },
            { "darksoulsiii", "Dark Souls III" },
            { "l4d2", "Left 4 Dead 2" },
            { "left4dead2", "Left 4 Dead 2" },
            { "tf_win64", "Team Fortress 2" },
            { "brawlhalla", "Brawlhalla" },
            { "osu!", "osu!" },
            { "xerogame", "Xero" }
        };

        private class DailyActivityRecord
        {
            public DateTime Date;
            public int StudySeconds;
            public int GameSeconds;
            public int PcSeconds;
        }

        private class CalendarEventItem
        {
            public DateTime Start;
            public DateTime End;
            public bool AllDay;
            public string Source;
            public string ColorHex;
            public string Title;
            public string Location;
            public string Description;
            public string HtmlLink;
            public string RawCustomLine;
        }

        public MainWindow()
        {
            settingsFilePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "settings.cfg");
            LoadSettings();
            DetectUserHardwareNames();

            for (int i = 0; i < 20; i++)
            {
                cpuHistory.Add(6);
                gpuHistory.Add(2);
            }

            try { sharedPing = new Ping(); } catch { }
            try
            {
                foreach (DriveInfo d in DriveInfo.GetDrives())
                {
                    if (d.DriveType == DriveType.Fixed && d.IsReady)
                    {
                        fixedDrives.Add(d);
                        if (fixedDrives.Count >= 3) break;
                    }
                }
            }
            catch { }

            InitializeWindowProps();
            BuildUserInterface();
            ApplyTheme(accentColorHex, bgOpacityPercent);
            InitializeTrayAndAudio();
            ApplyLanguage();
            InitializeTimers();
        }

        private void DetectUserHardwareNames()
        {
            // Detect CPU friendly model name from Registry (instant, zero WMI overhead)
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0", false))
                {
                    if (key != null)
                    {
                        string rawCpu = (key.GetValue("ProcessorNameString") ?? "").ToString().Trim();
                        rawCpu = Regex.Replace(rawCpu, @"\b(AMD|Intel\(R\)|Core\(TM\)|Processor|\d+-Core|\d+(st|nd|rd|th)\s+Gen)\b", "", RegexOptions.IgnoreCase);
                        rawCpu = Regex.Replace(rawCpu, @"\s+with\s+Radeon.*$", "", RegexOptions.IgnoreCase);
                        rawCpu = Regex.Replace(rawCpu, @"\s+", " ").Trim();
                        if (!string.IsNullOrEmpty(rawCpu)) cpuShortName = rawCpu;
                    }
                }
            }
            catch { }
        }

        private void LoadSettings()
        {
            try
            {
                if (File.Exists(settingsFilePath))
                {
                    foreach (string line in File.ReadAllLines(settingsFilePath))
                    {
                        int idx = line.IndexOf('=');
                        if (idx > 0)
                        {
                            string k = line.Substring(0, idx).Trim();
                            string v = line.Substring(idx + 1).Trim();
                            if (k == "Language" && (v.Equals("EN", StringComparison.OrdinalIgnoreCase) || v.Equals("TR", StringComparison.OrdinalIgnoreCase)))
                                appLanguage = v.ToUpperInvariant();
                            else if (k == "TempUnit")
                                useFahrenheit = (v.Equals("F", StringComparison.OrdinalIgnoreCase) || v.Equals("Fahrenheit", StringComparison.OrdinalIgnoreCase));
                            else if (k == "Accent" && v.StartsWith("#") && (v.Length == 7 || v.Length == 9))
                                accentColorHex = v;
                            else if (k == "Opacity")
                            {
                                int op;
                                if (int.TryParse(v, out op)) bgOpacityPercent = Math.Max(30, Math.Min(100, op));
                            }
                            else if (k == "LocationMode")
                                locationMode = v;
                            else if (k == "LocationName" && !string.IsNullOrEmpty(v))
                                locationName = v;
                            else if (k == "Latitude")
                                double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out locationLat);
                            else if (k == "Longitude")
                                double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out locationLon);
                            else if (k == "FreeWidth")
                            {
                                double fw;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out fw))
                                {
                                    savedFreeWidth = Math.Max(330, Math.Min(700, fw));
                                    hasSavedDimensions = true;
                                }
                            }
                            else if (k == "FreeHeight")
                            {
                                double fh;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out fh))
                                {
                                    savedFreeHeight = Math.Max(380, Math.Min(1400, fh));
                                    hasSavedDimensions = true;
                                }
                            }
                            else if (k == "Left")
                            {
                                double l;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out l))
                                    savedLeft = l;
                            }
                            else if (k == "Top")
                            {
                                double t;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out t))
                                    savedTop = t;
                            }
                            else if (k == "MonitorLink")
                                monitorLinkSync = (v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowWeather")
                                showSecWeather = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowMonitors")
                                showSecMonitors = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowWireless")
                                showSecWireless = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTelemetry")
                                showSecTelemetry = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowClipboard")
                                showSecClipboard = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTeleCpu")
                                showTeleCpu = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTeleRam")
                                showTeleRam = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTeleGpu")
                                showTeleGpu = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTeleVram")
                                showTeleVram = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTeleNet")
                                showTeleNet = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "ShowTeleDisks")
                                showTeleDisks = (v != "0" && !v.Equals("false", StringComparison.OrdinalIgnoreCase));
                            else if (k == "SectionOrder" && !string.IsNullOrEmpty(v))
                            {
                                string[] parts = v.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                List<string> parsed = new List<string>();
                                string[] validKeys = { "weather", "monitors", "wireless", "telemetry", "clipboard" };
                                foreach (string p in parts)
                                {
                                    string clean = p.Trim().ToLowerInvariant();
                                    if (Array.IndexOf(validKeys, clean) >= 0 && !parsed.Contains(clean))
                                        parsed.Add(clean);
                                }
                                foreach (string vk in validKeys)
                                {
                                    if (!parsed.Contains(vk)) parsed.Add(vk);
                                }
                                sectionOrder = parsed;
                            }
                            else if (k == "ShowCalendarWidget") showCalendarWidget = (v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase));
                            else if (k == "CalWidth")
                            {
                                double cw;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out cw))
                                    savedCalWidth = Math.Max(390, Math.Min(900, cw));
                            }
                            else if (k == "CalHeight")
                            {
                                double ch;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out ch))
                                    savedCalHeight = Math.Max(215, Math.Min(900, ch));
                            }
                            else if (k == "CalLeft")
                            {
                                double cl;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out cl))
                                    savedCalLeft = cl;
                            }
                            else if (k == "CalTop")
                            {
                                double ct;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out ct))
                                    savedCalTop = ct;
                            }
                            else if (k == "CalendarIcalUrl")
                            {
                                calendarSecretIcalUrl = v.Trim();
                            }
                            else if (k == "ShowTimerWidget") showTimerWidget = (v == "1" || v.Equals("true", StringComparison.OrdinalIgnoreCase));
                            else if (k == "TimerWidth")
                            {
                                double tw;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tw))
                                    savedTimerWidth = Math.Max(460, Math.Min(950, tw));
                            }
                            else if (k == "TimerHeight")
                            {
                                double th;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out th))
                                    savedTimerHeight = Math.Max(275, Math.Min(650, th));
                            }
                            else if (k == "TimerLeft")
                            {
                                double tl;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tl))
                                    savedTimerLeft = tl;
                            }
                            else if (k == "TimerTop")
                            {
                                double tt;
                                if (double.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tt))
                                    savedTimerTop = tt;
                            }
                            else if (k == "PomoFocusMin")
                            {
                                int pf;
                                if (int.TryParse(v, out pf))
                                {
                                    pomoFocusMinutes = Math.Max(1, Math.Min(180, pf));
                                    pomoRemainingSeconds = pomoFocusMinutes * 60;
                                }
                            }
                            else if (k == "PomoBreakMin")
                            {
                                int pb;
                                if (int.TryParse(v, out pb))
                                    pomoBreakMinutes = Math.Max(1, Math.Min(60, pb));
                            }
                        }
                    }
                }
            }
            catch { }
            if (IsAutoStartEnabled()) EnsureAutoStart(true);
        }

        private void SaveSettings()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Language=" + appLanguage);
                sb.AppendLine("TempUnit=" + (useFahrenheit ? "F" : "C"));
                sb.AppendLine("Accent=" + accentColorHex);
                sb.AppendLine("Opacity=" + bgOpacityPercent);
                sb.AppendLine("LocationMode=" + locationMode);
                sb.AppendLine("LocationName=" + locationName);
                sb.AppendLine("Latitude=" + locationLat.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("Longitude=" + locationLon.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("FreeWidth=" + savedFreeWidth.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("FreeHeight=" + savedFreeHeight.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!double.IsNaN(savedLeft))
                    sb.AppendLine("Left=" + savedLeft.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!double.IsNaN(savedTop))
                    sb.AppendLine("Top=" + savedTop.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("MonitorLink=" + (monitorLinkSync ? "1" : "0"));
                sb.AppendLine("SectionOrder=" + string.Join(",", sectionOrder.ToArray()));
                sb.AppendLine("ShowWeather=" + (showSecWeather ? "1" : "0"));
                sb.AppendLine("ShowMonitors=" + (showSecMonitors ? "1" : "0"));
                sb.AppendLine("ShowWireless=" + (showSecWireless ? "1" : "0"));
                sb.AppendLine("ShowTelemetry=" + (showSecTelemetry ? "1" : "0"));
                sb.AppendLine("ShowClipboard=" + (showSecClipboard ? "1" : "0"));
                sb.AppendLine("ShowTeleCpu=" + (showTeleCpu ? "1" : "0"));
                sb.AppendLine("ShowTeleRam=" + (showTeleRam ? "1" : "0"));
                sb.AppendLine("ShowTeleGpu=" + (showTeleGpu ? "1" : "0"));
                sb.AppendLine("ShowTeleVram=" + (showTeleVram ? "1" : "0"));
                sb.AppendLine("ShowTeleNet=" + (showTeleNet ? "1" : "0"));
                sb.AppendLine("ShowTeleDisks=" + (showTeleDisks ? "1" : "0"));
                sb.AppendLine("ShowCalendarWidget=" + (showCalendarWidget ? "1" : "0"));
                sb.AppendLine("CalWidth=" + savedCalWidth.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("CalHeight=" + savedCalHeight.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!double.IsNaN(savedCalLeft))
                    sb.AppendLine("CalLeft=" + savedCalLeft.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!double.IsNaN(savedCalTop))
                    sb.AppendLine("CalTop=" + savedCalTop.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!string.IsNullOrEmpty(calendarSecretIcalUrl))
                    sb.AppendLine("CalendarIcalUrl=" + calendarSecretIcalUrl);
                sb.AppendLine("ShowTimerWidget=" + (showTimerWidget ? "1" : "0"));
                sb.AppendLine("TimerWidth=" + savedTimerWidth.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("TimerHeight=" + savedTimerHeight.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!double.IsNaN(savedTimerLeft))
                    sb.AppendLine("TimerLeft=" + savedTimerLeft.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                if (!double.IsNaN(savedTimerTop))
                    sb.AppendLine("TimerTop=" + savedTimerTop.ToString("0", System.Globalization.CultureInfo.InvariantCulture));
                sb.AppendLine("PomoFocusMin=" + pomoFocusMinutes);
                sb.AppendLine("PomoBreakMin=" + pomoBreakMinutes);
                File.WriteAllText(settingsFilePath, sb.ToString());
            }
            catch { }
        }

        private void SaveSettingsDebounced()
        {
            if (!isWindowInitialized) return;
            if (saveSettingsDebounceTimer == null)
            {
                saveSettingsDebounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(450) };
                saveSettingsDebounceTimer.Tick += (s, e) =>
                {
                    saveSettingsDebounceTimer.Stop();
                    SaveSettings();
                    TrimProcessMemory();
                };
            }
            saveSettingsDebounceTimer.Stop();
            saveSettingsDebounceTimer.Start();
        }

        private bool IsAutoStartEnabled()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", false))
                {
                    if (key != null) return key.GetValue("OpenWidgetPublic") != null;
                }
            }
            catch { }
            return false;
        }

        private void EnsureAutoStart(bool enable)
        {
            try
            {
                string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null)
                    {
                        if (enable) key.SetValue("OpenWidgetPublic", "\"" + exePath + "\"");
                        else key.DeleteValue("OpenWidgetPublic", false);
                    }
                }
                if (enable)
                {
                    using (RegistryKey serKey = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize"))
                    {
                        if (serKey != null)
                        {
                            serKey.SetValue("StartupDelayInMSec", 0, RegistryValueKind.DWord);
                            serKey.SetValue("WaitForIdleState", 0, RegistryValueKind.DWord);
                        }
                    }
                }
            }
            catch { }
        }

        private bool IsPositionWithinVirtualDesktop(double left, double top, double width, double height)
        {
            if (double.IsNaN(left) || double.IsNaN(top) || double.IsInfinity(left) || double.IsInfinity(top))
                return false;
            if (left <= -10000 || top <= -10000 || left >= 20000 || top >= 20000)
                return false;

            double vLeft = SystemParameters.VirtualScreenLeft;
            double vTop = SystemParameters.VirtualScreenTop;
            double vRight = vLeft + SystemParameters.VirtualScreenWidth;
            double vBottom = vTop + SystemParameters.VirtualScreenHeight;

            try
            {
                foreach (var scr in System.Windows.Forms.Screen.AllScreens)
                {
                    if (scr.Bounds.Left < vLeft) vLeft = scr.Bounds.Left;
                    if (scr.Bounds.Top < vTop) vTop = scr.Bounds.Top;
                    if (scr.Bounds.Right > vRight) vRight = scr.Bounds.Right;
                    if (scr.Bounds.Bottom > vBottom) vBottom = scr.Bounds.Bottom;
                }
            }
            catch { }

            double w = Math.Max(200, width);
            double h = Math.Max(150, height);
            bool horizOk = (left + w >= vLeft + 60) && (left <= vRight - 60);
            bool vertOk = (top + h >= vTop + 40) && (top <= vBottom - 60);
            return horizOk && vertOk;
        }

        private Rect GetWindowMonitorWorkArea(Window win)
        {
            try
            {
                if (win != null)
                {
                    IntPtr hwnd = new WindowInteropHelper(win).Handle;
                    System.Windows.Forms.Screen scr = hwnd != IntPtr.Zero
                        ? System.Windows.Forms.Screen.FromHandle(hwnd)
                        : System.Windows.Forms.Screen.FromPoint(new System.Drawing.Point(
                            (int)Math.Round(double.IsNaN(win.Left) ? 0 : win.Left + (win.Width / 2)),
                            (int)Math.Round(double.IsNaN(win.Top) ? 0 : win.Top + (win.Height / 2))));
                    if (scr != null)
                    {
                        double scaleX = 1.0, scaleY = 1.0;
                        PresentationSource src = PresentationSource.FromVisual(win);
                        if (src != null && src.CompositionTarget != null)
                        {
                            scaleX = src.CompositionTarget.TransformToDevice.M11;
                            scaleY = src.CompositionTarget.TransformToDevice.M22;
                        }
                        if (scaleX <= 0.1) scaleX = 1.0;
                        if (scaleY <= 0.1) scaleY = 1.0;
                        var wa = scr.WorkingArea;
                        return new Rect(wa.Left / scaleX, wa.Top / scaleY, wa.Width / scaleX, wa.Height / scaleY);
                    }
                }
            }
            catch { }
            return SystemParameters.WorkArea;
        }

        private void InitializeWindowProps()
        {
            this.Title = "OpenWidget Desktop";
            Program.TryApplyWindowIcon(this);
            this.MinWidth = 335;
            this.MinHeight = 380;
            this.Width = savedFreeWidth;
            this.Height = savedFreeHeight;

            var workArea = SystemParameters.WorkArea;
            if (IsPositionWithinVirtualDesktop(savedLeft, savedTop, this.Width, this.Height))
            {
                this.Left = savedLeft;
                this.Top = savedTop;
            }
            else
            {
                this.Left = workArea.Right - this.Width - 14;
                this.Top = workArea.Top + 14;
                savedLeft = this.Left;
                savedTop = this.Top;
            }

            this.WindowStyle = WindowStyle.None;
            this.AllowsTransparency = true;
            this.Background = Brushes.Transparent;
            this.ResizeMode = ResizeMode.NoResize;
            this.ShowInTaskbar = false;
            this.Topmost = false;

            this.UseLayoutRounding = true;
            this.SnapsToDevicePixels = true;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
            TextOptions.SetTextRenderingMode(this, TextRenderingMode.ClearType);
            RenderOptions.SetClearTypeHint(this, ClearTypeHint.Enabled);
            this.FontFamily = new FontFamily("Segoe UI");

            windowChrome = new WindowChrome
            {
                CaptionHeight = 0,
                CornerRadius = new CornerRadius(0),
                GlassFrameThickness = new Thickness(0),
                NonClientFrameEdges = NonClientFrameEdges.None,
                ResizeBorderThickness = new Thickness(0)
            };
            WindowChrome.SetWindowChrome(this, windowChrome);

            this.SizeChanged += (s, e) =>
            {
                if (this.ActualWidth >= 335 && this.ActualHeight >= 380)
                {
                    savedFreeWidth = this.ActualWidth;
                    savedFreeHeight = this.ActualHeight;
                    if (isWindowInitialized) SaveSettings();
                }
            };

            this.LocationChanged += (s, e) =>
            {
                if (isWindowInitialized && !double.IsNaN(this.Left) && !double.IsNaN(this.Top) && this.Left > -10000 && this.Top > -10000)
                {
                    savedLeft = this.Left;
                    savedTop = this.Top;
                    SaveSettings();
                }
            };

            this.PreviewMouseLeftButtonDown += (s, e) =>
            {
                if (!isDraggable) return;
                DependencyObject dep = e.OriginalSource as DependencyObject;
                if (IsInteractiveControl(dep)) return;

                try
                {
                    IntPtr hwnd = new WindowInteropHelper(this).Handle;
                    ReleaseCapture();
                    SendMessage(hwnd, WM_NCLBUTTONDOWN, (IntPtr)HT_CAPTION, IntPtr.Zero);
                    savedLeft = this.Left;
                    savedTop = this.Top;
                    SaveSettings();
                    e.Handled = true;
                }
                catch { }
            };

            this.Loaded += (s, e) =>
            {
                IntPtr hwnd = new WindowInteropHelper(this).Handle;
                cachedMainHwnd = hwnd;
                int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
                SetWindowLong(hwnd, GWL_EXSTYLE, exStyle | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE);

                AttachToDesktopShell(hwnd);
                try { AddClipboardFormatListener(hwnd); } catch { }

                RegisterHotKey(hwnd, HOTKEY_ID_MIC, MOD_CONTROL | MOD_SHIFT, VK_M);
                HwndSource source = HwndSource.FromHwnd(hwnd);
                source.AddHook(WndProc);

                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (!hasSavedDimensions)
                    {
                        FitHeightToContentIfCompact();
                    }
                    isWindowInitialized = true;
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        if (showCalendarWidget) InitializeCalendarWidget();
                        if (showTimerWidget) InitializeTimerWidget();
                    }), DispatcherPriority.ApplicationIdle);
                    Task.Run(async () =>
                    {
                        await Task.Delay(2500);
                        TrimProcessMemory();
                    });
                }), DispatcherPriority.Loaded);
            };

            this.StateChanged += (s, e) =>
            {
                if (this.WindowState == WindowState.Minimized)
                {
                    this.WindowState = WindowState.Normal;
                }
            };

            this.Closed += (s, e) =>
            {
                if (isWindowInitialized && IsPositionWithinVirtualDesktop(this.Left, this.Top, this.ActualWidth, this.ActualHeight))
                {
                    savedLeft = this.Left;
                    savedTop = this.Top;
                }
                if (calendarWindow != null && isCalWindowInitialized && IsPositionWithinVirtualDesktop(calendarWindow.Left, calendarWindow.Top, calendarWindow.ActualWidth, calendarWindow.ActualHeight))
                {
                    savedCalLeft = calendarWindow.Left;
                    savedCalTop = calendarWindow.Top;
                }
                if (timerWindow != null && isTimerWindowInitialized && IsPositionWithinVirtualDesktop(timerWindow.Left, timerWindow.Top, timerWindow.ActualWidth, timerWindow.ActualHeight))
                {
                    savedTimerLeft = timerWindow.Left;
                    savedTimerTop = timerWindow.Top;
                }
                SaveTimerActivityData();
                SaveSettings();
                try
                {
                    if (calendarWindow != null)
                    {
                        calendarWindow.Close();
                        calendarWindow = null;
                    }
                    if (timerWindow != null)
                    {
                        timerWindow.Close();
                        timerWindow = null;
                    }
                }
                catch { }
                try
                {
                    IntPtr hwnd = new WindowInteropHelper(this).Handle;
                    RemoveClipboardFormatListener(hwnd);
                    UnregisterHotKey(hwnd, HOTKEY_ID_MIC);
                }
                catch { }
                try { if (nvmlInitialized) NvmlNative.nvmlShutdown(); } catch { }
                CleanupMonitorHandles();
                try { if (sharedPing != null) sharedPing.Dispose(); } catch { }
                if (trayIcon != null)
                {
                    trayIcon.Visible = false;
                    trayIcon.Dispose();
                }
            };
        }

        private void AttachToDesktopShell(IntPtr hwnd)
        {
            try
            {
                // Place widget on the desktop layer (bottom of normal windows) without binding GWLP_HWNDPARENT to WorkerW
                SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
            }
            catch { }
        }

        private bool IsWindowAbove(IntPtr hwnd, IntPtr targetHwnd)
        {
            if (hwnd == IntPtr.Zero || targetHwnd == IntPtr.Zero || hwnd == targetHwnd) return false;
            int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
            if ((exStyle & WS_EX_TOPMOST) != 0) return true;
            IntPtr cur = GetWindow(targetHwnd, GW_HWNDPREV);
            int steps = 0;
            while (cur != IntPtr.Zero && steps < 64)
            {
                if (cur == hwnd) return true;
                cur = GetWindow(cur, GW_HWNDPREV);
                steps++;
            }
            return false;
        }

        private void SendWidgetToDesktopBottom(IntPtr hwnd)
        {
            SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
            SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
        }

        private void CheckAndEnforceShowDesktopImmunity()
        {
            if (userHidden) return;
            try
            {
                IntPtr hwnd = cachedMainHwnd != IntPtr.Zero ? cachedMainHwnd : (cachedMainHwnd = new WindowInteropHelper(this).Handle);
                if (hwnd == IntPtr.Zero) return;

                IntPtr calHwnd = (calendarWindow != null && showCalendarWidget)
                    ? (cachedCalHwnd != IntPtr.Zero ? cachedCalHwnd : (cachedCalHwnd = new WindowInteropHelper(calendarWindow).Handle))
                    : IntPtr.Zero;

                IntPtr timerHwnd = (timerWindow != null && showTimerWidget)
                    ? (cachedTimerHwnd != IntPtr.Zero ? cachedTimerHwnd : (cachedTimerHwnd = new WindowInteropHelper(timerWindow).Handle))
                    : IntPtr.Zero;

                IntPtr fg = GetForegroundWindow();
                if (fg != IntPtr.Zero)
                {
                    if (fg == lastVerifiedFgHwnd && !isShowDesktopActive)
                        return;

                    fgClassBuilder.Length = 0;
                    GetClassName(fg, fgClassBuilder, 64);
                    string cls = fgClassBuilder.ToString();
                    if (cls == "WorkerW" || cls == "Progman")
                    {
                        lastVerifiedFgHwnd = IntPtr.Zero;
                        if (!isShowDesktopActive)
                        {
                            isShowDesktopActive = true;
                            SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
                            if (calHwnd != IntPtr.Zero)
                                SetWindowPos(calHwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
                            if (timerHwnd != IntPtr.Zero)
                                SetWindowPos(timerHwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
                        }
                    }
                    else if (fg != hwnd && fg != calHwnd && fg != timerHwnd && cls != "Shell_TrayWnd" && cls != "NotifyIconOverflowWindow")
                    {
                        if (isShowDesktopActive)
                        {
                            isShowDesktopActive = false;
                            SendWidgetToDesktopBottom(hwnd);
                            if (calHwnd != IntPtr.Zero) SendWidgetToDesktopBottom(calHwnd);
                            if (timerHwnd != IntPtr.Zero) SendWidgetToDesktopBottom(timerHwnd);
                        }
                        else
                        {
                            if (IsWindowAbove(hwnd, fg)) SendWidgetToDesktopBottom(hwnd);
                            if (calHwnd != IntPtr.Zero && IsWindowAbove(calHwnd, fg)) SendWidgetToDesktopBottom(calHwnd);
                            if (timerHwnd != IntPtr.Zero && IsWindowAbove(timerHwnd, fg)) SendWidgetToDesktopBottom(timerHwnd);
                        }
                        lastVerifiedFgHwnd = fg;
                    }
                }
            }
            catch { }
        }

        private static void TrimProcessMemory()
        {
            try
            {
                GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, false);
                GC.WaitForPendingFinalizers();
                SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, (IntPtr)(-1), (IntPtr)(-1));
            }
            catch { }
        }

        private bool IsInteractiveControl(DependencyObject dep)
        {
            while (dep != null && dep != this)
            {
                if (dep is ButtonBase || dep is Slider || dep is Thumb || dep is TextBox)
                    return true;
                if (dep is FrameworkElement)
                {
                    FrameworkElement fe = (FrameworkElement)dep;
                    if (fe.Tag != null && fe.Tag.ToString() == "Interactive")
                        return true;
                }
                dep = VisualTreeHelper.GetParent(dep);
            }
            return false;
        }

        private void FitHeightToContentIfCompact()
        {
            if (outerBorder != null && outerBorder.Child is Grid)
            {
                Grid g = (Grid)outerBorder.Child;
                if (g.Children.Count > 0 && g.Children[0] is ScrollViewer)
                {
                    ScrollViewer sv = (ScrollViewer)g.Children[0];
                    if (sv.Content is FrameworkElement)
                    {
                        FrameworkElement content = (FrameworkElement)sv.Content;
                        content.Measure(new Size(this.ActualWidth - 36, double.PositiveInfinity));
                        double desiredH = content.DesiredSize.Height + 42;
                        Rect workArea = GetWindowMonitorWorkArea(this);
                        double targetH = Math.Min(workArea.Height - 28, Math.Max(390, desiredH));
                        this.Height = targetH;
                        savedFreeHeight = targetH;
                    }
                }
            }
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_MOUSEACTIVATE = 0x0021;
            const int MA_NOACTIVATE = 3;
            const int WM_HOTKEY = 0x0312;
            const int WM_SYSCOMMAND = 0x0112;
            const int SC_MINIMIZE = 0xF020;
            const int WM_WINDOWPOSCHANGING = 0x0046;
            const uint SWP_HIDEWINDOW = 0x0080;

            if (msg == WM_MOUSEACTIVATE)
            {
                handled = true;
                return new IntPtr(MA_NOACTIVATE);
            }
            else if (msg == WM_HOTKEY && wParam.ToInt32() == HOTKEY_ID_MIC)
            {
                ToggleMicrophoneMute();
                handled = true;
            }
            else if (msg == WM_CLIPBOARDUPDATE)
            {
                CheckClipboardChanges();
            }
            else if (msg == WM_SYSCOMMAND && (wParam.ToInt32() & 0xFFF0) == SC_MINIMIZE)
            {
                handled = true;
            }
            else if (msg == WM_WINDOWPOSCHANGING && !userHidden && lParam != IntPtr.Zero)
            {
                try
                {
                    WINDOWPOS wp = (WINDOWPOS)Marshal.PtrToStructure(lParam, typeof(WINDOWPOS));
                    bool modified = false;
                    if ((wp.flags & SWP_HIDEWINDOW) != 0)
                    {
                        wp.flags &= ~SWP_HIDEWINDOW;
                        wp.flags |= SWP_SHOWWINDOW;
                        modified = true;
                    }
                    // Prevent mouse clicks on the widget from raising it above normal windows (browsers, apps)
                    if (!isShowDesktopActive && (wp.flags & SWP_NOZORDER) == 0 && wp.hwndInsertAfter == IntPtr.Zero)
                    {
                        wp.hwndInsertAfter = HWND_BOTTOM;
                        modified = true;
                    }
                    if (modified)
                    {
                        Marshal.StructureToPtr(wp, lParam, true);
                    }
                }
                catch { }
            }
            return IntPtr.Zero;
        }

        private static readonly Dictionary<string, SolidColorBrush> brushCache = new Dictionary<string, SolidColorBrush>(StringComparer.OrdinalIgnoreCase);

        private Brush HexBrush(string hex)
        {
            SolidColorBrush b;
            if (!brushCache.TryGetValue(hex, out b))
            {
                b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex);
                if (b.CanFreeze) b.Freeze();
                brushCache[hex] = b;
            }
            return b;
        }

        private Color ParseColor(string hex)
        {
            return (Color)ColorConverter.ConvertFromString(hex);
        }

        private Color BlendColors(Color baseColor, Color tint, double tintRatio, byte alpha)
        {
            byte r = (byte)Math.Max(0, Math.Min(255, baseColor.R * (1 - tintRatio) + tint.R * tintRatio));
            byte g = (byte)Math.Max(0, Math.Min(255, baseColor.G * (1 - tintRatio) + tint.G * tintRatio));
            byte b = (byte)Math.Max(0, Math.Min(255, baseColor.B * (1 - tintRatio) + tint.B * tintRatio));
            return Color.FromArgb(alpha, r, g, b);
        }

        public void ApplyTheme(string newAccentHex, int newOpacityPct)
        {
            try
            {
                Color accent = ParseColor(newAccentHex);
                accentColorHex = newAccentHex;
                bgOpacityPercent = Math.Max(30, Math.Min(100, newOpacityPct));

                byte mainAlpha = (byte)Math.Round((bgOpacityPercent / 100.0) * 255.0);
                byte cardAlpha = (byte)Math.Round((Math.Min(100, bgOpacityPercent * 0.65) / 100.0) * 255.0);
                byte subAlpha = (byte)Math.Round((Math.Min(100, bgOpacityPercent * 0.55) / 100.0) * 255.0);

                Color darkTop = BlendColors(Color.FromRgb(22, 19, 17), accent, 0.08, mainAlpha);
                Color darkBottom = BlendColors(Color.FromRgb(28, 24, 21), accent, 0.12, mainAlpha);
                Color outerBorderCol = BlendColors(Color.FromRgb(56, 48, 42), accent, 0.35, 220);

                Color cardBgCol = BlendColors(Color.FromRgb(34, 29, 26), accent, 0.10, cardAlpha);
                Color cardBorderCol = BlendColors(Color.FromRgb(64, 54, 48), accent, 0.28, 190);

                Color subBgCol = BlendColors(Color.FromRgb(42, 35, 31), accent, 0.12, subAlpha);
                Color subBorderCol = BlendColors(Color.FromRgb(74, 62, 55), accent, 0.30, 180);

                SolidColorBrush accentBrush = new SolidColorBrush(accent); accentBrush.Freeze();
                SolidColorBrush cardBgBrush = new SolidColorBrush(cardBgCol); cardBgBrush.Freeze();
                SolidColorBrush cardBorderBrush = new SolidColorBrush(cardBorderCol); cardBorderBrush.Freeze();
                SolidColorBrush subBgBrush = new SolidColorBrush(subBgCol); subBgBrush.Freeze();
                SolidColorBrush subBorderBrush = new SolidColorBrush(subBorderCol); subBorderBrush.Freeze();

                if (outerBorder != null)
                {
                    LinearGradientBrush grad = new LinearGradientBrush(darkTop, darkBottom, new Point(0, 0), new Point(0, 1));
                    grad.Freeze();
                    outerBorder.Background = grad;
                    SolidColorBrush ob = new SolidColorBrush(outerBorderCol); ob.Freeze();
                    outerBorder.BorderBrush = ob;
                }

                foreach (Border card in glassCards)
                {
                    card.Background = cardBgBrush;
                    card.BorderBrush = cardBorderBrush;
                }

                foreach (Border box in subBoxes)
                {
                    box.Background = subBgBrush;
                    box.BorderBrush = subBorderBrush;
                }

                if (weatherIconBox != null)
                {
                    weatherIconBox.Background = new SolidColorBrush(BlendColors(Color.FromRgb(38, 32, 28), accent, 0.22, 210));
                    weatherIconBox.BorderBrush = new SolidColorBrush(BlendColors(Color.FromRgb(60, 50, 44), accent, 0.45, 220));
                }

                foreach (TextBlock tb in accentTextBlocks)
                {
                    tb.Foreground = accentBrush;
                }

                foreach (Polyline poly in accentSparklines)
                {
                    poly.Stroke = accentBrush;
                }

                foreach (Border fill in accentBarFills)
                {
                    fill.Background = accentBrush;
                }

                for (int i = 0; i < monitorSliderContainers.Count && i < sliderMonitors.Count; i++)
                {
                    if (monitorSliderContainers[i] != null && sliderMonitors[i] != null)
                    {
                        int idx = i;
                        double curVal = sliderMonitors[i].Value;
                        Slider ms = CreateModernSlider(accentColorHex, curVal, 0, "6,0,8,0");
                        ms.ValueChanged += (s, e) => OnMonitorSliderValueChanged(idx, e.NewValue);
                        AttachMonitorSliderWheel(ms, idx);
                        sliderMonitors[i] = ms;
                        monitorSliderContainers[i].Child = ms;
                    }
                }

                UpdateMonitorLinkButtonUi();
                UpdateDraggableButtonUi();
                ApplyCalendarWidgetTheme();
                ApplyTimerWidgetTheme();

                if (toastBorder != null)
                {
                    toastBorder.Background = new SolidColorBrush(BlendColors(Color.FromRgb(30, 26, 24), accent, 0.75, 240));
                }

                SaveSettings();
            }
            catch { }
        }

        private void BuildUserInterface()
        {
            outerBorder = new Border
            {
                CornerRadius = new CornerRadius(16),
                BorderThickness = new Thickness(1),
                Margin = new Thickness(4)
            };
            DropShadowEffect shadow = new DropShadowEffect
            {
                Color = Colors.Black,
                BlurRadius = 14,
                ShadowDepth = 2,
                Opacity = 0.60
            };
            shadow.Freeze();
            outerBorder.Effect = shadow;

            Grid outerGrid = new Grid();

            ScrollViewer scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Hidden,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Padding = new Thickness(14, 12, 14, 14)
            };

            StackPanel rootStack = new StackPanel();

            // 1. TOP HEADER (Clock + Date + Uptime + Icon-Only Mic + Icon-Only Lock + Settings)
            Grid headerGrid = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtClockAndUptime = new TextBlock
            {
                Text = "05:50 · 6 Kas Cum  Açık: 2s 15dk",
                Foreground = HexBrush("#F5EFEA"),
                FontSize = 11.5,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(txtClockAndUptime, 0);
            headerGrid.Children.Add(txtClockAndUptime);

            btnMicHeader = CreateStyledIconButton("#26201D", "Transparent", L("Mikrofonu Sustur / Aç (Ctrl+Shift+M)", "Mute / Unmute Microphone (Ctrl+Shift+M)"));
            btnMicHeader.Margin = new Thickness(4, 0, 4, 0);
            btnMicHeader.Padding = new Thickness(7, 3, 7, 3);
            txtMicHeaderIcon = new TextBlock { Text = "🎙", FontSize = 11.5, Foreground = HexBrush("#FAF6F2"), VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
            btnMicHeader.Content = txtMicHeaderIcon;
            btnMicHeader.Click += (s, e) => ToggleMicrophoneMute();
            Grid.SetColumn(btnMicHeader, 1);
            headerGrid.Children.Add(btnMicHeader);

            btnLockDrag = CreateStyledIconButton("#26201D", "Transparent", L("Sabit Mod (Taşınabilir ve Boyutlandırılabilir Modu Açmak İçin Tıklayın)", "Locked Mode (Click to Enable Draggable & Resizable Mode)"));
            btnLockDrag.Padding = new Thickness(7, 3, 7, 3);
            btnLockDrag.Margin = new Thickness(0, 0, 4, 0);
            btnLockDrag.Content = new TextBlock { Text = "📌", FontSize = 11.5, Foreground = HexBrush("#C7B9AE"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            btnLockDrag.Click += (s, e) => ToggleDraggableMode();
            Grid.SetColumn(btnLockDrag, 2);
            headerGrid.Children.Add(btnLockDrag);

            btnSettingsHeader = CreateStyledIconButton("#26201D", "Transparent", L("Widget Ayarları (Dil, Konum, Tema Rengi & Opaklık)", "Widget Settings (Language, Location, Theme & Opacity)"));
            btnSettingsHeader.Padding = new Thickness(7, 3, 7, 3);
            btnSettingsHeader.Content = new TextBlock { Text = "⚙", FontSize = 11.5, Foreground = HexBrush("#C7B9AE") };
            btnSettingsHeader.Click += (s, e) => OpenSettingsWindow();
            Grid.SetColumn(btnSettingsHeader, 3);
            headerGrid.Children.Add(btnSettingsHeader);

            rootStack.Children.Add(headerGrid);

            modulesHostPanel = new StackPanel();
            rootStack.Children.Add(modulesHostPanel);

            // 2. WEATHER SECTION
            secContainerWeather = new StackPanel();
            Grid weatherTitleGrid = new Grid { Margin = new Thickness(0, 2, 0, 6) };
            weatherTitleGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            weatherTitleGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel weatherTitleLeft = new StackPanel { Orientation = Orientation.Horizontal };
            weatherTitleLeft.Children.Add(new TextBlock { Text = "☀ ", Foreground = HexBrush("#C7B9AE"), FontSize = 12, VerticalAlignment = VerticalAlignment.Center });
            txtWeatherSectionTitle = new TextBlock { Text = L("Hava Durumu", "Weather"), Foreground = HexBrush("#E6DDD6"), FontSize = 12, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            weatherTitleLeft.Children.Add(txtWeatherSectionTitle);
            Grid.SetColumn(weatherTitleLeft, 0);
            weatherTitleGrid.Children.Add(weatherTitleLeft);

            txtLocationBadge = new TextBlock
            {
                Text = locationName,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Cursor = Cursors.Hand,
                Tag = "Interactive",
                ToolTip = L("Hava durumunu yenilemek için sol tıklayın, konumu değiştirmek için Ayarlar (⚙) menüsünü açın", "Left-click to refresh weather, open Settings (⚙) to change location")
            };
            accentTextBlocks.Add(txtLocationBadge);
            txtLocationBadge.MouseLeftButtonDown += (s, e) => Task.Run(() => FetchWeatherAsync());
            Grid.SetColumn(txtLocationBadge, 1);
            weatherTitleGrid.Children.Add(txtLocationBadge);
            secContainerWeather.Children.Add(weatherTitleGrid);

            Border weatherCard = CreateGlassCard();
            StackPanel weatherStack = new StackPanel();

            Grid mainWeatherRow = new Grid { Margin = new Thickness(2, 0, 2, 10) };
            mainWeatherRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            mainWeatherRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            mainWeatherRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtWeatherTemp = new TextBlock
            {
                Text = "14°",
                Foreground = Brushes.White,
                FontSize = 30,
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 12, 0)
            };
            Grid.SetColumn(txtWeatherTemp, 0);
            mainWeatherRow.Children.Add(txtWeatherTemp);

            StackPanel descStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            txtWeatherDesc = new TextBlock { Text = L("Parçalı Bulutlu", "Partly Cloudy"), Foreground = HexBrush("#FAF6F2"), FontSize = 13.5, FontWeight = FontWeights.SemiBold };
            txtWeatherFeels = new TextBlock { Text = L("Hissedilen 13°C", "Feels like 13°C"), Foreground = HexBrush("#B8A99E"), FontSize = 11.5, Margin = new Thickness(0, 2, 0, 0) };
            descStack.Children.Add(txtWeatherDesc);
            descStack.Children.Add(txtWeatherFeels);
            Grid.SetColumn(descStack, 1);
            mainWeatherRow.Children.Add(descStack);

            weatherIconBox = new Border
            {
                Width = 38,
                Height = 38,
                CornerRadius = new CornerRadius(10),
                BorderThickness = new Thickness(1)
            };
            txtWeatherMainIcon = new TextBlock
            {
                Text = "☀",
                FontSize = 19,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            accentTextBlocks.Add(txtWeatherMainIcon);
            weatherIconBox.Child = txtWeatherMainIcon;
            Grid.SetColumn(weatherIconBox, 2);
            mainWeatherRow.Children.Add(weatherIconBox);
            weatherStack.Children.Add(mainWeatherRow);

            UniformGrid metricsGrid = new UniformGrid { Columns = 3, Margin = new Thickness(0, 0, 0, 10) };
            metricsGrid.Children.Add(CreateWeatherMetricBox(L("💧 Nem", "💧 Humidity"), "%75", out txtHumidityLabel, out txtWeatherHumidity, new Thickness(0, 0, 4, 0)));
            metricsGrid.Children.Add(CreateWeatherMetricBox(L("💨 Rüzgar", "💨 Wind"), L("10 km/s", "10 km/h"), out txtWindLabel, out txtWeatherWind, new Thickness(2, 0, 2, 0)));
            metricsGrid.Children.Add(CreateWeatherMetricBox(L("🌧 Yağış", "🌧 Rain"), "0 mm", out txtRainLabel, out txtWeatherRain, new Thickness(4, 0, 0, 0)));
            weatherStack.Children.Add(metricsGrid);

            weatherStack.Children.Add(new Border { Height = 1, Background = HexBrush("#3D322C"), Margin = new Thickness(0, 0, 0, 8) });

            UniformGrid forecastGrid = new UniformGrid { Columns = 3 };
            string[] defaultDays = { L("Bugün", "Today"), L("Yarın", "Tomorrow"), L("Pazar", "Sun") };
            for (int i = 0; i < 3; i++)
            {
                StackPanel dayBox = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
                txtDayNames[i] = new TextBlock { Text = defaultDays[i], Foreground = HexBrush("#B8A99E"), FontSize = 11, HorizontalAlignment = HorizontalAlignment.Center };
                txtDayIcons[i] = new TextBlock { Text = "⛅", FontSize = 13, Margin = new Thickness(0, 3, 0, 3), HorizontalAlignment = HorizontalAlignment.Center };
                accentTextBlocks.Add(txtDayIcons[i]);
                txtDayTemps[i] = new TextBlock { Text = "8° / 16°", Foreground = HexBrush("#FAF6F2"), FontSize = 11.5, FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Center };
                dayBox.Children.Add(txtDayNames[i]);
                dayBox.Children.Add(txtDayIcons[i]);
                dayBox.Children.Add(txtDayTemps[i]);
                forecastGrid.Children.Add(dayBox);
            }
            weatherStack.Children.Add(forecastGrid);
            weatherCard.Child = weatherStack;
            secContainerWeather.Children.Add(weatherCard);
            RefreshWeatherTemperatureUi();

            // 2B. MONITOR BRIGHTNESS SECTION (Auto-Detects Monitors, HDR SDRWhiteLevel + DDC/CI)
            secContainerMonitors = new StackPanel { Visibility = Visibility.Collapsed };
            monHeaderGrid = new Grid { Margin = new Thickness(0, 12, 0, 6), Cursor = Cursors.Hand, Tag = "Interactive" };
            monHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            monHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            monHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            monHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel monHeaderLeft = new StackPanel { Orientation = Orientation.Horizontal };
            monHeaderLeft.Children.Add(new TextBlock { Text = "🖥 ", Foreground = HexBrush("#B8A99E"), FontSize = 11.5, VerticalAlignment = VerticalAlignment.Center });
            txtMonitorSectionTitle = new TextBlock { Text = L("Monitör Parlaklığı", "Monitor Brightness"), Foreground = HexBrush("#E6DDD6"), FontSize = 12.5, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            monHeaderLeft.Children.Add(txtMonitorSectionTitle);
            Grid.SetColumn(monHeaderLeft, 0);
            monHeaderGrid.Children.Add(monHeaderLeft);

            btnMonitorLink = CreateStyledIconButton("#26201D", "#443831", L("Monitörlerin parlaklığını birlikte (senkron) değiştir", "Sync brightness across all monitors"));
            btnMonitorLink.Padding = new Thickness(6, 2, 6, 2);
            btnMonitorLink.Margin = new Thickness(0, 0, 4, 0);
            btnMonitorLink.Click += (s, e) =>
            {
                e.Handled = true;
                monitorLinkSync = !monitorLinkSync;
                UpdateMonitorLinkButtonUi();
                SaveSettings();
                if (monitorLinkSync && sliderMonitors.Count > 0 && sliderMonitors[0] != null)
                {
                    SetMonitorBrightnessFromUi(0, (int)Math.Round(sliderMonitors[0].Value), true);
                }
            };
            Grid.SetColumn(btnMonitorLink, 1);
            monHeaderGrid.Children.Add(btnMonitorLink);

            btnRefreshMonitors = CreateStyledIconButton("Transparent", "Transparent", L("Monitör parlaklıklarını yeniden oku", "Re-read monitor brightness levels"));
            btnRefreshMonitors.Padding = new Thickness(5, 1, 5, 1);
            btnRefreshMonitors.Margin = new Thickness(0, 0, 4, 0);
            btnRefreshMonitors.Content = new TextBlock { Text = "↻", Foreground = HexBrush("#B8A99E"), FontSize = 12, FontWeight = FontWeights.Bold };
            btnRefreshMonitors.Click += (s, e) =>
            {
                e.Handled = true;
                Task.Run(() => DiscoverAndSyncMonitors(true));
                ShowToast(L("Monitör parlaklıkları okunuyor...", "Reading monitor brightness..."));
            };
            Grid.SetColumn(btnRefreshMonitors, 2);
            monHeaderGrid.Children.Add(btnRefreshMonitors);

            TextBlock monChevron = new TextBlock { Text = "⌄", Foreground = HexBrush("#B8A99E"), FontSize = 13, FontWeight = FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(monChevron, 3);
            monHeaderGrid.Children.Add(monChevron);

            monitorCard = CreateGlassCard();
            monHeaderGrid.MouseLeftButtonDown += (s, e) =>
            {
                if (monitorCard.Visibility == Visibility.Visible)
                {
                    monitorCard.Visibility = Visibility.Collapsed;
                    monChevron.Text = "›";
                }
                else
                {
                    monitorCard.Visibility = Visibility.Visible;
                    monChevron.Text = "⌄";
                }
            };
            secContainerMonitors.Children.Add(monHeaderGrid);

            StackPanel monCardStack = new StackPanel();
            monRowsHostStack = new StackPanel();
            monCardStack.Children.Add(monRowsHostStack);

            UniformGrid monPresetGrid = new UniformGrid { Columns = 4, Margin = new Thickness(0, 4, 0, 0) };
            int[] monPresetVals = { 15, 40, 75, 100 };
            string[] monPresetIcons = { "🌙 ", "🔉 ", "🔆 ", "☀ " };
            for (int i = 0; i < 4; i++)
            {
                int targetVal = monPresetVals[i];
                string iconPrefix = monPresetIcons[i];
                Button b = CreateStyledIconButton("#26201D", "#443831", L("Tüm monitörleri %", "Set all monitors to ") + targetVal + (IsEn ? "%" : " yap"));
                b.Margin = new Thickness(i == 0 ? 0 : 2, 0, i == 3 ? 0 : 2, 0);
                b.Padding = new Thickness(2, 3, 2, 3);
                b.Content = new TextBlock { Text = iconPrefix + (IsEn ? (targetVal + "%") : ("%" + targetVal)), Foreground = HexBrush("#E6DDD6"), FontSize = 10, HorizontalAlignment = HorizontalAlignment.Center };
                b.Click += (s, e) => SetMonitorBrightnessFromUi(0, targetVal, true);
                monPresetGrid.Children.Add(b);
            }
            monCardStack.Children.Add(monPresetGrid);
            monitorCard.Child = monCardStack;
            secContainerMonitors.Children.Add(monitorCard);
            UpdateMonitorLinkButtonUi();

            // 3. WIRELESS DEVICES SECTION (Auto-Discovers Connected Mouse, Keyboard, Headset, Controller)
            secContainerWireless = new StackPanel { Visibility = Visibility.Collapsed };
            wirelessHeaderGrid = new Grid
            {
                Margin = new Thickness(0, 12, 0, 4),
                Cursor = Cursors.Hand,
                Tag = "Interactive"
            };
            wirelessHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            wirelessHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            wirelessHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel wirelessTitleLeft = new StackPanel { Orientation = Orientation.Horizontal };
            wirelessTitleLeft.Children.Add(new TextBlock { Text = "🔋 ", Foreground = HexBrush("#B8A99E"), FontSize = 11.5, VerticalAlignment = VerticalAlignment.Center });
            txtWirelessSectionTitle = new TextBlock { Text = L("Kablosuz Cihazlar", "Wireless Devices"), Foreground = HexBrush("#E6DDD6"), FontSize = 12.5, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            wirelessTitleLeft.Children.Add(txtWirelessSectionTitle);
            Grid.SetColumn(wirelessTitleLeft, 0);
            wirelessHeaderGrid.Children.Add(wirelessTitleLeft);

            btnRefreshWireless = CreateStyledIconButton("Transparent", "Transparent", L("Kablosuz cihaz şarjlarını şimdi yenile", "Refresh wireless device battery levels now"));
            btnRefreshWireless.Padding = new Thickness(5, 1, 5, 1);
            btnRefreshWireless.Margin = new Thickness(0, 0, 4, 0);
            btnRefreshWireless.Content = new TextBlock { Text = "↻", Foreground = HexBrush("#B8A99E"), FontSize = 12, FontWeight = FontWeights.Bold };
            btnRefreshWireless.Click += (s, e) =>
            {
                e.Handled = true;
                Task.Run(() => PollWirelessDevicesAsync());
                ShowToast(L("Kablosuz cihazlar taranıyor...", "Scanning wireless devices..."));
            };
            Grid.SetColumn(btnRefreshWireless, 1);
            wirelessHeaderGrid.Children.Add(btnRefreshWireless);

            TextBlock wirelessChevron = new TextBlock { Text = "⌄", Foreground = HexBrush("#B8A99E"), FontSize = 13, FontWeight = FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(wirelessChevron, 2);
            wirelessHeaderGrid.Children.Add(wirelessChevron);

            panelWirelessContent = new StackPanel();
            wirelessHeaderGrid.MouseLeftButtonDown += (s, e) =>
            {
                if (panelWirelessContent.Visibility == Visibility.Visible)
                {
                    panelWirelessContent.Visibility = Visibility.Collapsed;
                    wirelessChevron.Text = "›";
                }
                else
                {
                    panelWirelessContent.Visibility = Visibility.Visible;
                    wirelessChevron.Text = "⌄";
                    Task.Run(() => PollWirelessDevicesAsync());
                }
            };
            secContainerWireless.Children.Add(wirelessHeaderGrid);
            secContainerWireless.Children.Add(panelWirelessContent);

            // 4. TELEMETRY SECTION
            secContainerTelemetry = new StackPanel();
            Grid teleHeader = new Grid { Margin = new Thickness(0, 12, 0, 4), Cursor = Cursors.Hand, Tag = "Interactive" };
            teleHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            teleHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            txtTelemetrySectionTitle = new TextBlock { Text = L("Telemetri", "Telemetry"), Foreground = HexBrush("#E6DDD6"), FontSize = 12.5, FontWeight = FontWeights.Medium };
            teleHeader.Children.Add(txtTelemetrySectionTitle);
            TextBlock teleChevron = new TextBlock { Text = "⌄", Foreground = HexBrush("#B8A99E"), FontSize = 13, FontWeight = FontWeights.Bold };
            Grid.SetColumn(teleChevron, 1);
            teleHeader.Children.Add(teleChevron);

            panelTelemetryContent = new StackPanel();
            teleHeader.MouseLeftButtonDown += (s, e) =>
            {
                if (panelTelemetryContent.Visibility == Visibility.Visible)
                {
                    panelTelemetryContent.Visibility = Visibility.Collapsed;
                    teleChevron.Text = "›";
                }
                else
                {
                    panelTelemetryContent.Visibility = Visibility.Visible;
                    teleChevron.Text = "⌄";
                }
            };
            secContainerTelemetry.Children.Add(teleHeader);

            rowTeleCpu = CreateTelemetrySparkRow("⚙", L("İşlemci (CPU)", "Processor (CPU)"), "46°C • " + cpuShortName, true, out txtCpuRowLabel, out txtCpuDetail, out sparkCpu, out txtCpuPct);
            panelTelemetryContent.Children.Add(rowTeleCpu);

            rowTeleRam = CreateTelemetryBarRow("📟", L("Bellek (RAM)", "Memory (RAM)"), "8.0 / 16 GB", true, out txtRamRowLabel, out txtRamDetail, out barRamFill, out txtRamPct);
            panelTelemetryContent.Children.Add(rowTeleRam);

            rowTeleGpu = CreateTelemetrySparkRow("🎮", L("Ekran Kartı (GPU)", "Graphics (GPU)"), "45°C • " + gpuModelName, true, out txtGpuRowLabel, out txtGpuDetail, out sparkGpu, out txtGpuPct);
            panelTelemetryContent.Children.Add(rowTeleGpu);

            rowTeleVram = CreateTelemetryBarRow("🎞", L("Video Belleği (VRAM)", "Video Memory (VRAM)"), "1.5 / 8 GB", true, out txtVramRowLabel, out txtVramDetail, out barVramFill, out txtVramPct);
            panelTelemetryContent.Children.Add(rowTeleVram);

            // Network Row
            rowTeleNet = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            rowTeleNet.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            rowTeleNet.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            rowTeleNet.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            rowTeleNet.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel netLeft = new StackPanel { Orientation = Orientation.Horizontal };
            netLeft.Children.Add(CreateMiniIconBadge("⇄"));
            txtNetRowLabel = new TextBlock { Text = L("Ağ Trafiği", "Network"), Foreground = HexBrush("#F5EFEA"), FontSize = 12, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            netLeft.Children.Add(txtNetRowLabel);
            Grid.SetColumn(netLeft, 0);
            rowTeleNet.Children.Add(netLeft);

            txtNetSpeed = new TextBlock
            {
                Text = "↓ 0 Kbps ↑ 0 Kbps",
                Foreground = HexBrush("#B8A99E"),
                FontSize = 11,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(4, 0, 6, 0)
            };
            Grid.SetColumn(txtNetSpeed, 1);
            rowTeleNet.Children.Add(txtNetSpeed);

            Border netBadgeBorder = new Border
            {
                CornerRadius = new CornerRadius(4),
                Background = HexBrush("#2A211C"),
                BorderBrush = HexBrush("#4F3B30"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(5, 1, 5, 1),
                Margin = new Thickness(0, 0, 6, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            subBoxes.Add(netBadgeBorder);
            txtNetBadge = new TextBlock { Text = L("Harika", "Great"), FontSize = 10, FontWeight = FontWeights.SemiBold };
            accentTextBlocks.Add(txtNetBadge);
            netBadgeBorder.Child = txtNetBadge;
            Grid.SetColumn(netBadgeBorder, 2);
            rowTeleNet.Children.Add(netBadgeBorder);

            txtNetPing = new TextBlock
            {
                Text = "10 ms",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Width = 48,
                TextAlignment = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };
            accentTextBlocks.Add(txtNetPing);
            Grid.SetColumn(txtNetPing, 3);
            rowTeleNet.Children.Add(txtNetPing);
            panelTelemetryContent.Children.Add(rowTeleNet);

            // Dynamic Fixed Drives (Automatically adapts to whatever disks C:, D:, E: the user has!)
            for (int i = 0; i < fixedDrives.Count; i++)
            {
                DriveInfo d = fixedDrives[i];
                string dName = d.Name.TrimEnd('\\');
                TextBlock rowLbl;
                TextBlock det;
                Border fill;
                TextBlock pct;
                Grid dRow = CreateTelemetryBarRow(i == 0 ? "💾" : "💿", dName + L(" Diski", " Drive"), L("... GB Boş", "... GB Free"), true, out rowLbl, out det, out fill, out pct);
                panelTelemetryContent.Children.Add(dRow);
                rowsTeleDisks.Add(dRow);
                diskRowLabels.Add(rowLbl);
                diskDetailBlocks.Add(det);
                diskFillBars.Add(fill);
                diskPctBlocks.Add(pct);
            }

            secContainerTelemetry.Children.Add(panelTelemetryContent);

            // 5. CLIPBOARD HISTORY SECTION
            secContainerClipboard = new StackPanel();
            Grid clipHeader = new Grid { Margin = new Thickness(0, 12, 0, 6) };
            clipHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            clipHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            clipHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel clipTitleLeft = new StackPanel { Orientation = Orientation.Horizontal };
            clipTitleLeft.Children.Add(new TextBlock { Text = "📋 ", Foreground = HexBrush("#B8A99E"), FontSize = 12, VerticalAlignment = VerticalAlignment.Center });
            txtClipboardSectionTitle = new TextBlock { Text = L("Pano Geçmişi", "Clipboard History"), Foreground = HexBrush("#E6DDD6"), FontSize = 12.5, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            clipTitleLeft.Children.Add(txtClipboardSectionTitle);
            Grid.SetColumn(clipTitleLeft, 0);
            clipHeader.Children.Add(clipTitleLeft);

            btnClearClip = CreateStyledIconButton("Transparent", "Transparent", L("Pano geçmişini temizle", "Clear clipboard history"));
            btnClearClip.Padding = new Thickness(5, 2, 5, 2);
            btnClearClip.Margin = new Thickness(0, 0, 6, 0);
            btnClearClip.Content = new TextBlock { Text = "🗑", Foreground = HexBrush("#B8A99E"), FontSize = 12 };
            btnClearClip.Click += (s, e) =>
            {
                clipboardHistory.Clear();
                RefreshClipboardUi();
                ShowToast(L("Pano geçmişi temizlendi", "Clipboard history cleared"));
            };
            Grid.SetColumn(btnClearClip, 1);
            clipHeader.Children.Add(btnClearClip);

            Border clipCountBadge = new Border
            {
                CornerRadius = new CornerRadius(6),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(7, 2, 7, 2)
            };
            subBoxes.Add(clipCountBadge);
            txtClipCount = new TextBlock { Text = L("0 öğe", "0 items"), Foreground = HexBrush("#E6DDD6"), FontSize = 11 };
            clipCountBadge.Child = txtClipCount;
            Grid.SetColumn(clipCountBadge, 2);
            clipHeader.Children.Add(clipCountBadge);
            secContainerClipboard.Children.Add(clipHeader);

            panelClipItems = new StackPanel();
            secContainerClipboard.Children.Add(panelClipItems);

            ApplyLayoutAndVisibility();

            resizeGripIndicator = new Border
            {
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, 6, 4),
                Visibility = Visibility.Collapsed,
                IsHitTestVisible = false
            };
            resizeGripIndicator.Child = new TextBlock
            {
                Text = "◢",
                FontSize = 11,
                Foreground = HexBrush("#E2925C"),
                Opacity = 0.75
            };

            toastPopup = new Popup
            {
                PlacementTarget = this,
                Placement = PlacementMode.Bottom,
                VerticalOffset = -45,
                HorizontalOffset = 80,
                AllowsTransparency = true,
                StaysOpen = true
            };
            toastBorder = new Border
            {
                CornerRadius = new CornerRadius(8),
                Background = HexBrush("#E6E2925C"),
                Padding = new Thickness(12, 6, 12, 6)
            };
            txtToastMessage = new TextBlock { Text = L("Panoya kopyalandı", "Copied to clipboard"), Foreground = Brushes.White, FontSize = 11.5, FontWeight = FontWeights.SemiBold };
            toastBorder.Child = txtToastMessage;
            toastPopup.Child = toastBorder;

            toastTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1600) };
            toastTimer.Tick += (s, e) => { toastPopup.IsOpen = false; toastTimer.Stop(); };

            scroll.Content = rootStack;
            outerGrid.Children.Add(scroll);
            outerGrid.Children.Add(resizeGripIndicator);
            outerBorder.Child = outerGrid;
            this.Content = outerBorder;
        }

        private Border CreateGlassCard()
        {
            Border b = new Border
            {
                CornerRadius = new CornerRadius(12),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(12, 10, 12, 10)
            };
            glassCards.Add(b);
            return b;
        }

        private Slider CreateModernSlider(string accentHex, double initialVal)
        {
            return CreateModernSlider(accentHex, initialVal, 30, "0,2,0,10");
        }

        private Slider CreateModernSlider(string accentHex, double initialVal, double minVal, string marginStr)
        {
            string xaml = string.Format(@"
            <Slider xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                    xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
                    Minimum='{2}' Maximum='100' Value='{1}' IsMoveToPointEnabled='True' Cursor='Hand' Margin='{3}'>
                <Slider.Template>
                    <ControlTemplate TargetType='Slider'>
                        <Grid VerticalAlignment='Center' Height='18'>
                            <Border Height='4' CornerRadius='2' Background='#2A211C' VerticalAlignment='Center'/>
                            <Track x:Name='PART_Track'>
                                <Track.DecreaseRepeatButton>
                                    <RepeatButton Command='Slider.DecreaseLarge'>
                                        <RepeatButton.Template>
                                            <ControlTemplate TargetType='RepeatButton'>
                                                <Border Height='4' CornerRadius='2' Background='{0}' VerticalAlignment='Center'/>
                                            </ControlTemplate>
                                        </RepeatButton.Template>
                                    </RepeatButton>
                                </Track.DecreaseRepeatButton>
                                <Track.IncreaseRepeatButton>
                                    <RepeatButton Command='Slider.IncreaseLarge'>
                                        <RepeatButton.Template>
                                            <ControlTemplate TargetType='RepeatButton'>
                                                <Border Height='4' CornerRadius='2' Background='Transparent' VerticalAlignment='Center'/>
                                            </ControlTemplate>
                                        </RepeatButton.Template>
                                    </RepeatButton>
                                </Track.IncreaseRepeatButton>
                                <Track.Thumb>
                                    <Thumb>
                                        <Thumb.Template>
                                            <ControlTemplate TargetType='Thumb'>
                                                <Border Width='14' Height='14' CornerRadius='7' Background='{0}' BorderBrush='#FAF6F2' BorderThickness='2'/>
                                            </ControlTemplate>
                                        </Thumb.Template>
                                    </Thumb>
                                </Track.Thumb>
                            </Track>
                        </Grid>
                    </ControlTemplate>
                </Slider.Template>
            </Slider>", accentHex, (int)Math.Round(initialVal), (int)Math.Round(minVal), marginStr);
            return (Slider)System.Windows.Markup.XamlReader.Parse(xaml);
        }

        private void ApplyLayoutAndVisibility()
        {
            if (modulesHostPanel == null) return;

            if (secContainerWeather != null) secContainerWeather.Visibility = showSecWeather ? Visibility.Visible : Visibility.Collapsed;
            if (secContainerMonitors != null) secContainerMonitors.Visibility = (showSecMonitors && monitorSlots.Count > 0) ? Visibility.Visible : Visibility.Collapsed;
            if (secContainerWireless != null) secContainerWireless.Visibility = (showSecWireless && lastWirelessCount > 0) ? Visibility.Visible : Visibility.Collapsed;
            if (secContainerTelemetry != null) secContainerTelemetry.Visibility = showSecTelemetry ? Visibility.Visible : Visibility.Collapsed;
            if (secContainerClipboard != null) secContainerClipboard.Visibility = showSecClipboard ? Visibility.Visible : Visibility.Collapsed;

            if (rowTeleCpu != null) rowTeleCpu.Visibility = showTeleCpu ? Visibility.Visible : Visibility.Collapsed;
            if (rowTeleRam != null) rowTeleRam.Visibility = showTeleRam ? Visibility.Visible : Visibility.Collapsed;
            if (rowTeleGpu != null) rowTeleGpu.Visibility = showTeleGpu ? Visibility.Visible : Visibility.Collapsed;
            if (rowTeleVram != null) rowTeleVram.Visibility = showTeleVram ? Visibility.Visible : Visibility.Collapsed;
            if (rowTeleNet != null) rowTeleNet.Visibility = showTeleNet ? Visibility.Visible : Visibility.Collapsed;
            for (int i = 0; i < rowsTeleDisks.Count; i++)
            {
                if (rowsTeleDisks[i] != null)
                {
                    rowsTeleDisks[i].Visibility = showTeleDisks ? Visibility.Visible : Visibility.Collapsed;
                }
            }

            modulesHostPanel.Children.Clear();
            bool isFirstVisible = true;
            foreach (string key in sectionOrder)
            {
                StackPanel container = null;
                if (key == "weather") container = secContainerWeather;
                else if (key == "monitors") container = secContainerMonitors;
                else if (key == "wireless") container = secContainerWireless;
                else if (key == "telemetry") container = secContainerTelemetry;
                else if (key == "clipboard") container = secContainerClipboard;

                if (container != null)
                {
                    if (container.Children.Count > 0 && container.Children[0] is FrameworkElement)
                    {
                        FrameworkElement hdr = (FrameworkElement)container.Children[0];
                        if (container.Visibility == Visibility.Visible)
                        {
                            hdr.Margin = isFirstVisible ? new Thickness(0, 2, 0, 6) : new Thickness(0, 12, 0, 6);
                            isFirstVisible = false;
                        }
                    }
                    modulesHostPanel.Children.Add(container);
                }
            }
        }

        private Border CreateWeatherMetricBox(string label, string initialValue, out TextBlock labelBlock, out TextBlock valueBlock, Thickness margin)
        {
            Border b = new Border
            {
                CornerRadius = new CornerRadius(8),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(6, 6, 6, 6),
                Margin = margin
            };
            subBoxes.Add(b);
            StackPanel sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            labelBlock = new TextBlock { Text = label, Foreground = HexBrush("#B8A99E"), FontSize = 10.5, HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(labelBlock);
            valueBlock = new TextBlock
            {
                Text = initialValue,
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12.5,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 2, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Center
            };
            sp.Children.Add(valueBlock);
            b.Child = sp;
            return b;
        }

        private Border CreateMiniIconBadge(string iconText)
        {
            Border b = new Border
            {
                Width = 20,
                Height = 20,
                CornerRadius = new CornerRadius(5),
                BorderThickness = new Thickness(1),
                Margin = new Thickness(0, 0, 7, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            subBoxes.Add(b);
            b.Child = new TextBlock
            {
                Text = iconText,
                Foreground = HexBrush("#C7B9AE"),
                FontSize = 10,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            return b;
        }

        private Grid CreateTelemetrySparkRow(string icon, string label, string detail, bool useThemeAccent, out TextBlock labelBlock, out TextBlock detailBlock, out Polyline sparkline, out TextBlock pctBlock)
        {
            Grid g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel left = new StackPanel { Orientation = Orientation.Horizontal };
            left.Children.Add(CreateMiniIconBadge(icon));
            labelBlock = new TextBlock { Text = label, Foreground = HexBrush("#F5EFEA"), FontSize = 12, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            left.Children.Add(labelBlock);
            Grid.SetColumn(left, 0);
            g.Children.Add(left);

            detailBlock = new TextBlock
            {
                Text = detail,
                Foreground = HexBrush("#B8A99E"),
                FontSize = 11,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(4, 0, 8, 0),
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(detailBlock, 1);
            g.Children.Add(detailBlock);

            Border sparkBox = new Border
            {
                Width = 46,
                Height = 16,
                CornerRadius = new CornerRadius(3),
                Background = HexBrush("#1F1916"),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0),
                ClipToBounds = true
            };
            Canvas c = new Canvas { Width = 46, Height = 16 };
            sparkline = new Polyline { StrokeThickness = 1.6 };
            if (useThemeAccent) accentSparklines.Add(sparkline);
            c.Children.Add(sparkline);
            sparkBox.Child = c;
            Grid.SetColumn(sparkBox, 2);
            g.Children.Add(sparkBox);

            pctBlock = new TextBlock
            {
                Text = "%6",
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                Width = 46,
                TextAlignment = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };
            if (useThemeAccent) accentTextBlocks.Add(pctBlock);
            Grid.SetColumn(pctBlock, 3);
            g.Children.Add(pctBlock);

            return g;
        }

        private Grid CreateTelemetryBarRow(string icon, string label, string detail, bool useThemeAccent, out TextBlock labelBlock, out TextBlock detailBlock, out Border barFill, out TextBlock pctBlock)
        {
            Grid g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel left = new StackPanel { Orientation = Orientation.Horizontal };
            left.Children.Add(CreateMiniIconBadge(icon));
            labelBlock = new TextBlock { Text = label, Foreground = HexBrush("#F5EFEA"), FontSize = 12, FontWeight = FontWeights.Medium, VerticalAlignment = VerticalAlignment.Center };
            left.Children.Add(labelBlock);
            Grid.SetColumn(left, 0);
            g.Children.Add(left);

            detailBlock = new TextBlock
            {
                Text = detail,
                Foreground = HexBrush("#B8A99E"),
                FontSize = 11,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(4, 0, 8, 0),
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(detailBlock, 1);
            g.Children.Add(detailBlock);

            Border track = new Border
            {
                Width = 42,
                Height = 4,
                CornerRadius = new CornerRadius(2),
                Background = HexBrush("#2E2520"),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 6, 0)
            };
            barFill = new Border
            {
                Width = 20,
                Height = 4,
                CornerRadius = new CornerRadius(2),
                HorizontalAlignment = HorizontalAlignment.Left
            };
            if (useThemeAccent) accentBarFills.Add(barFill);
            track.Child = barFill;
            Grid.SetColumn(track, 2);
            g.Children.Add(track);

            pctBlock = new TextBlock
            {
                Text = "%40",
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                MinWidth = 48,
                TextAlignment = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };
            if (useThemeAccent) accentTextBlocks.Add(pctBlock);
            Grid.SetColumn(pctBlock, 3);
            g.Children.Add(pctBlock);

            return g;
        }

        private Button CreateStyledIconButton(string bgHex, string borderHex, string tooltip)
        {
            Button btn = new Button
            {
                Cursor = Cursors.Hand,
                ToolTip = tooltip,
                Background = bgHex == "Transparent" ? Brushes.Transparent : HexBrush(bgHex),
                BorderBrush = borderHex == "Transparent" ? Brushes.Transparent : HexBrush(borderHex),
                BorderThickness = new Thickness(1)
            };

            ControlTemplate template = new ControlTemplate(typeof(Button));
            FrameworkElementFactory border = new FrameworkElementFactory(typeof(Border));
            border.SetValue(Border.CornerRadiusProperty, new CornerRadius(6));
            border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
            border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Button.BorderBrushProperty));
            border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Button.BorderThicknessProperty));
            border.SetValue(Border.PaddingProperty, new TemplateBindingExtension(Button.PaddingProperty));

            FrameworkElementFactory presenter = new FrameworkElementFactory(typeof(ContentPresenter));
            presenter.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            presenter.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            border.AppendChild(presenter);

            template.VisualTree = border;
            btn.Template = template;
            return btn;
        }

        private Button CreateStretchSettingsButton(string bgHex, string borderHex, string tooltip)
        {
            Button btn = new Button
            {
                Cursor = Cursors.Hand,
                ToolTip = tooltip,
                Background = bgHex == "Transparent" ? Brushes.Transparent : HexBrush(bgHex),
                BorderBrush = borderHex == "Transparent" ? Brushes.Transparent : HexBrush(borderHex),
                BorderThickness = new Thickness(1),
                HorizontalContentAlignment = HorizontalAlignment.Stretch
            };

            ControlTemplate template = new ControlTemplate(typeof(Button));
            FrameworkElementFactory border = new FrameworkElementFactory(typeof(Border));
            border.SetValue(Border.CornerRadiusProperty, new CornerRadius(7));
            border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
            border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Button.BorderBrushProperty));
            border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Button.BorderThicknessProperty));
            border.SetValue(Border.PaddingProperty, new TemplateBindingExtension(Button.PaddingProperty));

            FrameworkElementFactory presenter = new FrameworkElementFactory(typeof(ContentPresenter));
            presenter.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            presenter.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            border.AppendChild(presenter);

            template.VisualTree = border;
            btn.Template = template;
            return btn;
        }

        // ==========================================
        // SYSTEM TRAY & CACHED COREAUDIO CONTROLLER
        // ==========================================
        private void InitializeTrayAndAudio()
        {
            iconMicUnmuted = CreateModernMicTrayIcon(false);
            iconMicMuted = CreateModernMicTrayIcon(true);

            trayIcon = new System.Windows.Forms.NotifyIcon();
            trayIcon.Icon = iconMicUnmuted;
            trayIcon.Visible = true;

            // Cache CoreAudio endpoints off the UI thread so startup never stalls on audio service/COM init
            Task.Run(() =>
            {
                try
                {
                    var enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumeratorComObject());
                    IMMDevice devConsole;
                    if (enumerator.GetDefaultAudioEndpoint(1, 0, out devConsole) == 0 && devConsole != null)
                    {
                        Guid iid = typeof(IAudioEndpointVolume).GUID;
                        object obj;
                        devConsole.Activate(ref iid, 23, IntPtr.Zero, out obj);
                        cachedMicVolumeConsole = (IAudioEndpointVolume)obj;
                    }
                    IMMDevice devComm;
                    if (enumerator.GetDefaultAudioEndpoint(1, 2, out devComm) == 0 && devComm != null)
                    {
                        Guid iid = typeof(IAudioEndpointVolume).GUID;
                        object obj;
                        devComm.Activate(ref iid, 23, IntPtr.Zero, out obj);
                        cachedMicVolumeComm = (IAudioEndpointVolume)obj;
                    }
                }
                catch { }
                try { Dispatcher.BeginInvoke(new Action(() => SyncMicrophoneStateFromOs(true))); } catch { }
            });

            var menu = new System.Windows.Forms.ContextMenuStrip();
            trayMuteItem = new System.Windows.Forms.ToolStripMenuItem(L("🎙 Mikrofonu Sustur / Aç (Sol Tık)", "🎙 Mute / Unmute Microphone (Left Click)"));
            trayMuteItem.Click += (s, e) => ToggleMicrophoneMute();
            menu.Items.Add(trayMuteItem);

            traySettingsItem = new System.Windows.Forms.ToolStripMenuItem(L("⚙ Widget Ayarları (Dil, Konum & Tema)...", "⚙ Widget Settings (Language, Location & Theme)..."));
            traySettingsItem.Font = new System.Drawing.Font(traySettingsItem.Font, System.Drawing.FontStyle.Bold);
            traySettingsItem.Click += (s, e) => OpenSettingsWindow();
            menu.Items.Add(traySettingsItem);

            trayCalendarItem = new System.Windows.Forms.ToolStripMenuItem(showCalendarWidget
                ? L("📅 Takvim Widget'ını Gizle", "📅 Hide Calendar Widget")
                : L("📅 Takvim Widget'ını Göster", "📅 Show Calendar Widget"));
            trayCalendarItem.Click += (s, e) => SetCalendarWidgetVisible(!showCalendarWidget);
            menu.Items.Add(trayCalendarItem);

            trayTimerItem = new System.Windows.Forms.ToolStripMenuItem(showTimerWidget
                ? L("⏱ Timer Widgeti'ni Gizle", "⏱ Hide Timer Widget")
                : L("⏱ Timer Widgeti'ni Göster", "⏱ Show Timer Widget"));
            trayTimerItem.Click += (s, e) => SetTimerWidgetVisible(!showTimerWidget);
            menu.Items.Add(trayTimerItem);

            menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());

            trayLockItem = new System.Windows.Forms.ToolStripMenuItem(L("🔓 Taşınabilir & Boyutlandırılabilir Modu Aç", "🔓 Enable Draggable & Resizable Mode"));
            trayLockItem.Click += (s, e) => ToggleDraggableMode();
            menu.Items.Add(trayLockItem);

            trayFitHeightItem = new System.Windows.Forms.ToolStripMenuItem(L("📐 Yüksekliği İçeriğe Göre Otomatik Sığdır", "📐 Auto-Fit Height to Content"));
            trayFitHeightItem.Click += (s, e) => FitHeightToContentIfCompact();
            menu.Items.Add(trayFitHeightItem);

            trayDockRightItem = new System.Windows.Forms.ToolStripMenuItem(L("➡ Sağ Kenara Hizala", "➡ Dock to Right Edge"));
            trayDockRightItem.Click += (s, e) => DockWindow("Right");
            menu.Items.Add(trayDockRightItem);

            trayDockLeftItem = new System.Windows.Forms.ToolStripMenuItem(L("⬅ Sol Kenara Hizala", "⬅ Dock to Left Edge"));
            trayDockLeftItem.Click += (s, e) => DockWindow("Left");
            menu.Items.Add(trayDockLeftItem);

            trayToggleVisItem = new System.Windows.Forms.ToolStripMenuItem(L("👁 Widget'ı Göster / Gizle", "👁 Show / Hide Widget"));
            trayToggleVisItem.Click += (s, e) =>
            {
                if (this.Visibility == Visibility.Visible && !userHidden)
                {
                    userHidden = true;
                    this.Visibility = Visibility.Hidden;
                }
                else
                {
                    userHidden = false;
                    this.Visibility = Visibility.Visible;
                }
            };
            menu.Items.Add(trayToggleVisItem);

            trayAutoStartItem = new System.Windows.Forms.ToolStripMenuItem(L("🚀 Windows Başlangıcında Otomatik Aç", "🚀 Launch Automatically on Windows Startup"))
            {
                Checked = IsAutoStartEnabled(),
                CheckOnClick = true
            };
            trayAutoStartItem.Click += (s, e) =>
            {
                EnsureAutoStart(trayAutoStartItem.Checked);
                ShowToast(trayAutoStartItem.Checked
                    ? L("Başlangıçta otomatik açılma aktif edildi", "Startup auto-launch enabled")
                    : L("Başlangıçta otomatik açılma kapatıldı", "Startup auto-launch disabled"));
            };
            menu.Items.Add(trayAutoStartItem);

            menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());

            trayExitItem = new System.Windows.Forms.ToolStripMenuItem(L("✖ Çıkış", "✖ Exit"));
            trayExitItem.Click += (s, e) => Application.Current.Shutdown();
            menu.Items.Add(trayExitItem);

            trayIcon.ContextMenuStrip = menu;

            trayIcon.MouseClick += (s, e) =>
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Left)
                {
                    ToggleMicrophoneMute();
                }
            };
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool DestroyIcon(IntPtr handle);

        private System.Drawing.Icon CreateModernMicTrayIcon(bool muted)
        {
            using (var bmp = new System.Drawing.Bitmap(32, 32))
            using (var g = System.Drawing.Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.Clear(System.Drawing.Color.Transparent);

                if (!muted)
                {
                    using (var whiteBrush = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(255, 250, 250, 252)))
                    using (var whitePen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(255, 250, 250, 252), 2.8f))
                    {
                        whitePen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                        whitePen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

                        g.FillRectangle(whiteBrush, 11, 6, 10, 11);
                        g.FillEllipse(whiteBrush, 11, 2, 10, 8);
                        g.FillEllipse(whiteBrush, 11, 13, 10, 8);

                        g.DrawArc(whitePen, 7, 8, 18, 15, 0, 180);
                        g.DrawLine(whitePen, 16, 23, 16, 28);
                        g.DrawLine(whitePen, 10, 28, 22, 28);
                    }
                }
                else
                {
                    using (var dimWhiteBrush = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(215, 240, 240, 240)))
                    using (var dimWhitePen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(215, 240, 240, 240), 2.6f))
                    {
                        dimWhitePen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                        dimWhitePen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

                        g.FillRectangle(dimWhiteBrush, 11, 6, 10, 11);
                        g.FillEllipse(dimWhiteBrush, 11, 2, 10, 8);
                        g.FillEllipse(dimWhiteBrush, 11, 13, 10, 8);

                        g.DrawArc(dimWhitePen, 7, 8, 18, 15, 0, 180);
                        g.DrawLine(dimWhitePen, 16, 23, 16, 28);
                        g.DrawLine(dimWhitePen, 10, 28, 22, 28);
                    }

                    using (var shadowPen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(220, 20, 20, 20), 5.5f))
                    using (var redSlashPen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(255, 244, 63, 94), 3.4f))
                    {
                        shadowPen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                        shadowPen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                        redSlashPen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                        redSlashPen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

                        g.DrawLine(shadowPen, 5, 5, 27, 27);
                        g.DrawLine(redSlashPen, 5, 5, 27, 27);
                    }
                }

                IntPtr hIcon = bmp.GetHicon();
                System.Drawing.Icon cloned = (System.Drawing.Icon)System.Drawing.Icon.FromHandle(hIcon).Clone();
                DestroyIcon(hIcon);
                return cloned;
            }
        }

        private void SyncMicrophoneStateFromOs(bool forceUiUpdate)
        {
            bool prev = isMicMuted;
            try
            {
                if (cachedMicVolumeConsole != null)
                {
                    bool muted;
                    cachedMicVolumeConsole.GetMute(out muted);
                    isMicMuted = muted;
                }
            }
            catch { }
            if (forceUiUpdate || prev != isMicMuted)
            {
                UpdateMicrophoneUi();
            }
        }

        private void ToggleMicrophoneMute()
        {
            bool targetMute = !isMicMuted;
            try
            {
                Guid ctx = Guid.Empty;
                if (cachedMicVolumeConsole != null) cachedMicVolumeConsole.SetMute(targetMute, ref ctx);
                if (cachedMicVolumeComm != null) cachedMicVolumeComm.SetMute(targetMute, ref ctx);
                isMicMuted = targetMute;
            }
            catch { }

            UpdateMicrophoneUi();
            ShowToast(isMicMuted
                ? L("🔇 Mikrofon Susturuldu (Muted)", "🔇 Microphone Muted")
                : L("🎙 Mikrofon Açıldı (Canlı)", "🎙 Microphone Unmuted (Live)"));
        }

        private void UpdateMicrophoneUi()
        {
            Dispatcher.Invoke(() =>
            {
                if (trayIcon != null)
                {
                    trayIcon.Icon = isMicMuted ? iconMicMuted : iconMicUnmuted;
                    trayIcon.Text = isMicMuted
                        ? L("Mikrofon: KAPALI (Susturuldu) - Açmak için tıkla", "Microphone: MUTED - Click to unmute")
                        : L("Mikrofon: AÇIK (Canlı) - Susturmak için tıkla", "Microphone: LIVE - Click to mute");
                }
                if (txtMicHeaderIcon != null && btnMicHeader != null)
                {
                    if (isMicMuted)
                    {
                        txtMicHeaderIcon.Text = "🔇";
                        txtMicHeaderIcon.Foreground = HexBrush("#FB7185");
                        btnMicHeader.Background = HexBrush("#3B1622");
                        btnMicHeader.BorderBrush = HexBrush("#E11D48");
                        btnMicHeader.ToolTip = L("Mikrofon Sessiz (Açmak için tıklayın veya Ctrl+Shift+M)", "Microphone Muted (Click to unmute or Ctrl+Shift+M)");
                    }
                    else
                    {
                        txtMicHeaderIcon.Text = "🎙";
                        txtMicHeaderIcon.Foreground = HexBrush("#FAF6F2");
                        btnMicHeader.Background = HexBrush("#26201D");
                        btnMicHeader.BorderBrush = Brushes.Transparent;
                        btnMicHeader.ToolTip = L("Mikrofon Açık (Susturmak için tıklayın veya Ctrl+Shift+M)", "Microphone Live (Click to mute or Ctrl+Shift+M)");
                    }
                }
            });
        }

        public void ApplyLanguage()
        {
            try
            {
                if (txtWeatherSectionTitle != null) txtWeatherSectionTitle.Text = L("Hava Durumu", "Weather");
                if (txtLocationBadge != null) txtLocationBadge.ToolTip = L("Hava durumunu yenilemek için sol tıklayın, konumu değiştirmek için Ayarlar (⚙) menüsünü açın", "Left-click to refresh weather, open Settings (⚙) to change location");
                if (txtHumidityLabel != null) txtHumidityLabel.Text = L("💧 Nem", "💧 Humidity");
                if (txtWindLabel != null) txtWindLabel.Text = L("💨 Rüzgar", "💨 Wind");
                if (txtRainLabel != null) txtRainLabel.Text = L("🌧 Yağış", "🌧 Rain");
                if (txtMonitorSectionTitle != null) txtMonitorSectionTitle.Text = L("Monitör Parlaklığı", "Monitor Brightness");
                if (btnRefreshMonitors != null) btnRefreshMonitors.ToolTip = L("Monitörleri ve parlaklık seviyelerini yeniden algıla", "Re-detect monitors and brightness levels");
                UpdateMonitorLinkButtonUi();
                RebuildMonitorSlidersUi();
                if (txtWirelessSectionTitle != null) txtWirelessSectionTitle.Text = L("Kablosuz Cihazlar", "Wireless Devices");
                if (btnRefreshWireless != null) btnRefreshWireless.ToolTip = L("Kablosuz cihaz şarjlarını şimdi yenile", "Refresh wireless device battery levels now");
                if (txtTelemetrySectionTitle != null) txtTelemetrySectionTitle.Text = L("Telemetri", "Telemetry");
                if (txtCpuRowLabel != null) txtCpuRowLabel.Text = L("İşlemci (CPU)", "Processor (CPU)");
                if (txtRamRowLabel != null) txtRamRowLabel.Text = L("Bellek (RAM)", "Memory (RAM)");
                if (txtGpuRowLabel != null) txtGpuRowLabel.Text = L("Ekran Kartı (GPU)", "Graphics (GPU)");
                if (txtVramRowLabel != null) txtVramRowLabel.Text = L("Video Belleği (VRAM)", "Video Memory (VRAM)");
                if (txtNetRowLabel != null) txtNetRowLabel.Text = L("Ağ Trafiği", "Network");

                for (int i = 0; i < fixedDrives.Count && i < diskRowLabels.Count; i++)
                {
                    string dName = fixedDrives[i].Name.TrimEnd('\\');
                    diskRowLabels[i].Text = dName + L(" Diski", " Drive");
                }

                if (txtClipboardSectionTitle != null) txtClipboardSectionTitle.Text = L("Pano Geçmişi", "Clipboard History");
                if (btnClearClip != null) btnClearClip.ToolTip = L("Pano geçmişini temizle", "Clear clipboard history");
                if (btnSettingsHeader != null) btnSettingsHeader.ToolTip = L("Widget Ayarları (Dil, Konum, Tema & Düzen)", "Widget Settings (Language, Location, Theme & Layout)");

                if (trayMuteItem != null) trayMuteItem.Text = L("🎙 Mikrofonu Sustur / Aç (Sol Tık)", "🎙 Mute / Unmute Microphone (Left Click)");
                if (traySettingsItem != null) traySettingsItem.Text = L("⚙ Widget Ayarları (Dil, Konum, Tema & Düzen)...", "⚙ Widget Settings (Language, Location, Theme & Layout)...");
                if (trayCalendarItem != null) trayCalendarItem.Text = showCalendarWidget ? L("📅 Takvim Widget'ını Gizle", "📅 Hide Calendar Widget") : L("📅 Takvim Widget'ını Göster", "📅 Show Calendar Widget");
                if (trayTimerItem != null) trayTimerItem.Text = showTimerWidget ? L("⏱ Timer Widgeti'ni Gizle", "⏱ Hide Timer Widget") : L("⏱ Timer Widgeti'ni Göster", "⏱ Show Timer Widget");
                if (trayLockItem != null)
                {
                    trayLockItem.Text = isDraggable
                        ? L("📌 Konumu ve Boyutu Kilitle (Sabit Mod)", "📌 Lock Position & Size (Fixed Mode)")
                        : L("🔓 Taşınabilir & Boyutlandırılabilir Modu Aç", "🔓 Enable Draggable & Resizable Mode");
                }
                if (trayFitHeightItem != null) trayFitHeightItem.Text = L("📐 Yüksekliği İçeriğe Göre Otomatik Sığdır", "📐 Auto-Fit Height to Content");
                if (trayDockRightItem != null) trayDockRightItem.Text = L("➡ Sağ Kenara Hizala", "➡ Dock to Right Edge");
                if (trayDockLeftItem != null) trayDockLeftItem.Text = L("⬅ Sol Kenara Hizala", "⬅ Dock to Left Edge");
                if (trayToggleVisItem != null) trayToggleVisItem.Text = L("👁 Widget'ı Göster / Gizle", "👁 Show / Hide Widget");
                if (trayAutoStartItem != null) trayAutoStartItem.Text = L("🚀 Windows Başlangıcında Otomatik Aç", "🚀 Launch Automatically on Windows Startup");
                if (trayExitItem != null) trayExitItem.Text = L("✖ Çıkış", "✖ Exit");

                UpdateMicrophoneUi();
                UpdateDraggableButtonUi();
                UpdateClockAndUptime();
                UpdateTelemetryFast();
                RefreshClipboardUi();
                if (calendarWindow != null)
                {
                    lastRightScheduleSignature = "";
                    lastLeftColumnSignature = "";
                    BuildCalendarWidgetUi();
                    ApplyCalendarWidgetTheme();
                }
                if (timerWindow != null)
                {
                    cachedHeatmapAccentHex = "";
                    lastPlayBtnBrushKey = "";
                    lastRenderedLitTicks = -1;
                    heatmapCellPool.Clear();
                    heatmapMonthPool.Clear();
                    BuildTimerWidgetUi();
                    ApplyTimerWidgetTheme();
                }
                Task.Run(() =>
                {
                    FetchWeatherAsync();
                    PollWirelessDevicesAsync();
                });
            }
            catch { }
        }

        // ==========================================
        // DRAGGABLE & RESIZABLE MODE + SETTINGS WINDOW
        // ==========================================
        private void ToggleDraggableMode()
        {
            isDraggable = !isDraggable;
            if (isDraggable)
            {
                this.ResizeMode = ResizeMode.CanResize;
                if (windowChrome != null) windowChrome.ResizeBorderThickness = new Thickness(8);
                if (resizeGripIndicator != null) resizeGripIndicator.Visibility = Visibility.Visible;
                if (calendarWindow != null)
                {
                    calendarWindow.ResizeMode = ResizeMode.CanResize;
                    if (calWindowChrome != null) calWindowChrome.ResizeBorderThickness = new Thickness(8);
                    if (calResizeGrip != null) calResizeGrip.Visibility = Visibility.Visible;
                }
                if (timerWindow != null)
                {
                    timerWindow.ResizeMode = ResizeMode.CanResize;
                    if (timerWindowChrome != null) timerWindowChrome.ResizeBorderThickness = new Thickness(8);
                    if (timerResizeGrip != null) timerResizeGrip.Visibility = Visibility.Visible;
                }
                if (trayLockItem != null) trayLockItem.Text = L("📌 Konumu ve Boyutu Kilitle (Sabit Mod)", "📌 Lock Position & Size (Fixed Mode)");
                ShowToast(L("Taşınabilir Mod Açık: Sürükleyebilir veya kenarlardan boyutlandırabilirsiniz", "Unlocked Mode: Drag anywhere or resize from edges"));
            }
            else
            {
                this.ResizeMode = ResizeMode.NoResize;
                if (windowChrome != null) windowChrome.ResizeBorderThickness = new Thickness(0);
                if (resizeGripIndicator != null) resizeGripIndicator.Visibility = Visibility.Collapsed;
                if (calendarWindow != null)
                {
                    calendarWindow.ResizeMode = ResizeMode.NoResize;
                    if (calWindowChrome != null) calWindowChrome.ResizeBorderThickness = new Thickness(0);
                    if (calResizeGrip != null) calResizeGrip.Visibility = Visibility.Collapsed;
                }
                if (timerWindow != null)
                {
                    timerWindow.ResizeMode = ResizeMode.NoResize;
                    if (timerWindowChrome != null) timerWindowChrome.ResizeBorderThickness = new Thickness(0);
                    if (timerResizeGrip != null) timerResizeGrip.Visibility = Visibility.Collapsed;
                }
                if (trayLockItem != null) trayLockItem.Text = L("🔓 Taşınabilir & Boyutlandırılabilir Modu Aç", "🔓 Enable Draggable & Resizable Mode");
                SaveSettings();
                ShowToast(L("Konum ve boyut kilitlendi", "Position and size locked"));
            }
            UpdateDraggableButtonUi();
        }

        private void UpdateDraggableButtonUi()
        {
            if (btnLockDrag != null)
            {
                if (isDraggable)
                {
                    btnLockDrag.Content = new TextBlock { Text = "🔓", FontSize = 11.5, Foreground = HexBrush(accentColorHex), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    btnLockDrag.Background = HexBrush("#33251D");
                    btnLockDrag.BorderBrush = HexBrush(accentColorHex);
                    btnLockDrag.ToolTip = L("Taşınabilir & Boyutlandırılabilir Mod Açık (Sabitlemek için tıklayın)", "Draggable & Resizable Mode Active (Click to lock)");
                }
                else
                {
                    btnLockDrag.Content = new TextBlock { Text = "📌", FontSize = 11.5, Foreground = HexBrush("#C7B9AE"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    btnLockDrag.Background = HexBrush("#26201D");
                    btnLockDrag.BorderBrush = Brushes.Transparent;
                    btnLockDrag.ToolTip = L("Sabit Mod (Taşınabilir ve Boyutlandırılabilir Modu Açmak İçin Tıklayın)", "Locked Mode (Click to Enable Draggable & Resizable Mode)");
                }
            }
            if (btnCalLockDrag != null)
            {
                if (isDraggable)
                {
                    btnCalLockDrag.Content = new TextBlock { Text = "🔓", FontSize = 10.5, Foreground = HexBrush(accentColorHex), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    btnCalLockDrag.Background = HexBrush("#33251D");
                    btnCalLockDrag.BorderBrush = HexBrush(accentColorHex);
                }
                else
                {
                    btnCalLockDrag.Content = new TextBlock { Text = "📌", FontSize = 10.5, Foreground = HexBrush("#C7B9AE"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    btnCalLockDrag.Background = HexBrush("#26201D");
                    btnCalLockDrag.BorderBrush = Brushes.Transparent;
                }
            }
            if (btnTimerLockDrag != null)
            {
                if (isDraggable)
                {
                    btnTimerLockDrag.Content = new TextBlock { Text = "🔓", FontSize = 10.5, Foreground = HexBrush(accentColorHex), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    btnTimerLockDrag.Background = HexBrush("#33251D");
                    btnTimerLockDrag.BorderBrush = HexBrush(accentColorHex);
                }
                else
                {
                    btnTimerLockDrag.Content = new TextBlock { Text = "📌", FontSize = 10.5, Foreground = HexBrush("#C7B9AE"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    btnTimerLockDrag.Background = HexBrush("#26201D");
                    btnTimerLockDrag.BorderBrush = Brushes.Transparent;
                }
            }
        }

        private void DockWindow(string side)
        {
            Rect workArea = GetWindowMonitorWorkArea(this);
            this.Top = workArea.Top + 14;
            if (side == "Left")
            {
                this.Left = workArea.Left + 14;
            }
            else
            {
                this.Left = workArea.Right - this.ActualWidth - 14;
            }
            savedLeft = this.Left;
            savedTop = this.Top;
            SaveSettings();
        }

        private string GetSectionDisplayName(string key)
        {
            if (key == "weather") return L("☀  Hava Durumu", "☀  Weather");
            if (key == "monitors") return L("🖥  Monitör Parlaklığı", "🖥  Monitor Brightness");
            if (key == "wireless") return L("🔋  Kablosuz Cihazlar", "🔋  Wireless Devices");
            if (key == "telemetry") return L("⚙  Telemetri", "⚙  Telemetry");
            if (key == "clipboard") return L("📋  Pano Geçmişi", "📋  Clipboard History");
            return key;
        }

        private bool IsSectionEnabled(string key)
        {
            if (key == "weather") return showSecWeather;
            if (key == "monitors") return showSecMonitors;
            if (key == "wireless") return showSecWireless;
            if (key == "telemetry") return showSecTelemetry;
            if (key == "clipboard") return showSecClipboard;
            return true;
        }

        private void SetSectionEnabled(string key, bool val)
        {
            if (key == "weather") showSecWeather = val;
            else if (key == "monitors") showSecMonitors = val;
            else if (key == "wireless") showSecWireless = val;
            else if (key == "telemetry") showSecTelemetry = val;
            else if (key == "clipboard") showSecClipboard = val;
        }

        private Border CreateSettingsSectionCard(string sectionTitle, string subtitle)
        {
            Border secCard = new Border
            {
                CornerRadius = new CornerRadius(11),
                Background = HexBrush("#251F1B"),
                BorderBrush = HexBrush("#3B302A"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(13, 11, 13, 11),
                Margin = new Thickness(0, 0, 0, 10)
            };
            StackPanel sp = new StackPanel();
            if (!string.IsNullOrEmpty(sectionTitle))
            {
                sp.Children.Add(new TextBlock
                {
                    Text = sectionTitle,
                    Foreground = HexBrush("#FAF6F2"),
                    FontSize = 12,
                    FontWeight = FontWeights.Bold,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, string.IsNullOrEmpty(subtitle) ? 8 : 2)
                });
            }
            if (!string.IsNullOrEmpty(subtitle))
            {
                sp.Children.Add(new TextBlock
                {
                    Text = subtitle,
                    Foreground = HexBrush("#9E8E82"),
                    FontSize = 10.5,
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, 8)
                });
            }
            secCard.Child = sp;
            return secCard;
        }

        private void OpenSettingsWindow()
        {
            if (settingsWindow != null && settingsWindow.IsVisible)
            {
                settingsWindow.Activate();
                return;
            }

            if (currentSettingsTab < 0 || currentSettingsTab > 2) currentSettingsTab = 0;

            double maxH = Math.Min(650, SystemParameters.WorkArea.Height - 40);
            settingsWindow = new Window
            {
                Title = L("OpenWidget Ayarları", "OpenWidget Settings"),
                Width = 450,
                Height = Math.Max(460, maxH),
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                Background = Brushes.Transparent,
                ResizeMode = ResizeMode.NoResize,
                Topmost = true,
                UseLayoutRounding = true,
                SnapsToDevicePixels = true,
                FontFamily = new FontFamily("Segoe UI")
            };
            TextOptions.SetTextFormattingMode(settingsWindow, TextFormattingMode.Display);
            TextOptions.SetTextRenderingMode(settingsWindow, TextRenderingMode.ClearType);
            Program.TryApplyWindowIcon(settingsWindow);

            Border card = new Border
            {
                CornerRadius = new CornerRadius(15),
                Background = HexBrush("#F71B1613"),
                BorderBrush = HexBrush(accentColorHex),
                BorderThickness = new Thickness(1.5),
                Padding = new Thickness(16, 14, 16, 14),
                Margin = new Thickness(8)
            };
            card.Effect = new DropShadowEffect { Color = Colors.Black, BlurRadius = 16, Opacity = 0.68 };

            // 3-Row Grid: Fixed Sticky Header + Segmented Tab Bar + Smooth ScrollViewer Content
            Grid rootLayout = new Grid();
            rootLayout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            rootLayout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            rootLayout.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // Row 0: Sticky Draggable Header
            Grid hdr = new Grid { Margin = new Thickness(0, 0, 0, 11), Background = Brushes.Transparent, Cursor = Cursors.SizeAll };
            hdr.MouseLeftButtonDown += (s, e) =>
            {
                if (e.ButtonState == MouseButtonState.Pressed)
                {
                    try { settingsWindow.DragMove(); } catch { }
                }
            };
            hdr.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdr.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel hdrTitleStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 10, 0) };
            hdrTitleStack.Children.Add(new TextBlock
            {
                Text = L("⚙ OpenWidget Ayarları", "⚙ OpenWidget Settings"),
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 15,
                FontWeight = FontWeights.Bold
            });
            hdrTitleStack.Children.Add(new TextBlock
            {
                Text = L("Görünüm, konum, masaüstü eklentileri ve modül düzeni", "Appearance, location, companion widgets & module layout"),
                Foreground = HexBrush("#9E8E82"),
                FontSize = 10.5,
                Margin = new Thickness(0, 1, 0, 0)
            });
            Grid.SetColumn(hdrTitleStack, 0);
            hdr.Children.Add(hdrTitleStack);

            Button btnClose = CreateStyledIconButton("#2E2520", "#4A3C34", L("Kapat", "Close"));
            btnClose.Padding = new Thickness(9, 4, 9, 4);
            btnClose.VerticalAlignment = VerticalAlignment.Center;
            btnClose.Content = new TextBlock { Text = "✕", Foreground = HexBrush("#C7B9AE"), FontSize = 11.5 };
            btnClose.Click += (s, e) => settingsWindow.Close();
            Grid.SetColumn(btnClose, 1);
            hdr.Children.Add(btnClose);
            Grid.SetRow(hdr, 0);
            rootLayout.Children.Add(hdr);

            // Row 1: Modern 3-Tab Segmented Pill Bar
            Border tabShell = new Border
            {
                CornerRadius = new CornerRadius(10),
                Background = HexBrush("#14100E"),
                BorderBrush = HexBrush("#332924"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(3),
                Margin = new Thickness(0, 0, 0, 10)
            };
            UniformGrid tabBar = new UniformGrid { Columns = 3 };
            Button[] tabBtns = new Button[3];
            TextBlock[] tabLbls = new TextBlock[3];
            string[] tabTitles = {
                L("🎨 Görünüm", "🎨 Appearance"),
                L("✨ Ek Widget'lar", "✨ Widgets"),
                L("🧩 Modül Düzeni", "🧩 Modules")
            };
            string[] tabTips = {
                L("Dil, hava durumu konumu, tema rengi ve saydamlık", "Language, weather location, theme color & opacity"),
                L("Takvim Widget ve Timer Widget eklentileri", "Calendar Widget & Timer Widget companions"),
                L("Ana widget modül sıralaması ve telemetri öğeleri", "Main widget module order & telemetry metrics")
            };
            for (int ti = 0; ti < 3; ti++)
            {
                Button tb = CreateStyledIconButton("Transparent", "Transparent", tabTips[ti]);
                tb.Padding = new Thickness(6, 6, 6, 6);
                tb.Margin = new Thickness(ti == 0 ? 0 : 2, 0, ti == 2 ? 0 : 2, 0);
                TextBlock lbl = new TextBlock
                {
                    Text = tabTitles[ti],
                    FontSize = 11,
                    FontWeight = FontWeights.SemiBold,
                    TextTrimming = TextTrimming.CharacterEllipsis
                };
                tb.Content = lbl;
                tabBtns[ti] = tb;
                tabLbls[ti] = lbl;
                tabBar.Children.Add(tb);
            }
            tabShell.Child = tabBar;
            Grid.SetRow(tabShell, 1);
            rootLayout.Children.Add(tabShell);

            // Row 2: Smooth ScrollViewer containing Tab Panels
            ScrollViewer settingsScroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                PanningMode = PanningMode.VerticalOnly,
                Padding = new Thickness(0, 0, 4, 0)
            };
            ApplyThinDarkScrollBarStyle(settingsScroll);
            Grid.SetRow(settingsScroll, 2);
            rootLayout.Children.Add(settingsScroll);

            StackPanel scrollContentHost = new StackPanel { Margin = new Thickness(0, 0, 2, 4) };
            settingsScroll.Content = scrollContentHost;

            StackPanel[] tabPanels = new StackPanel[] { new StackPanel(), new StackPanel(), new StackPanel() };
            scrollContentHost.Children.Add(tabPanels[0]);
            scrollContentHost.Children.Add(tabPanels[1]);
            scrollContentHost.Children.Add(tabPanels[2]);

            Action syncAccentControls = null;
            Action syncTabsUi = () =>
            {
                for (int ti = 0; ti < 3; ti++)
                {
                    bool active = (currentSettingsTab == ti);
                    tabPanels[ti].Visibility = active ? Visibility.Visible : Visibility.Collapsed;
                    tabBtns[ti].Background = HexBrush(active ? "#38281E" : "Transparent");
                    tabBtns[ti].BorderBrush = HexBrush(active ? accentColorHex : "Transparent");
                    tabLbls[ti].Foreground = HexBrush(active ? "#FAF6F2" : "#9E8E82");
                }
                if (syncAccentControls != null) syncAccentControls();
            };
            for (int ti = 0; ti < 3; ti++)
            {
                int capturedTi = ti;
                tabBtns[ti].Click += (s, e) =>
                {
                    currentSettingsTab = capturedTi;
                    syncTabsUi();
                    settingsScroll.ScrollToTop();
                };
            }

            // =========================================================
            // TAB 0: APPEARANCE, LANGUAGE & WEATHER LOCATION
            // =========================================================
            Border langLocCard = CreateSettingsSectionCard(L("🌐 Dil & Hava Durumu", "🌐 Language & Weather"), L("Arayüz dili, sıcaklık birimi ve şehir konumu", "Interface language, temperature unit & city location"));
            StackPanel langLocStack = (StackPanel)langLocCard.Child;

            Grid langRow = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            langRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            langRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            langRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            langRow.Children.Add(new TextBlock
            {
                Text = L("Arayüz Dili", "Interface Language"),
                Foreground = HexBrush("#C7B9AE"),
                FontSize = 11.5,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 10, 0)
            });

            Button btnSetTr = CreateStyledIconButton(IsEn ? "#1D1815" : "#38281E", IsEn ? "#4A3C34" : accentColorHex, "Türkçe");
            btnSetTr.Margin = new Thickness(0, 0, 6, 0);
            btnSetTr.Padding = new Thickness(10, 4, 10, 4);
            btnSetTr.Content = new TextBlock { Text = "🇹🇷 Türkçe", Foreground = HexBrush("#FAF6F2"), FontSize = 11, FontWeight = FontWeights.SemiBold };
            btnSetTr.Click += (s, e) =>
            {
                if (appLanguage != "TR")
                {
                    appLanguage = "TR";
                    SaveSettings();
                    ApplyLanguage();
                    settingsWindow.Close();
                    OpenSettingsWindow();
                }
            };
            Grid.SetColumn(btnSetTr, 1);
            langRow.Children.Add(btnSetTr);

            Button btnSetEn = CreateStyledIconButton(IsEn ? "#38281E" : "#1D1815", IsEn ? accentColorHex : "#4A3C34", "English");
            btnSetEn.Padding = new Thickness(10, 4, 10, 4);
            btnSetEn.Content = new TextBlock { Text = "🇬🇧 English", Foreground = HexBrush("#FAF6F2"), FontSize = 11, FontWeight = FontWeights.SemiBold };
            btnSetEn.Click += (s, e) =>
            {
                if (appLanguage != "EN")
                {
                    appLanguage = "EN";
                    SaveSettings();
                    ApplyLanguage();
                    settingsWindow.Close();
                    OpenSettingsWindow();
                }
            };
            Grid.SetColumn(btnSetEn, 2);
            langRow.Children.Add(btnSetEn);
            langLocStack.Children.Add(langRow);

            Grid tempUnitRow = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            tempUnitRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            tempUnitRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            tempUnitRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            tempUnitRow.Children.Add(new TextBlock
            {
                Text = L("Sıcaklık Birimi", "Temperature Unit"),
                Foreground = HexBrush("#C7B9AE"),
                FontSize = 11.5,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 10, 0)
            });

            Button btnSetCelsius = CreateStyledIconButton(!useFahrenheit ? "#38281E" : "#1D1815", !useFahrenheit ? accentColorHex : "#4A3C34", "Celsius (°C)");
            btnSetCelsius.Margin = new Thickness(0, 0, 6, 0);
            btnSetCelsius.Padding = new Thickness(10, 4, 10, 4);
            btnSetCelsius.Content = new TextBlock { Text = "°C", Foreground = HexBrush("#FAF6F2"), FontSize = 11, FontWeight = FontWeights.SemiBold };

            Button btnSetFahrenheit = CreateStyledIconButton(useFahrenheit ? "#38281E" : "#1D1815", useFahrenheit ? accentColorHex : "#4A3C34", "Fahrenheit (°F)");
            btnSetFahrenheit.Padding = new Thickness(10, 4, 10, 4);
            btnSetFahrenheit.Content = new TextBlock { Text = "°F", Foreground = HexBrush("#FAF6F2"), FontSize = 11, FontWeight = FontWeights.SemiBold };

            Action syncTempUnitButtons = () =>
            {
                btnSetCelsius.Background = HexBrush(!useFahrenheit ? "#38281E" : "#1D1815");
                btnSetCelsius.BorderBrush = HexBrush(!useFahrenheit ? accentColorHex : "#4A3C34");
                btnSetFahrenheit.Background = HexBrush(useFahrenheit ? "#38281E" : "#1D1815");
                btnSetFahrenheit.BorderBrush = HexBrush(useFahrenheit ? accentColorHex : "#4A3C34");
            };

            btnSetCelsius.Click += (s, e) =>
            {
                if (useFahrenheit)
                {
                    useFahrenheit = false;
                    syncTempUnitButtons();
                    SaveSettings();
                    RefreshWeatherTemperatureUi();
                    ShowToast(L("Sıcaklık birimi: °C (Celsius)", "Temperature unit: °C (Celsius)"));
                }
            };
            Grid.SetColumn(btnSetCelsius, 1);
            tempUnitRow.Children.Add(btnSetCelsius);

            btnSetFahrenheit.Click += (s, e) =>
            {
                if (!useFahrenheit)
                {
                    useFahrenheit = true;
                    syncTempUnitButtons();
                    SaveSettings();
                    RefreshWeatherTemperatureUi();
                    ShowToast(L("Sıcaklık birimi: °F (Fahrenheit)", "Temperature unit: °F (Fahrenheit)"));
                }
            };
            Grid.SetColumn(btnSetFahrenheit, 2);
            tempUnitRow.Children.Add(btnSetFahrenheit);
            langLocStack.Children.Add(tempUnitRow);

            langLocStack.Children.Add(new TextBlock { Text = L("Hava Durumu Konumu (GPS veya Şehir/İlçe Adı)", "Weather Location (GPS or City Name)"), Foreground = HexBrush("#B8A99E"), FontSize = 11, Margin = new Thickness(0, 0, 0, 5) });
            Grid locRow = new Grid();
            locRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            locRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            locRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            TextBox txtCity = new TextBox
            {
                Text = locationName,
                Background = HexBrush("#1C1714"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 5, 8, 5),
                FontSize = 12,
                VerticalContentAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(txtCity, 0);
            locRow.Children.Add(txtCity);

            Button btnSaveCity = CreateStyledIconButton("#38281E", accentColorHex, L("Yazılan şehri kaydet", "Save entered city"));
            btnSaveCity.Margin = new Thickness(6, 0, 0, 0);
            btnSaveCity.Padding = new Thickness(10, 5, 10, 5);
            btnSaveCity.Content = new TextBlock { Text = L("Şehir Ara", "Search"), Foreground = HexBrush("#FAF6F2"), FontSize = 11, FontWeight = FontWeights.SemiBold };
            btnSaveCity.Click += (s, e) =>
            {
                string q = txtCity.Text.Trim();
                Task.Run(() =>
                {
                    GeoLookupResult r = LocationHelper.SearchCityByName(q, appLanguage);
                    if (r.Success)
                    {
                        locationMode = "Manual";
                        locationName = r.DisplayName;
                        locationLat = r.Latitude;
                        locationLon = r.Longitude;
                        Dispatcher.Invoke(() =>
                        {
                            txtLocationBadge.Text = locationName;
                            txtCity.Text = locationName;
                        });
                        SaveSettings();
                        FetchWeatherAsync();
                        ShowToast(L("Konum güncellendi: ", "Location updated: ") + locationName);
                    }
                    else
                    {
                        ShowToast(L("Şehir bulunamadı!", "City not found!"));
                    }
                });
            };
            Grid.SetColumn(btnSaveCity, 1);
            locRow.Children.Add(btnSaveCity);

            Button btnAutoGps = CreateStyledIconButton("#2A221E", "#4A3C34", L("GPS / Konum Servisi ile otomatik bul", "Auto-detect via GPS / Location Services"));
            btnAutoGps.Margin = new Thickness(6, 0, 0, 0);
            btnAutoGps.Padding = new Thickness(9, 5, 9, 5);
            btnAutoGps.Content = new TextBlock { Text = "📍 GPS", Foreground = HexBrush("#FAF6F2"), FontSize = 11 };
            btnAutoGps.Click += (s, e) =>
            {
                Task.Run(() =>
                {
                    GeoLookupResult r = LocationHelper.ResolveAutoLocation(appLanguage);
                    if (r.Success)
                    {
                        locationMode = "Auto";
                        locationName = r.DisplayName;
                        locationLat = r.Latitude;
                        locationLon = r.Longitude;
                        Dispatcher.Invoke(() =>
                        {
                            txtLocationBadge.Text = locationName;
                            txtCity.Text = locationName;
                        });
                        SaveSettings();
                        FetchWeatherAsync();
                        ShowToast(L("Otomatik konum: ", "Auto location: ") + locationName);
                    }
                });
            };
            Grid.SetColumn(btnAutoGps, 2);
            locRow.Children.Add(btnAutoGps);
            langLocStack.Children.Add(locRow);
            tabPanels[0].Children.Add(langLocCard);

            // Color Picker Card
            Border colorSecCard = CreateSettingsSectionCard(L("🎨 Ana Tema Rengi", "🎨 Theme Accent Color"), L("Tüm widget çerçeveleri ve grafikler seçilen renge uyarlanır", "All widget borders, charts & activity heatmap adapt to this color"));
            StackPanel colorSecStack = (StackPanel)colorSecCard.Child;

            Border previewSwatch = new Border
            {
                Width = 28,
                Height = 28,
                CornerRadius = new CornerRadius(7),
                Background = HexBrush(accentColorHex),
                BorderBrush = Brushes.White,
                BorderThickness = new Thickness(1.5),
                Margin = new Thickness(0, 0, 8, 0),
                VerticalAlignment = VerticalAlignment.Center
            };

            TextBox txtHexInput = new TextBox
            {
                Text = accentColorHex,
                Background = HexBrush("#1C1714"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 5, 8, 5),
                FontSize = 12,
                VerticalContentAlignment = VerticalAlignment.Center
            };

            FrameworkElement spectrumPicker = CreateInteractiveSpectrumPicker(accentColorHex, (pickedHex) =>
            {
                txtHexInput.Text = pickedHex;
                previewSwatch.Background = HexBrush(pickedHex);
                ApplyTheme(pickedHex, bgOpacityPercent);
                card.BorderBrush = HexBrush(pickedHex);
                syncTabsUi();
            });
            spectrumPicker.HorizontalAlignment = HorizontalAlignment.Center;
            colorSecStack.Children.Add(spectrumPicker);

            Grid colorCustomRow = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            colorCustomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            colorCustomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            colorCustomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            colorCustomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Grid.SetColumn(previewSwatch, 0);
            colorCustomRow.Children.Add(previewSwatch);
            Grid.SetColumn(txtHexInput, 1);
            colorCustomRow.Children.Add(txtHexInput);

            Button btnApplyHex = CreateStyledIconButton("#38281E", accentColorHex, L("Kodu Uygula", "Apply Hex Code"));
            btnApplyHex.Margin = new Thickness(6, 0, 0, 0);
            btnApplyHex.Padding = new Thickness(10, 5, 10, 5);
            btnApplyHex.Content = new TextBlock { Text = L("Uygula", "Apply"), Foreground = HexBrush("#FAF6F2"), FontSize = 11.5, FontWeight = FontWeights.SemiBold };
            btnApplyHex.Click += (s, e) =>
            {
                string val = txtHexInput.Text.Trim();
                if (!val.StartsWith("#")) val = "#" + val;
                try
                {
                    ParseColor(val);
                    previewSwatch.Background = HexBrush(val);
                    ApplyTheme(val, bgOpacityPercent);
                    card.BorderBrush = HexBrush(val);
                    syncTabsUi();
                }
                catch
                {
                    ShowToast(L("Geçersiz renk kodu! Örn: #E2925C", "Invalid color code! e.g. #E2925C"));
                }
            };
            Grid.SetColumn(btnApplyHex, 2);
            colorCustomRow.Children.Add(btnApplyHex);

            Button btnWinPalette = CreateStyledIconButton("#2A221E", "#4A3C34", L("Gelişmiş Renk Seçici Penceresini Aç", "Open Advanced Color Picker Dialog"));
            btnWinPalette.Margin = new Thickness(6, 0, 0, 0);
            btnWinPalette.Padding = new Thickness(9, 5, 9, 5);
            btnWinPalette.Content = new TextBlock { Text = L("🎨 Palet...", "🎨 Palette..."), Foreground = HexBrush("#FAF6F2"), FontSize = 11.5 };
            btnWinPalette.Click += (s, e) =>
            {
                Color cur = ParseColor(accentColorHex);
                using (var dlg = new System.Windows.Forms.ColorDialog())
                {
                    dlg.FullOpen = true;
                    dlg.AnyColor = true;
                    dlg.Color = System.Drawing.Color.FromArgb(cur.R, cur.G, cur.B);
                    if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        string hex = string.Format("#{0:X2}{1:X2}{2:X2}", dlg.Color.R, dlg.Color.G, dlg.Color.B);
                        txtHexInput.Text = hex;
                        previewSwatch.Background = HexBrush(hex);
                        ApplyTheme(hex, bgOpacityPercent);
                        card.BorderBrush = HexBrush(hex);
                        syncTabsUi();
                    }
                }
            };
            Grid.SetColumn(btnWinPalette, 3);
            colorCustomRow.Children.Add(btnWinPalette);
            colorSecStack.Children.Add(colorCustomRow);

            string[] presets = { "#E2925C", "#D97706", "#C08457", "#E07A5F", "#10B981", "#38BDF8", "#A78BFA", "#F43F5E" };
            string[] presetNames = IsEn
                ? new string[] { "Default (#E2925C)", "Amber", "Bronze Brown", "Coral", "Emerald", "Sky Blue", "Lavender", "Ruby" }
                : new string[] { "Varsayılan (#E2925C)", "Kehribar", "Bronz Kahve", "Mercan", "Zümrüt", "Gökyüzü", "Lavanta", "Yakut" };
            UniformGrid swatchGrid = new UniformGrid { Columns = 8 };
            for (int i = 0; i < presets.Length; i++)
            {
                string hex = presets[i];
                Border sw = new Border
                {
                    Width = 28,
                    Height = 28,
                    CornerRadius = new CornerRadius(14),
                    Background = HexBrush(hex),
                    BorderBrush = Brushes.White,
                    BorderThickness = new Thickness(hex.Equals(accentColorHex, StringComparison.OrdinalIgnoreCase) ? 2 : 0.5),
                    Cursor = Cursors.Hand,
                    ToolTip = presetNames[i]
                };
                sw.MouseLeftButtonDown += (s, e) =>
                {
                    txtHexInput.Text = hex;
                    previewSwatch.Background = HexBrush(hex);
                    ApplyTheme(hex, bgOpacityPercent);
                    card.BorderBrush = HexBrush(hex);
                    syncTabsUi();
                };
                swatchGrid.Children.Add(sw);
            }
            colorSecStack.Children.Add(swatchGrid);
            tabPanels[0].Children.Add(colorSecCard);

            // Opacity & Fit Card
            Border opSecCard = CreateSettingsSectionCard(L("🪟 Saydamlık & Pencere", "🪟 Opacity & Window"), L("Arka plan saydamlığını ve widget boyutunu ayarlayın", "Adjust background transparency & main widget height"));
            StackPanel opSecStack = (StackPanel)opSecCard.Child;

            Grid opRow = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            opRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            opRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            opRow.Children.Add(new TextBlock { Text = L("Arka Plan Opaklığı", "Background Opacity"), Foreground = HexBrush("#C7B9AE"), FontSize = 11.5 });
            TextBlock txtOpVal = new TextBlock { Text = IsEn ? (bgOpacityPercent + "%") : ("%" + bgOpacityPercent), Foreground = HexBrush("#FAF6F2"), FontSize = 12, FontWeight = FontWeights.Bold };
            Grid.SetColumn(txtOpVal, 1);
            opRow.Children.Add(txtOpVal);
            opSecStack.Children.Add(opRow);

            Border opSliderHost = new Border();
            Action rebuildOpacitySlider = () =>
            {
                Slider slOpacity = CreateModernSlider(accentColorHex, bgOpacityPercent);
                slOpacity.Minimum = 30;
                slOpacity.Maximum = 100;
                slOpacity.Value = bgOpacityPercent;
                slOpacity.ValueChanged += (s, e) =>
                {
                    int v = (int)Math.Round(e.NewValue);
                    txtOpVal.Text = IsEn ? (v + "%") : ("%" + v);
                    ApplyTheme(accentColorHex, v);
                };
                opSliderHost.Child = slOpacity;
            };
            string lastSyncedAccent = accentColorHex;
            syncAccentControls = () =>
            {
                if (!string.Equals(lastSyncedAccent, accentColorHex, StringComparison.OrdinalIgnoreCase))
                {
                    lastSyncedAccent = accentColorHex;
                    ApplyThinDarkScrollBarStyle(settingsScroll);
                    btnApplyHex.BorderBrush = HexBrush(accentColorHex);
                    rebuildOpacitySlider();
                }
            };
            rebuildOpacitySlider();
            opSecStack.Children.Add(opSliderHost);

            Button btnFit = CreateStyledIconButton("#2E241E", "#4A3C34", L("Widget boyunu içerik kadar küçült/sığdır", "Auto-fit widget height to content"));
            btnFit.Margin = new Thickness(0, 4, 0, 0);
            btnFit.Padding = new Thickness(10, 7, 10, 7);
            btnFit.Content = new TextBlock { Text = L("📐 Widget Yüksekliğini İçeriğe Sığdır", "📐 Auto-Fit Widget Height to Content"), Foreground = HexBrush("#FAF6F2"), FontSize = 11.5, FontWeight = FontWeights.Medium };
            btnFit.Click += (s, e) =>
            {
                FitHeightToContentIfCompact();
                ShowToast(L("Yükseklik içeriğe göre optimize edildi", "Height optimized to fit content"));
            };
            opSecStack.Children.Add(btnFit);
            tabPanels[0].Children.Add(opSecCard);

            // =========================================================
            // TAB 1: COMPANION WIDGETS (CALENDAR & TIMER)
            // =========================================================
            Border calCompanionCard = new Border
            {
                CornerRadius = new CornerRadius(11),
                Background = HexBrush(showCalendarWidget ? "#2C221C" : "#221C18"),
                BorderBrush = HexBrush(showCalendarWidget ? accentColorHex : "#3B302A"),
                BorderThickness = new Thickness(1.2),
                Padding = new Thickness(13, 11, 13, 11),
                Margin = new Thickness(0, 0, 0, 10)
            };
            StackPanel calCompanionStack = new StackPanel();
            Grid calCompanionTop = new Grid();
            calCompanionTop.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            calCompanionTop.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel calCompanionInfo = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0) };
            calCompanionInfo.Children.Add(new TextBlock
            {
                Text = L("📅 Takvim Widget'ı (iCal Destekli)", "📅 Calendar Widget (iCal Sync)"),
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                TextWrapping = TextWrapping.Wrap
            });
            calCompanionInfo.Children.Add(new TextBlock
            {
                Text = L("Aylık takvim, iCal (.ics) senkronizasyonu ve hızlı etkinlik ekleme", "Monthly desktop calendar with iCal (.ics) sync & quick event capture"),
                Foreground = HexBrush("#9E8E82"),
                FontSize = 10.5,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 2, 0, 0)
            });
            Grid.SetColumn(calCompanionInfo, 0);
            calCompanionTop.Children.Add(calCompanionInfo);

            Button btnToggleCalWidget = CreateStyledIconButton(
                showCalendarWidget ? "#38281E" : "#1D1815",
                showCalendarWidget ? accentColorHex : "#3E322B",
                L("Takvim masaüstü widget'ını aç veya kapat", "Enable or disable the Calendar desktop widget"));
            btnToggleCalWidget.Padding = new Thickness(11, 5, 11, 5);
            btnToggleCalWidget.MinWidth = 72;
            btnToggleCalWidget.VerticalAlignment = VerticalAlignment.Center;
            TextBlock txtToggleCalWidget = new TextBlock
            {
                Text = showCalendarWidget ? L("✓ Açık", "✓ On") : L("Kapalı", "Off"),
                Foreground = HexBrush(showCalendarWidget ? "#FAF6F2" : "#8E7F74"),
                FontSize = 11,
                FontWeight = FontWeights.Bold
            };
            btnToggleCalWidget.Content = txtToggleCalWidget;
            btnToggleCalWidget.Click += (s, e) =>
            {
                SetCalendarWidgetVisible(!showCalendarWidget);
                calCompanionCard.Background = HexBrush(showCalendarWidget ? "#2C221C" : "#221C18");
                calCompanionCard.BorderBrush = HexBrush(showCalendarWidget ? accentColorHex : "#3B302A");
                btnToggleCalWidget.Background = HexBrush(showCalendarWidget ? "#38281E" : "#1D1815");
                btnToggleCalWidget.BorderBrush = HexBrush(showCalendarWidget ? accentColorHex : "#3E322B");
                txtToggleCalWidget.Text = showCalendarWidget ? L("✓ Açık", "✓ On") : L("Kapalı", "Off");
                txtToggleCalWidget.Foreground = HexBrush(showCalendarWidget ? "#FAF6F2" : "#8E7F74");
            };
            Grid.SetColumn(btnToggleCalWidget, 1);
            calCompanionTop.Children.Add(btnToggleCalWidget);
            calCompanionStack.Children.Add(calCompanionTop);

            calCompanionStack.Children.Add(new TextBlock
            {
                Text = L("Google Takvim Gizli iCal (.ics) Adresi (İsteğe Bağlı)", "Google Calendar Secret iCal (.ics) URL (Optional)"),
                Foreground = HexBrush("#B8A99E"),
                FontSize = 10.5,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 10, 0, 4)
            });
            Grid calIcalRow = new Grid();
            calIcalRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            calIcalRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            TextBox txtIcalUrl = new TextBox
            {
                Text = string.IsNullOrEmpty(calendarSecretIcalUrl) ? "" : calendarSecretIcalUrl,
                Background = HexBrush("#1C1714"),
                Foreground = HexBrush("#E6DDD6"),
                BorderBrush = HexBrush("#3E322B"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(7, 4, 7, 4),
                FontSize = 10.5,
                VerticalContentAlignment = VerticalAlignment.Center,
                ToolTip = L("Google Takvim Ayarları -> 'iCal biçimindeki gizli adres' (.ics) linkini buraya yapıştırabilirsiniz", "Paste your Google Calendar 'Secret address in iCal format' (.ics) URL here")
            };
            Grid.SetColumn(txtIcalUrl, 0);
            calIcalRow.Children.Add(txtIcalUrl);

            Button btnSaveIcal = CreateStyledIconButton("#2E241E", "#4A3C34", L("iCal adresini kaydet ve senkronize et", "Save & sync iCal feed"));
            btnSaveIcal.Margin = new Thickness(6, 0, 0, 0);
            btnSaveIcal.Padding = new Thickness(10, 4, 10, 4);
            btnSaveIcal.Content = new TextBlock { Text = L("🔗 Kaydet", "🔗 Save"), Foreground = HexBrush("#E6DDD6"), FontSize = 10.5, FontWeight = FontWeights.SemiBold };
            btnSaveIcal.Click += (s, e) =>
            {
                calendarSecretIcalUrl = txtIcalUrl.Text.Trim();
                SaveSettings();
                if (showCalendarWidget) Task.Run(() => LoadAndSyncCalendarEventsAsync(true));
                ShowToast(L("Takvim iCal bağlantısı kaydedildi", "Calendar iCal URL saved"));
            };
            Grid.SetColumn(btnSaveIcal, 1);
            calIcalRow.Children.Add(btnSaveIcal);
            calCompanionStack.Children.Add(calIcalRow);

            calCompanionCard.Child = calCompanionStack;
            tabPanels[1].Children.Add(calCompanionCard);

            // Standalone Timer Widget Companion Card
            Border timerCompanionCard = new Border
            {
                CornerRadius = new CornerRadius(11),
                Background = HexBrush(showTimerWidget ? "#2C221C" : "#221C18"),
                BorderBrush = HexBrush(showTimerWidget ? accentColorHex : "#3B302A"),
                BorderThickness = new Thickness(1.2),
                Padding = new Thickness(13, 11, 13, 11),
                Margin = new Thickness(0, 0, 0, 10)
            };
            Grid timerCompanionTop = new Grid();
            timerCompanionTop.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            timerCompanionTop.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel timerCompanionInfo = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0) };
            timerCompanionInfo.Children.Add(new TextBlock
            {
                Text = L("⏱ Timer Widgeti", "⏱ Timer Widget"),
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 12,
                FontWeight = FontWeights.Bold,
                TextWrapping = TextWrapping.Wrap
            });
            timerCompanionInfo.Children.Add(new TextBlock
            {
                Text = L("Normal zamanlayıcı, otomatik oyun algılayan Eğlence Modu, Pomodoro ve yıllık aktivite ısı haritası", "Stopwatch, auto game-detecting Gaming mode, Study Pomodoro & yearly activity heatmap"),
                Foreground = HexBrush("#9E8E82"),
                FontSize = 10.5,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 2, 0, 0)
            });
            Grid.SetColumn(timerCompanionInfo, 0);
            timerCompanionTop.Children.Add(timerCompanionInfo);

            Button btnToggleTimerWidget = CreateStyledIconButton(
                showTimerWidget ? "#38281E" : "#1D1815",
                showTimerWidget ? accentColorHex : "#3E322B",
                L("Timer masaüstü widget'ını aç veya kapat", "Enable or disable the Timer desktop widget"));
            btnToggleTimerWidget.Padding = new Thickness(11, 5, 11, 5);
            btnToggleTimerWidget.MinWidth = 72;
            btnToggleTimerWidget.VerticalAlignment = VerticalAlignment.Center;
            TextBlock txtToggleTimerWidget = new TextBlock
            {
                Text = showTimerWidget ? L("✓ Açık", "✓ On") : L("Kapalı", "Off"),
                Foreground = HexBrush(showTimerWidget ? "#FAF6F2" : "#8E7F74"),
                FontSize = 11,
                FontWeight = FontWeights.Bold
            };
            btnToggleTimerWidget.Content = txtToggleTimerWidget;
            btnToggleTimerWidget.Click += (s, e) =>
            {
                SetTimerWidgetVisible(!showTimerWidget);
                timerCompanionCard.Background = HexBrush(showTimerWidget ? "#2C221C" : "#221C18");
                timerCompanionCard.BorderBrush = HexBrush(showTimerWidget ? accentColorHex : "#3B302A");
                btnToggleTimerWidget.Background = HexBrush(showTimerWidget ? "#38281E" : "#1D1815");
                btnToggleTimerWidget.BorderBrush = HexBrush(showTimerWidget ? accentColorHex : "#3E322B");
                txtToggleTimerWidget.Text = showTimerWidget ? L("✓ Açık", "✓ On") : L("Kapalı", "Off");
                txtToggleTimerWidget.Foreground = HexBrush(showTimerWidget ? "#FAF6F2" : "#8E7F74");
            };
            Grid.SetColumn(btnToggleTimerWidget, 1);
            timerCompanionTop.Children.Add(btnToggleTimerWidget);
            timerCompanionCard.Child = timerCompanionTop;
            tabPanels[1].Children.Add(timerCompanionCard);

            // =========================================================
            // TAB 2: MODULE ORDER, VISIBILITY & TELEMETRY SUB-TOGGLES
            // =========================================================
            Border modulesOrderCard = CreateSettingsSectionCard(L("🧩 Ana Widget Modülleri", "🧩 Main Widget Modules"), L("Tut-sürükle veya ▲/▼ ile sıralayın, sağdaki butonla gizleyip açın", "Drag or use ▲/▼ to reorder, toggle visibility on the right"));
            StackPanel modulesOrderCardStack = (StackPanel)modulesOrderCard.Child;

            StackPanel modulesOrderList = new StackPanel();
            int draggingModuleIdx = -1;
            Action rebuildModulesOrderUi = null;

            rebuildModulesOrderUi = () =>
            {
                modulesOrderList.Children.Clear();
                for (int i = 0; i < sectionOrder.Count; i++)
                {
                    int idx = i;
                    string key = sectionOrder[idx];
                    bool enabled = IsSectionEnabled(key);
                    bool isDraggingThis = (draggingModuleIdx == idx);

                    Border rowBorder = new Border
                    {
                        CornerRadius = new CornerRadius(8),
                        Background = HexBrush(isDraggingThis ? "#3A2B21" : (enabled ? "#1E1916" : "#181412")),
                        BorderBrush = HexBrush(isDraggingThis ? accentColorHex : (enabled ? "#4A3C34" : "#2E2520")),
                        BorderThickness = new Thickness(isDraggingThis ? 1.5 : 1),
                        Padding = new Thickness(10, 6, 8, 6),
                        Margin = new Thickness(0, 0, 0, 5),
                        Cursor = Cursors.SizeNS,
                        ToolTip = L("Sıralamayı değiştirmek için basılı tutup yukarı/aşağı sürükleyin", "Hold and drag up/down to reorder module")
                    };

                    Grid rg = new Grid();
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                    TextBlock grip = new TextBlock
                    {
                        Text = "⠿",
                        Foreground = HexBrush(isDraggingThis ? accentColorHex : "#8E7F74"),
                        FontSize = 13.5,
                        Margin = new Thickness(0, 0, 8, 0),
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(grip, 0);
                    rg.Children.Add(grip);

                    TextBlock title = new TextBlock
                    {
                        Text = (idx + 1) + ". " + GetSectionDisplayName(key),
                        Foreground = HexBrush(enabled ? "#FAF6F2" : "#7E7067"),
                        FontSize = 11.5,
                        FontWeight = FontWeights.SemiBold,
                        VerticalAlignment = VerticalAlignment.Center,
                        TextTrimming = TextTrimming.CharacterEllipsis,
                        Margin = new Thickness(0, 0, 8, 0)
                    };
                    Grid.SetColumn(title, 1);
                    rg.Children.Add(title);

                    Button btnUp = CreateStyledIconButton("#26201C", "#3E322B", L("Yukarı Taşı", "Move Up"));
                    btnUp.Padding = new Thickness(6, 3, 6, 3);
                    btnUp.Margin = new Thickness(0, 0, 3, 0);
                    btnUp.IsEnabled = (idx > 0);
                    btnUp.Opacity = (idx > 0) ? 1.0 : 0.35;
                    btnUp.Content = new TextBlock { Text = "▲", Foreground = HexBrush("#C7B9AE"), FontSize = 9.5 };
                    btnUp.Click += (s, e) =>
                    {
                        if (idx > 0)
                        {
                            string tmp = sectionOrder[idx - 1];
                            sectionOrder[idx - 1] = sectionOrder[idx];
                            sectionOrder[idx] = tmp;
                            ApplyLayoutAndVisibility();
                            SaveSettings();
                            rebuildModulesOrderUi();
                        }
                        e.Handled = true;
                    };
                    Grid.SetColumn(btnUp, 2);
                    rg.Children.Add(btnUp);

                    Button btnDown = CreateStyledIconButton("#26201C", "#3E322B", L("Aşağı Taşı", "Move Down"));
                    btnDown.Padding = new Thickness(6, 3, 6, 3);
                    btnDown.Margin = new Thickness(0, 0, 6, 0);
                    btnDown.IsEnabled = (idx < sectionOrder.Count - 1);
                    btnDown.Opacity = (idx < sectionOrder.Count - 1) ? 1.0 : 0.35;
                    btnDown.Content = new TextBlock { Text = "▼", Foreground = HexBrush("#C7B9AE"), FontSize = 9.5 };
                    btnDown.Click += (s, e) =>
                    {
                        if (idx < sectionOrder.Count - 1)
                        {
                            string tmp = sectionOrder[idx + 1];
                            sectionOrder[idx + 1] = sectionOrder[idx];
                            sectionOrder[idx] = tmp;
                            ApplyLayoutAndVisibility();
                            SaveSettings();
                            rebuildModulesOrderUi();
                        }
                        e.Handled = true;
                    };
                    Grid.SetColumn(btnDown, 3);
                    rg.Children.Add(btnDown);

                    Button btnToggle = CreateStyledIconButton(
                        enabled ? "#38281E" : "#1D1815",
                        enabled ? accentColorHex : "#3E322B",
                        L("Bu modülü göster veya gizle", "Show or hide this module"));
                    btnToggle.Padding = new Thickness(9, 3, 9, 3);
                    btnToggle.MinWidth = 60;
                    btnToggle.Content = new TextBlock
                    {
                        Text = enabled ? L("✓ Açık", "✓ On") : L("Kapalı", "Off"),
                        Foreground = HexBrush(enabled ? "#FAF6F2" : "#8E7F74"),
                        FontSize = 10.5,
                        FontWeight = FontWeights.SemiBold
                    };
                    btnToggle.Click += (s, e) =>
                    {
                        bool nextState = !IsSectionEnabled(key);
                        SetSectionEnabled(key, nextState);
                        if (key == "monitors" && nextState && monitorSlots.Count == 0)
                        {
                            Task.Run(() => DiscoverAndSyncMonitors(true));
                        }
                        ApplyLayoutAndVisibility();
                        FitHeightToContentIfCompact();
                        SaveSettings();
                        rebuildModulesOrderUi();
                        e.Handled = true;
                    };
                    Grid.SetColumn(btnToggle, 4);
                    rg.Children.Add(btnToggle);

                    rowBorder.Child = rg;

                    rowBorder.MouseLeftButtonDown += (s, e) =>
                    {
                        draggingModuleIdx = idx;
                        modulesOrderList.CaptureMouse();
                        rebuildModulesOrderUi();
                        e.Handled = true;
                    };

                    modulesOrderList.Children.Add(rowBorder);
                }
            };

            modulesOrderList.MouseMove += (s, e) =>
            {
                if (draggingModuleIdx >= 0 && e.LeftButton == MouseButtonState.Pressed)
                {
                    Point pt = e.GetPosition(modulesOrderList);
                    double rowH = Math.Max(32.0, modulesOrderList.ActualHeight / Math.Max(1, sectionOrder.Count));
                    int targetIdx = (int)(pt.Y / rowH);
                    if (targetIdx < 0) targetIdx = 0;
                    if (targetIdx >= sectionOrder.Count) targetIdx = sectionOrder.Count - 1;

                    if (targetIdx != draggingModuleIdx)
                    {
                        string item = sectionOrder[draggingModuleIdx];
                        sectionOrder.RemoveAt(draggingModuleIdx);
                        sectionOrder.Insert(targetIdx, item);
                        draggingModuleIdx = targetIdx;
                        ApplyLayoutAndVisibility();
                        SaveSettings();
                        rebuildModulesOrderUi();
                    }
                }
            };

            modulesOrderList.MouseLeftButtonUp += (s, e) =>
            {
                if (draggingModuleIdx >= 0)
                {
                    draggingModuleIdx = -1;
                    if (modulesOrderList.IsMouseCaptured) modulesOrderList.ReleaseMouseCapture();
                    rebuildModulesOrderUi();
                }
            };

            rebuildModulesOrderUi();
            modulesOrderCardStack.Children.Add(modulesOrderList);
            tabPanels[2].Children.Add(modulesOrderCard);

            // Telemetry Sub-Items Visibility Section
            Border teleSubCard = CreateSettingsSectionCard(L("📊 Telemetri İçeriği", "📊 Telemetry Metrics"), L("Ana widget içindeki donanım sensörlerini seçin", "Choose which hardware stats appear inside the main widget"));
            StackPanel teleSubStack = (StackPanel)teleSubCard.Child;

            UniformGrid teleSubGrid = new UniformGrid { Columns = 2 };
            Action rebuildTeleSubGrid = null;
            rebuildTeleSubGrid = () =>
            {
                teleSubGrid.Children.Clear();
                string[] tKeys = { "cpu", "ram", "gpu", "vram", "net", "disks" };
                string[] tLabels = {
                    L("⚙ İşlemci (CPU)", "⚙ Processor (CPU)"),
                    L("▦ Bellek (RAM)", "▦ Memory (RAM)"),
                    L("▣ Ekran Kartı (GPU)", "▣ Graphics (GPU)"),
                    L("▤ Video Belleği (VRAM)", "▤ Video Memory (VRAM)"),
                    L("⇄ Ağ Trafiği & Ping", "⇄ Network & Ping"),
                    L("⛁ Diskler (C:, D:...)", "⛁ Drives (C:, D:...)")
                };
                bool[] tStates = { showTeleCpu, showTeleRam, showTeleGpu, showTeleVram, showTeleNet, showTeleDisks };

                for (int i = 0; i < tKeys.Length; i++)
                {
                    int idx = i;
                    string tk = tKeys[idx];
                    bool on = tStates[idx];

                    Button bSub = CreateStretchSettingsButton(on ? "#38281E" : "#1D1815", on ? accentColorHex : "#3A2F29", tLabels[idx]);
                    bSub.Margin = new Thickness(idx % 2 == 0 ? 0 : 3, 0, idx % 2 == 0 ? 3 : 0, 6);
                    bSub.Padding = new Thickness(9, 6, 9, 6);

                    Grid bg = new Grid();
                    bg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    bg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                    TextBlock lbl = new TextBlock
                    {
                        Text = tLabels[idx],
                        Foreground = HexBrush(on ? "#FAF6F2" : "#8E7F74"),
                        FontSize = 11,
                        FontWeight = FontWeights.SemiBold,
                        VerticalAlignment = VerticalAlignment.Center,
                        TextTrimming = TextTrimming.CharacterEllipsis,
                        Margin = new Thickness(0, 0, 8, 0)
                    };
                    Grid.SetColumn(lbl, 0);
                    bg.Children.Add(lbl);

                    TextBlock stateBadge = new TextBlock
                    {
                        Text = on ? "✓" : "✕",
                        Foreground = HexBrush(on ? accentColorHex : "#6E5E55"),
                        FontSize = 11,
                        FontWeight = FontWeights.Bold,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(stateBadge, 1);
                    bg.Children.Add(stateBadge);

                    bSub.Content = bg;
                    bSub.Click += (s, e) =>
                    {
                        if (tk == "cpu") showTeleCpu = !showTeleCpu;
                        else if (tk == "ram") showTeleRam = !showTeleRam;
                        else if (tk == "gpu") showTeleGpu = !showTeleGpu;
                        else if (tk == "vram") showTeleVram = !showTeleVram;
                        else if (tk == "net") showTeleNet = !showTeleNet;
                        else if (tk == "disks") showTeleDisks = !showTeleDisks;

                        ApplyLayoutAndVisibility();
                        FitHeightToContentIfCompact();
                        SaveSettings();
                        rebuildTeleSubGrid();
                    };
                    teleSubGrid.Children.Add(bSub);
                }
            };
            rebuildTeleSubGrid();
            teleSubStack.Children.Add(teleSubGrid);

            Button btnFitLayout = CreateStyledIconButton("#2E241E", "#4A3C34", L("Widget boyunu seçili modüllere göre otomatik sığdır", "Auto-fit widget height to active modules"));
            btnFitLayout.Margin = new Thickness(0, 4, 0, 0);
            btnFitLayout.Padding = new Thickness(10, 7, 10, 7);
            btnFitLayout.Content = new TextBlock { Text = L("📐 Widget Yüksekliğini Modüllere Göre Sığdır", "📐 Auto-Fit Height to Selected Modules"), Foreground = HexBrush("#FAF6F2"), FontSize = 11.5, FontWeight = FontWeights.Medium };
            btnFitLayout.Click += (s, e) =>
            {
                FitHeightToContentIfCompact();
                ShowToast(L("Yükseklik aktif modüllere göre optimize edildi", "Height optimized for active modules"));
            };
            teleSubStack.Children.Add(btnFitLayout);
            tabPanels[2].Children.Add(teleSubCard);

            syncTabsUi();
            card.Child = rootLayout;
            settingsWindow.Content = card;
            settingsWindow.Show();
        }

        private FrameworkElement CreateInteractiveSpectrumPicker(string initialHex, Action<string> onColorPicked)
        {
            double currentH = 24, currentS = 0.70, currentV = 0.89;
            try
            {
                Color c = ParseColor(initialHex);
                RgbToHsv(c.R, c.G, c.B, out currentH, out currentS, out currentV);
            }
            catch { }

            StackPanel container = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };

            double svWidth = 330;
            double svHeight = 96;

            Border svBorder = new Border
            {
                Width = svWidth,
                Height = svHeight,
                CornerRadius = new CornerRadius(8),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                ClipToBounds = true,
                Cursor = Cursors.Cross,
                Margin = new Thickness(0, 0, 0, 8)
            };

            Grid svGrid = new Grid();
            Border hueBaseLayer = new Border { Background = new SolidColorBrush(HsvToRgb(currentH, 1.0, 1.0)) };

            LinearGradientBrush whiteHoriz = new LinearGradientBrush(Colors.White, Color.FromArgb(0, 255, 255, 255), new Point(0, 0), new Point(1, 0));
            whiteHoriz.Freeze();
            Border satLayer = new Border { Background = whiteHoriz };

            LinearGradientBrush blackVert = new LinearGradientBrush(Color.FromArgb(0, 0, 0, 0), Colors.Black, new Point(0, 0), new Point(0, 1));
            blackVert.Freeze();
            Border valLayer = new Border { Background = blackVert };

            Canvas svCanvas = new Canvas { Width = svWidth, Height = svHeight };
            Border svThumb = new Border
            {
                Width = 14,
                Height = 14,
                CornerRadius = new CornerRadius(7),
                BorderBrush = Brushes.White,
                BorderThickness = new Thickness(2),
                Background = Brushes.Transparent,
                IsHitTestVisible = false
            };
            svThumb.Effect = new DropShadowEffect { Color = Colors.Black, BlurRadius = 4, ShadowDepth = 0, Opacity = 0.9 };
            svCanvas.Children.Add(svThumb);

            svGrid.Children.Add(hueBaseLayer);
            svGrid.Children.Add(satLayer);
            svGrid.Children.Add(valLayer);
            svGrid.Children.Add(svCanvas);
            svBorder.Child = svGrid;

            Border hueBarBorder = new Border
            {
                Width = svWidth,
                Height = 16,
                CornerRadius = new CornerRadius(8),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                ClipToBounds = true,
                Cursor = Cursors.Hand
            };

            LinearGradientBrush rainbow = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 0) };
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(255, 0, 0), 0.00));
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(255, 255, 0), 0.17));
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(0, 255, 0), 0.33));
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(0, 255, 255), 0.50));
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(0, 0, 255), 0.67));
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(255, 0, 255), 0.83));
            rainbow.GradientStops.Add(new GradientStop(Color.FromRgb(255, 0, 0), 1.00));
            rainbow.Freeze();

            Canvas hueCanvas = new Canvas { Width = svWidth, Height = 16, Background = rainbow };
            Border hueThumb = new Border
            {
                Width = 8,
                Height = 16,
                CornerRadius = new CornerRadius(3),
                Background = Brushes.White,
                BorderBrush = Brushes.Black,
                BorderThickness = new Thickness(1),
                IsHitTestVisible = false
            };
            hueCanvas.Children.Add(hueThumb);
            hueBarBorder.Child = hueCanvas;

            Action updateThumbsAndNotify = () =>
            {
                Canvas.SetLeft(svThumb, Math.Max(0, Math.Min(svWidth - 14, currentS * svWidth - 7)));
                Canvas.SetTop(svThumb, Math.Max(0, Math.Min(svHeight - 14, (1.0 - currentV) * svHeight - 7)));
                Canvas.SetLeft(hueThumb, Math.Max(0, Math.Min(svWidth - 8, (currentH / 360.0) * svWidth - 4)));

                hueBaseLayer.Background = new SolidColorBrush(HsvToRgb(currentH, 1.0, 1.0));
                Color picked = HsvToRgb(currentH, currentS, currentV);
                string hex = string.Format("#{0:X2}{1:X2}{2:X2}", picked.R, picked.G, picked.B);
                if (onColorPicked != null) onColorPicked(hex);
            };

            Canvas.SetLeft(svThumb, Math.Max(0, Math.Min(svWidth - 14, currentS * svWidth - 7)));
            Canvas.SetTop(svThumb, Math.Max(0, Math.Min(svHeight - 14, (1.0 - currentV) * svHeight - 7)));
            Canvas.SetLeft(hueThumb, Math.Max(0, Math.Min(svWidth - 8, (currentH / 360.0) * svWidth - 4)));

            Action<Point> handleSvMouse = (pt) =>
            {
                currentS = Math.Max(0.0, Math.Min(1.0, pt.X / svWidth));
                currentV = Math.Max(0.05, Math.Min(1.0, 1.0 - (pt.Y / svHeight)));
                updateThumbsAndNotify();
            };

            svBorder.MouseLeftButtonDown += (s, e) =>
            {
                svBorder.CaptureMouse();
                handleSvMouse(e.GetPosition(svCanvas));
                e.Handled = true;
            };
            svBorder.MouseMove += (s, e) =>
            {
                if (svBorder.IsMouseCaptured && e.LeftButton == MouseButtonState.Pressed)
                {
                    handleSvMouse(e.GetPosition(svCanvas));
                    e.Handled = true;
                }
            };
            svBorder.MouseLeftButtonUp += (s, e) =>
            {
                if (svBorder.IsMouseCaptured) svBorder.ReleaseMouseCapture();
                e.Handled = true;
            };

            Action<Point> handleHueMouse = (pt) =>
            {
                currentH = Math.Max(0.0, Math.Min(360.0, (pt.X / svWidth) * 360.0));
                updateThumbsAndNotify();
            };

            hueBarBorder.MouseLeftButtonDown += (s, e) =>
            {
                hueBarBorder.CaptureMouse();
                handleHueMouse(e.GetPosition(hueCanvas));
                e.Handled = true;
            };
            hueBarBorder.MouseMove += (s, e) =>
            {
                if (hueBarBorder.IsMouseCaptured && e.LeftButton == MouseButtonState.Pressed)
                {
                    handleHueMouse(e.GetPosition(hueCanvas));
                    e.Handled = true;
                }
            };
            hueBarBorder.MouseLeftButtonUp += (s, e) =>
            {
                if (hueBarBorder.IsMouseCaptured) hueBarBorder.ReleaseMouseCapture();
                e.Handled = true;
            };

            container.Children.Add(svBorder);
            container.Children.Add(hueBarBorder);
            return container;
        }

        private static Color HsvToRgb(double h, double s, double v)
        {
            double c = v * s;
            double x = c * (1.0 - Math.Abs(((h / 60.0) % 2.0) - 1.0));
            double m = v - c;
            double r1 = 0, g1 = 0, b1 = 0;

            if (h < 60) { r1 = c; g1 = x; b1 = 0; }
            else if (h < 120) { r1 = x; g1 = c; b1 = 0; }
            else if (h < 180) { r1 = 0; g1 = c; b1 = x; }
            else if (h < 240) { r1 = 0; g1 = x; b1 = c; }
            else if (h < 300) { r1 = x; g1 = 0; b1 = c; }
            else { r1 = c; g1 = 0; b1 = x; }

            byte r = (byte)Math.Round(Math.Max(0, Math.Min(255, (r1 + m) * 255.0)));
            byte g = (byte)Math.Round(Math.Max(0, Math.Min(255, (g1 + m) * 255.0)));
            byte b = (byte)Math.Round(Math.Max(0, Math.Min(255, (b1 + m) * 255.0)));
            return Color.FromRgb(r, g, b);
        }

        private static void RgbToHsv(byte r, byte g, byte b, out double h, out double s, out double v)
        {
            double rd = r / 255.0;
            double gd = g / 255.0;
            double bd = b / 255.0;
            double max = Math.Max(rd, Math.Max(gd, bd));
            double min = Math.Min(rd, Math.Min(gd, bd));
            double delta = max - min;

            h = 0;
            if (delta > 0.0001)
            {
                if (max == rd) h = 60.0 * (((gd - bd) / delta) % 6.0);
                else if (max == gd) h = 60.0 * (((bd - rd) / delta) + 2.0);
                else h = 60.0 * (((rd - gd) / delta) + 4.0);
                if (h < 0) h += 360.0;
            }
            s = max <= 0.0001 ? 0 : delta / max;
            v = max;
        }

        // ==========================================
        // MONITOR SDR / DDC BRIGHTNESS ENGINE (ZERO-OVERHEAD)
        // ==========================================
        private void UpdateMonitorLinkButtonUi()
        {
            if (btnMonitorLink == null) return;
            btnMonitorLink.Background = HexBrush(monitorLinkSync ? "#3A2B21" : "#221C19");
            btnMonitorLink.BorderBrush = HexBrush(monitorLinkSync ? accentColorHex : "#3A2E28");
            btnMonitorLink.ToolTip = monitorLinkSync
                ? L("Senkronize Mod Açık: Slider tüm monitörleri birlikte değiştirir (Ayırmak için tıkla)", "Sync Mode Active: Slider adjusts all monitors together (Click to separate)")
                : L("Ayrı Mod: Her monitör bağımsız kontrol edilir (Birleştirmek için tıkla)", "Separate Mode: Each monitor is controlled independently (Click to sync)");
            btnMonitorLink.Content = new TextBlock
            {
                Text = monitorLinkSync ? L("🔗 Birlikte", "🔗 Linked") : L("⛓ Ayrı", "⛓ Separate"),
                Foreground = HexBrush(monitorLinkSync ? accentColorHex : "#B8A99E"),
                FontSize = 10,
                FontWeight = FontWeights.SemiBold
            };
        }

        private void AttachMonitorSliderWheel(Slider sl, int monitorIndex)
        {
            sl.PreviewMouseWheel += (s, e) =>
            {
                int delta = e.Delta > 0 ? 5 : -5;
                int cur = (monitorIndex >= 0 && monitorIndex < monitorSlots.Count) ? monitorSlots[monitorIndex].CurrentBrightness : (int)Math.Round(sl.Value);
                int next = Math.Max(0, Math.Min(100, cur + delta));
                SetMonitorBrightnessFromUi(monitorIndex, next, monitorLinkSync);
                e.Handled = true;
            };
        }

        private void OnMonitorSliderValueChanged(int monitorIndex, double newValue)
        {
            if (isUpdatingMonitorUi) return;
            int target = Math.Max(0, Math.Min(100, (int)Math.Round(newValue)));
            SetMonitorBrightnessFromUi(monitorIndex, target, monitorLinkSync);
        }

        private void SetMonitorBrightnessFromUi(int sourceIndex, int targetPct, bool syncAll)
        {
            targetPct = Math.Max(0, Math.Min(100, targetPct));
            isUpdatingMonitorUi = true;
            try
            {
                if (syncAll)
                {
                    for (int i = 0; i < monitorSlots.Count; i++)
                    {
                        monitorSlots[i].CurrentBrightness = targetPct;
                        if (i < txtMonitorPercents.Count) txtMonitorPercents[i].Text = IsEn ? (targetPct + "%") : ("%" + targetPct);
                        if (i < sliderMonitors.Count && Math.Abs(sliderMonitors[i].Value - targetPct) >= 0.5)
                        {
                            sliderMonitors[i].Value = targetPct;
                        }
                        QueueMonitorBrightness(i, targetPct);
                    }
                }
                else
                {
                    if (sourceIndex >= 0 && sourceIndex < monitorSlots.Count)
                    {
                        monitorSlots[sourceIndex].CurrentBrightness = targetPct;
                        if (sourceIndex < txtMonitorPercents.Count) txtMonitorPercents[sourceIndex].Text = IsEn ? (targetPct + "%") : ("%" + targetPct);
                        if (sourceIndex < sliderMonitors.Count && Math.Abs(sliderMonitors[sourceIndex].Value - targetPct) >= 0.5)
                        {
                            sliderMonitors[sourceIndex].Value = targetPct;
                        }
                        QueueMonitorBrightness(sourceIndex, targetPct);
                    }
                }
            }
            finally
            {
                isUpdatingMonitorUi = false;
            }
        }

        private void QueueMonitorBrightness(int index, int pct)
        {
            if (index < 0 || index >= monitorSlots.Count) return;
            PhysicalMonitorSlot slot = monitorSlots[index];
            Interlocked.Exchange(ref slot.PendingBrightness, pct);

            if (Interlocked.CompareExchange(ref slot.WorkerBusy, 1, 0) == 0)
            {
                ThreadPool.QueueUserWorkItem(_ => RunMonitorDdcWorker(slot));
            }
        }

        private void RunMonitorDdcWorker(PhysicalMonitorSlot slot)
        {
            try
            {
                while (true)
                {
                    int target = Interlocked.Exchange(ref slot.PendingBrightness, -1);
                    if (target < 0) break;

                    if (slot.UseWindowsSdrWhiteLevel && slot.TargetId != 0)
                    {
                        MonitorDdcNative.SetSdrWhiteLevelPercent(slot.AdapterId, slot.TargetId, target);
                        Thread.Sleep(8);
                    }
                    else
                    {
                        uint span = (slot.MaxVal > slot.MinVal) ? (slot.MaxVal - slot.MinVal) : 100u;
                        uint rawVal = slot.MinVal + (uint)Math.Round((target / 100.0) * span);

                        lock (monitorHandleLock)
                        {
                            if (slot.Handle != IntPtr.Zero)
                            {
                                MonitorDdcNative.SetVCPFeature(slot.Handle, MonitorDdcNative.VCP_BRIGHTNESS, rawVal);
                            }
                        }
                        Thread.Sleep(28);
                    }
                }
            }
            catch { }
            finally
            {
                Interlocked.Exchange(ref slot.WorkerBusy, 0);
                if (Interlocked.CompareExchange(ref slot.PendingBrightness, -1, -1) >= 0)
                {
                    if (Interlocked.CompareExchange(ref slot.WorkerBusy, 1, 0) == 0)
                    {
                        ThreadPool.QueueUserWorkItem(_ => RunMonitorDdcWorker(slot));
                    }
                }
            }
        }

        private string FormatFriendlyMonitorName(string rawName, int idx)
        {
            if (string.IsNullOrWhiteSpace(rawName)) return L("Monitör ", "Monitor ") + (idx + 1);
            string n = rawName.Trim();
            if (n.IndexOf("Generic PnP", StringComparison.OrdinalIgnoreCase) >= 0)
                return L("Monitör ", "Monitor ") + (idx + 1);
            return n;
        }

        private void DiscoverAndSyncMonitors(bool isInitial)
        {
            try
            {
                List<MonitorDdcNative.WinDisplayTargetInfo> winTargets = MonitorDdcNative.QueryActiveDisplayTargets();
                List<IntPtr> hMonitors = new List<IntPtr>();
                MonitorDdcNative.EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (IntPtr hMon, IntPtr hdc, ref MonitorDdcNative.RECT r, IntPtr d) =>
                {
                    hMonitors.Add(hMon);
                    return true;
                }, IntPtr.Zero);

                List<PhysicalMonitorSlot> discovered = new List<PhysicalMonitorSlot>();

                for (int m = 0; m < hMonitors.Count; m++)
                {
                    string gdiDevName = null;
                    MonitorDdcNative.MONITORINFOEX mi = new MonitorDdcNative.MONITORINFOEX();
                    mi.cbSize = Marshal.SizeOf(typeof(MonitorDdcNative.MONITORINFOEX));
                    if (MonitorDdcNative.GetMonitorInfo(hMonitors[m], ref mi))
                    {
                        gdiDevName = mi.szDevice;
                    }

                    MonitorDdcNative.WinDisplayTargetInfo matchedTarget = null;
                    if (!string.IsNullOrEmpty(gdiDevName))
                    {
                        for (int t = 0; t < winTargets.Count; t++)
                        {
                            if (string.Equals(winTargets[t].GdiDeviceName, gdiDevName, StringComparison.OrdinalIgnoreCase))
                            {
                                matchedTarget = winTargets[t];
                                break;
                            }
                        }
                    }
                    if (matchedTarget == null && m < winTargets.Count)
                    {
                        matchedTarget = winTargets[m];
                    }

                    uint count = 0;
                    if (!MonitorDdcNative.GetNumberOfPhysicalMonitorsFromHMONITOR(hMonitors[m], out count) || count == 0)
                        continue;

                    MonitorDdcNative.PHYSICAL_MONITOR[] phys = new MonitorDdcNative.PHYSICAL_MONITOR[count];
                    if (!MonitorDdcNative.GetPhysicalMonitorsFromHMONITOR(hMonitors[m], count, phys))
                        continue;

                    for (int i = 0; i < count; i++)
                    {
                        IntPtr hPhys = phys[i].hPhysicalMonitor;
                        string rawDesc = phys[i].szPhysicalMonitorDescription;
                        if (matchedTarget != null && !string.IsNullOrWhiteSpace(matchedTarget.FriendlyName))
                        {
                            rawDesc = matchedTarget.FriendlyName;
                        }

                        uint pdwType, curVal = 50, maxVal = 100;
                        bool ddcOk = MonitorDdcNative.GetVCPFeatureAndVCPFeatureReply(hPhys, MonitorDdcNative.VCP_BRIGHTNESS, out pdwType, out curVal, out maxVal);

                        bool useSdr = false;
                        int pct = 60;
                        if (matchedTarget != null && matchedTarget.HdrEnabled)
                        {
                            useSdr = true;
                            pct = matchedTarget.SdrBrightnessPct;
                        }
                        else if (ddcOk && maxVal > 0)
                        {
                            pct = (int)Math.Round((curVal / (double)maxVal) * 100.0);
                            pct = Math.Max(0, Math.Min(100, pct));
                        }
                        else if (matchedTarget != null)
                        {
                            useSdr = true;
                            pct = matchedTarget.SdrBrightnessPct;
                        }

                        PhysicalMonitorSlot slot = new PhysicalMonitorSlot
                        {
                            Handle = hPhys,
                            Name = FormatFriendlyMonitorName(rawDesc, discovered.Count),
                            MinVal = 0,
                            MaxVal = (ddcOk && maxVal > 0) ? maxVal : 100u,
                            CurrentBrightness = pct,
                            PendingBrightness = -1,
                            WorkerBusy = 0,
                            UseWindowsSdrWhiteLevel = useSdr,
                            AdapterId = matchedTarget != null ? matchedTarget.AdapterId : default(MonitorDdcNative.LUID),
                            TargetId = matchedTarget != null ? matchedTarget.TargetId : 0u
                        };
                        discovered.Add(slot);
                    }
                }

                if (discovered.Count > 0)
                {
                    lock (monitorHandleLock)
                    {
                        CleanupMonitorHandles();
                        monitorSlots.Clear();
                        monitorSlots.AddRange(discovered);
                    }

                    Dispatcher.Invoke(() =>
                    {
                        RebuildMonitorSlidersUi();
                        ApplyLayoutAndVisibility();
                        if (isWindowInitialized) FitHeightToContentIfCompact();
                    });
                }
                else
                {
                    Dispatcher.Invoke(() =>
                    {
                        ApplyLayoutAndVisibility();
                    });
                }
            }
            catch { }
        }

        private void RebuildMonitorSlidersUi()
        {
            if (monRowsHostStack == null) return;
            isUpdatingMonitorUi = true;
            try
            {
                monRowsHostStack.Children.Clear();
                txtMonitorNames.Clear();
                txtMonitorPercents.Clear();
                sliderMonitors.Clear();
                monitorSliderContainers.Clear();

                for (int i = 0; i < monitorSlots.Count; i++)
                {
                    int idx = i;
                    PhysicalMonitorSlot slot = monitorSlots[i];

                    Grid row = new Grid { Margin = new Thickness(0, i == 0 ? 0 : 5, 0, 2) };
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(118) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38) });

                    StackPanel nameStack = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                    nameStack.Children.Add(new TextBlock { Text = "🖥", Foreground = HexBrush("#B8A99E"), FontSize = 11, Margin = new Thickness(0, 0, 5, 0), VerticalAlignment = VerticalAlignment.Center });
                    TextBlock tName = new TextBlock
                    {
                        Text = slot.Name + (slot.UseWindowsSdrWhiteLevel ? " (SDR)" : ""),
                        Foreground = HexBrush("#F5EFEA"),
                        FontSize = 11.5,
                        FontWeight = FontWeights.SemiBold,
                        VerticalAlignment = VerticalAlignment.Center,
                        TextTrimming = TextTrimming.CharacterEllipsis,
                        ToolTip = slot.UseWindowsSdrWhiteLevel
                            ? (slot.Name + L(" • HDR Açık: Windows SDR İçerik Parlaklığı (Gecikmesiz)", " • HDR Active: Windows SDR Content Brightness (Instant)"))
                            : (slot.Name + L(" • Donanımsal DDC/CI Parlaklık", " • Hardware DDC/CI Brightness"))
                    };
                    nameStack.Children.Add(tName);
                    txtMonitorNames.Add(tName);
                    Grid.SetColumn(nameStack, 0);
                    row.Children.Add(nameStack);

                    Border sHost = new Border { VerticalAlignment = VerticalAlignment.Center };
                    Slider sl = CreateModernSlider(accentColorHex, slot.CurrentBrightness, 0, "6,0,8,0");
                    sl.ValueChanged += (s, e) => OnMonitorSliderValueChanged(idx, e.NewValue);
                    AttachMonitorSliderWheel(sl, idx);
                    sHost.Child = sl;
                    monitorSliderContainers.Add(sHost);
                    sliderMonitors.Add(sl);
                    Grid.SetColumn(sHost, 1);
                    row.Children.Add(sHost);

                    TextBlock tPct = new TextBlock
                    {
                        Text = IsEn ? (slot.CurrentBrightness + "%") : ("%" + slot.CurrentBrightness),
                        Foreground = HexBrush(accentColorHex),
                        FontSize = 12,
                        FontWeight = FontWeights.Bold,
                        HorizontalAlignment = HorizontalAlignment.Right,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    accentTextBlocks.Add(tPct);
                    txtMonitorPercents.Add(tPct);
                    Grid.SetColumn(tPct, 2);
                    row.Children.Add(tPct);

                    monRowsHostStack.Children.Add(row);
                }
            }
            finally
            {
                isUpdatingMonitorUi = false;
            }
        }

        private void CleanupMonitorHandles()
        {
            lock (monitorHandleLock)
            {
                foreach (var slot in monitorSlots)
                {
                    if (slot.Handle != IntPtr.Zero)
                    {
                        try { MonitorDdcNative.DestroyPhysicalMonitor(slot.Handle); } catch { }
                        slot.Handle = IntPtr.Zero;
                    }
                }
            }
        }

        // ==========================================
        // ULTRA-LIGHT TIMERS, NVML GPU & TELEMETRY
        // ==========================================
        private void InitializeTimers()
        {
            Task.Run(() =>
            {
                // Initialize Direct NVML C-API off UI thread so cold boot is never stalled by GPU driver init
                try
                {
                    if (NvmlNative.nvmlInit_v2() == 0)
                    {
                        if (NvmlNative.nvmlDeviceGetHandleByIndex_v2(0, out nvmlDeviceHandle) == 0)
                        {
                            nvmlInitialized = true;
                            StringBuilder sb = new StringBuilder(96);
                            if (NvmlNative.nvmlDeviceGetName(nvmlDeviceHandle, sb, 96) == 0)
                            {
                                string rawGpu = sb.ToString().Replace("NVIDIA", "").Replace("GeForce", "").Trim();
                                if (!string.IsNullOrEmpty(rawGpu)) gpuModelName = rawGpu;
                            }
                        }
                    }
                }
                catch { }
                try
                {
                    cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                    cpuCounter.NextValue();
                }
                catch { }
                DiscoverAndSyncMonitors(true);
                FetchWeatherAsync();
                UpdatePingAsync();
                PollWirelessDevicesAsync();
            });

            clipboardHistory.Add(new ClipboardEntry { Text = L("OpenWidget Masaüstü Hazır", "OpenWidget Desktop Ready"), Time = DateTime.Now.ToString("HH:mm") });
            RefreshClipboardUi();
            Dispatcher.BeginInvoke(new Action(() =>
            {
                try
                {
                    if (Clipboard.ContainsText())
                    {
                        string initText = Clipboard.GetText().Trim();
                        if (!string.IsNullOrEmpty(initText))
                        {
                            clipboardHistory.Clear();
                            lastClipboardText = initText;
                            clipboardHistory.Add(new ClipboardEntry { Text = initText, Time = DateTime.Now.ToString("HH:mm") });
                            RefreshClipboardUi();
                        }
                    }
                }
                catch { }
            }), DispatcherPriority.ApplicationIdle);

            DispatcherTimer desktopGuardTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
            desktopGuardTimer.Tick += (s, e) => CheckAndEnforceShowDesktopImmunity();
            desktopGuardTimer.Start();

            DispatcherTimer fastTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1500) };
            fastTimer.Tick += (s, e) =>
            {
                UpdateClockAndUptime();
                UpdateTelemetryFast();
                SyncMicrophoneStateFromOs(false);
            };
            fastTimer.Start();

            int mediumTickCount = 0;
            DispatcherTimer mediumTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(6) };
            mediumTimer.Tick += (s, e) =>
            {
                mediumTickCount++;
                bool pollWirelessNow = (mediumTickCount % 3 == 0);
                bool trimNow = (mediumTickCount % 20 == 0);
                Task.Run(() =>
                {
                    UpdatePingAsync();
                    if (pollWirelessNow)
                    {
                        PollWirelessDevicesAsync();
                    }
                    if (trimNow)
                    {
                        TrimProcessMemory();
                    }
                });
            };
            mediumTimer.Start();

            DispatcherTimer weatherTimer = new DispatcherTimer { Interval = TimeSpan.FromMinutes(15) };
            weatherTimer.Tick += (s, e) =>
            {
                Task.Run(() => FetchWeatherAsync());
                TrimProcessMemory();
            };
            weatherTimer.Start();

            UpdateClockAndUptime();
            Dispatcher.BeginInvoke(new Action(() => UpdateTelemetryFast()), DispatcherPriority.Background);
        }

        private void UpdateClockAndUptime()
        {
            DateTime now = DateTime.Now;
            ulong tickMs = GetTickCount64();
            TimeSpan up = TimeSpan.FromMilliseconds(tickMs);
            int totalHours = (int)up.TotalHours;

            if (IsEn)
            {
                string[] monthsEn = { "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
                string[] daysEn = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
                txtClockAndUptime.Text = string.Format("{0:HH:mm} · {1} {2} {3}  Up: {4}h {5}m",
                    now, now.Day, monthsEn[now.Month], daysEn[(int)now.DayOfWeek], totalHours, up.Minutes);
            }
            else
            {
                string[] aylar = { "", "Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara" };
                string[] gunler = { "Pazar", "Pzt", "Salı", "Çar", "Per", "Cuma", "Cmt" };
                txtClockAndUptime.Text = string.Format("{0:HH:mm} · {1} {2} {3}  Açık: {4}s {5}dk",
                    now, now.Day, aylar[now.Month], gunler[(int)now.DayOfWeek], totalHours, up.Minutes);
            }
        }

        private void PollGpuDirectNvml()
        {
            if (!nvmlInitialized || nvmlDeviceHandle == IntPtr.Zero) return;
            try
            {
                uint temp;
                if (NvmlNative.nvmlDeviceGetTemperature(nvmlDeviceHandle, 0, out temp) == 0)
                {
                    gpuTemp = temp;
                }
                NvmlNative.nvmlUtilization_t util;
                if (NvmlNative.nvmlDeviceGetUtilizationRates(nvmlDeviceHandle, out util) == 0)
                {
                    gpuLoad = util.gpu;
                    gpuHistory.Add(gpuLoad);
                    if (gpuHistory.Count > 20) gpuHistory.RemoveAt(0);
                }
                NvmlNative.nvmlMemory_t mem;
                if (NvmlNative.nvmlDeviceGetMemoryInfo(nvmlDeviceHandle, out mem) == 0)
                {
                    vramUsedGb = mem.used / (1024.0 * 1024.0 * 1024.0);
                    vramTotalGb = mem.total / (1024.0 * 1024.0 * 1024.0);
                }
            }
            catch { }
        }

        private double ReadCpuTemperature(double currentCpuLoad)
        {
            double baseAmbient = Math.Max(38.0, gpuTemp - 4.0);
            double targetTemp = baseAmbient + (currentCpuLoad * 0.34);
            cpuTemp = (cpuTemp * 0.70) + (targetTemp * 0.30);
            return Math.Round(Math.Max(36, Math.Min(95, cpuTemp)));
        }

        private void UpdateTelemetryFast()
        {
            PollGpuDirectNvml();

            double cpuVal = 6;
            try
            {
                if (cpuCounter != null) cpuVal = Math.Round(cpuCounter.NextValue());
            }
            catch { }
            cpuVal = Math.Max(1, Math.Min(100, cpuVal));
            cpuHistory.Add(cpuVal);
            if (cpuHistory.Count > 20) cpuHistory.RemoveAt(0);

            double cTemp = ReadCpuTemperature(cpuVal);
            txtCpuDetail.Text = string.Format("{0:0}°C • {1}", cTemp, cpuShortName);
            txtCpuPct.Text = IsEn ? ((int)cpuVal + "%") : ("%" + (int)cpuVal);
            DrawSparkline(sparkCpu, cpuHistory, 46, 16);

            try
            {
                if (GlobalMemoryStatusEx(sharedMemStatus))
                {
                    double totalGb = sharedMemStatus.ullTotalPhys / (1024.0 * 1024.0 * 1024.0);
                    double usedGb = (sharedMemStatus.ullTotalPhys - sharedMemStatus.ullAvailPhys) / (1024.0 * 1024.0 * 1024.0);
                    int pct = (int)sharedMemStatus.dwMemoryLoad;
                    txtRamDetail.Text = string.Format("{0:0.0} / {1:0} GB", usedGb, Math.Round(totalGb));
                    txtRamPct.Text = IsEn ? (pct + "%") : ("%" + pct);
                    barRamFill.Width = Math.Max(3, (42.0 * pct) / 100.0);
                }
            }
            catch { }

            txtGpuDetail.Text = string.Format("{0:0}°C • {1}", gpuTemp, gpuModelName);
            txtGpuPct.Text = IsEn ? ((int)gpuLoad + "%") : ("%" + (int)gpuLoad);
            DrawSparkline(sparkGpu, gpuHistory, 46, 16);

            int vramPct = vramTotalGb > 0 ? (int)Math.Round((vramUsedGb / vramTotalGb) * 100.0) : 0;
            txtVramDetail.Text = string.Format("{0:0.0} / {1:0} GB", vramUsedGb, vramTotalGb);
            txtVramPct.Text = IsEn ? (vramPct + "%") : ("%" + vramPct);
            barVramFill.Width = Math.Max(3, (42.0 * vramPct) / 100.0);

            try
            {
                long totalRecv = 0;
                long totalSent = 0;
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus == OperationalStatus.Up && ni.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                    {
                        var stats = ni.GetIPv4Statistics();
                        totalRecv += stats.BytesReceived;
                        totalSent += stats.BytesSent;
                    }
                }

                DateTime now = DateTime.Now;
                double elapsedSec = (now - lastNetTime).TotalSeconds;
                if (lastBytesRecv > 0 && elapsedSec > 0.2)
                {
                    double downKbps = ((totalRecv - lastBytesRecv) * 8.0 / 1000.0) / elapsedSec;
                    double upKbps = ((totalSent - lastBytesSent) * 8.0 / 1000.0) / elapsedSec;
                    txtNetSpeed.Text = string.Format("↓ {0} ↑ {1}", FormatBitrate(downKbps), FormatBitrate(upKbps));
                }
                lastBytesRecv = totalRecv;
                lastBytesSent = totalSent;
                lastNetTime = now;
            }
            catch { }

            txtNetPing.Text = string.Format("{0:0} ms", lastPingMs);
            if (IsEn)
                txtNetBadge.Text = lastPingMs < 40 ? "Great" : (lastPingMs < 90 ? "Good" : "Fair");
            else
                txtNetBadge.Text = lastPingMs < 40 ? "Harika" : (lastPingMs < 90 ? "İyi" : "Orta");

            for (int i = 0; i < fixedDrives.Count; i++)
            {
                UpdateDiskRow(fixedDrives[i], diskDetailBlocks[i], diskFillBars[i], diskPctBlocks[i]);
            }
        }

        private string FormatBitrate(double kbps)
        {
            if (kbps >= 1000.0)
                return string.Format("{0:0.0} Mbps", kbps / 1000.0);
            return string.Format("{0:0} Kbps", Math.Max(0, kbps));
        }

        private void UpdateDiskRow(DriveInfo d, TextBlock detail, Border fill, TextBlock pctBlock)
        {
            try
            {
                if (d != null && d.IsReady)
                {
                    double freeGb = d.AvailableFreeSpace / (1024.0 * 1024.0 * 1024.0);
                    double totalGb = d.TotalSize / (1024.0 * 1024.0 * 1024.0);
                    int usedPct = (int)Math.Round(((totalGb - freeGb) / totalGb) * 100.0);
                    detail.Text = IsEn
                        ? string.Format("{0:0} GB Free / {1:0} GB", freeGb, totalGb)
                        : string.Format("{0:0} GB Boş / {1:0} GB", freeGb, totalGb);
                    pctBlock.Text = IsEn ? (usedPct + "% Used") : ("%" + usedPct + " Dolu");
                    fill.Width = Math.Max(3, (42.0 * usedPct) / 100.0);
                }
            }
            catch { }
        }

        private void DrawSparkline(Polyline poly, List<double> values, double width, double height)
        {
            if (values == null || values.Count < 2) return;
            PointCollection pts = new PointCollection(values.Count);
            double step = width / (values.Count - 1);
            for (int i = 0; i < values.Count; i++)
            {
                double v = Math.Max(0, Math.Min(100, values[i]));
                double x = i * step;
                double y = height - ((v / 100.0) * (height - 4)) - 2;
                pts.Add(new Point(x, y));
            }
            pts.Freeze();
            poly.Points = pts;
        }

        private void UpdatePingAsync()
        {
            try
            {
                if (sharedPing != null)
                {
                    PingReply reply = sharedPing.Send("1.1.1.1", 1000);
                    if (reply != null && reply.Status == IPStatus.Success)
                    {
                        lastPingMs = reply.RoundtripTime;
                    }
                }
            }
            catch { }
        }

        // ==========================================
        // UNIVERSAL WIRELESS PERIPHERALS BATTERY SCAN
        // ==========================================
        private void PollWirelessDevicesAsync()
        {
            if (Interlocked.CompareExchange(ref wirelessPollingBusy, 1, 0) != 0) return;
            try
            {
                bool en = IsEn;
                List<WirelessDeviceReading> activeList = WirelessBatteryNative.ScanActiveWirelessDevices(en, wirelessLastPcts, wirelessLastHz);

                Dispatcher.Invoke(() =>
                {
                    if (panelWirelessContent == null || wirelessHeaderGrid == null) return;

                    bool countChanged = (activeList.Count != lastWirelessCount);
                    lastWirelessCount = activeList.Count;

                    foreach (var kv in wirelessRowCache)
                    {
                        kv.Value.Row.Visibility = Visibility.Collapsed;
                    }

                    SolidColorBrush accentBrush = (SolidColorBrush)HexBrush(accentColorHex);

                    foreach (WirelessDeviceReading dev in activeList)
                    {
                        WirelessRowUi ui;
                        if (!wirelessRowCache.TryGetValue(dev.IdKey, out ui))
                        {
                            ui = new WirelessRowUi();
                            ui.Row = CreateTelemetryBarRow(dev.Icon, dev.Name, dev.Detail, true, out ui.Label, out ui.Detail, out ui.Fill, out ui.Pct);
                            wirelessRowCache[dev.IdKey] = ui;
                            panelWirelessContent.Children.Add(ui.Row);
                        }
                        ui.Row.Visibility = Visibility.Visible;
                        ui.Label.Text = dev.Name;
                        ui.Detail.Text = dev.Detail;
                        ui.Pct.Text = dev.PctText;
                        ui.Pct.Foreground = accentBrush;
                        ui.Fill.Background = accentBrush;
                        ui.Fill.Width = dev.BarPct > 0 ? Math.Max(3, (42.0 * dev.BarPct) / 100.0) : 0;
                    }

                    Visibility targetVis = (showSecWireless && activeList.Count > 0) ? Visibility.Visible : Visibility.Collapsed;
                    if (secContainerWireless != null && secContainerWireless.Visibility != targetVis)
                    {
                        ApplyLayoutAndVisibility();
                        countChanged = true;
                    }

                    if (countChanged && isWindowInitialized)
                    {
                        FitHeightToContentIfCompact();
                    }
                });
            }
            catch { }
            finally
            {
                Interlocked.Exchange(ref wirelessPollingBusy, 0);
            }
        }

        // ==========================================
        // WEATHER FETCHER (DYNAMIC USER LOCATION)
        // ==========================================
        private double ToDisplayTemp(double tempC)
        {
            return useFahrenheit ? Math.Round((tempC * 9.0 / 5.0) + 32.0) : Math.Round(tempC);
        }

        private void RefreshWeatherTemperatureUi()
        {
            try
            {
                string unitSuffix = useFahrenheit ? "°F" : "°C";
                if (txtWeatherTemp != null)
                    txtWeatherTemp.Text = string.Format("{0:0}°", ToDisplayTemp(lastWeatherTempC));
                if (txtWeatherFeels != null)
                {
                    txtWeatherFeels.Text = IsEn
                        ? string.Format("Feels like {0:0}{1}", ToDisplayTemp(lastWeatherFeelsC), unitSuffix)
                        : string.Format("Hissedilen {0:0}{1}", ToDisplayTemp(lastWeatherFeelsC), unitSuffix);
                }
                for (int i = 0; i < 3; i++)
                {
                    if (txtDayTemps[i] != null && lastWeatherMinC != null && lastWeatherMaxC != null && lastWeatherMinC.Length > i && lastWeatherMaxC.Length > i)
                    {
                        txtDayTemps[i].Text = string.Format("{0:0}° / {1:0}°", ToDisplayTemp(lastWeatherMinC[i]), ToDisplayTemp(lastWeatherMaxC[i]));
                    }
                }
            }
            catch { }
        }

        private void FetchWeatherAsync()
        {
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string latStr = locationLat.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture);
                string lonStr = locationLon.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture);
                string url = string.Format("https://api.open-meteo.com/v1/forecast?latitude={0}&longitude={1}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=4", latStr, lonStr);

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Timeout = 6000;
                req.UserAgent = "OpenWidgetPublic/2.5";

                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                {
                    string json = reader.ReadToEnd();

                    int currentIdx = json.IndexOf("\"current\":");
                    string currentSection = currentIdx >= 0 ? json.Substring(currentIdx) : json;

                    double temp = ExtractJsonDouble(currentSection, "temperature_2m", 14);
                    double feels = ExtractJsonDouble(currentSection, "apparent_temperature", 13);
                    double hum = ExtractJsonDouble(currentSection, "relative_humidity_2m", 75);
                    double wind = ExtractJsonDouble(currentSection, "wind_speed_10m", 12);
                    double precip = ExtractJsonDouble(currentSection, "precipitation", 0);
                    int wCode = (int)ExtractJsonDouble(currentSection, "weather_code", 1);

                    double[] minTemps = ExtractJsonArrayDoubles(json, "temperature_2m_min");
                    double[] maxTemps = ExtractJsonArrayDoubles(json, "temperature_2m_max");
                    double[] dayCodes = ExtractJsonArrayDoubles(json, "weather_code");

                    lastWeatherTempC = temp;
                    lastWeatherFeelsC = feels;
                    if (minTemps.Length >= 3) lastWeatherMinC = minTemps;
                    if (maxTemps.Length >= 3) lastWeatherMaxC = maxTemps;

                    Dispatcher.Invoke(() =>
                    {
                        txtLocationBadge.Text = locationName;
                        RefreshWeatherTemperatureUi();
                        txtWeatherDesc.Text = WeatherCodeToText(wCode);
                        txtWeatherMainIcon.Text = WeatherCodeToIcon(wCode);
                        txtWeatherHumidity.Text = IsEn ? (Math.Round(hum) + "%") : ("%" + Math.Round(hum));
                        txtWeatherWind.Text = Math.Round(wind) + L(" km/s", " km/h");
                        txtWeatherRain.Text = precip.ToString("0.#") + " mm";

                        string[] gunIsimleri = IsEn
                            ? new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" }
                            : new string[] { "Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi" };
                        for (int i = 0; i < 3; i++)
                        {
                            txtDayNames[i].Text = i == 0
                                ? L("Bugün", "Today")
                                : (i == 1 ? L("Yarın", "Tomorrow") : gunIsimleri[(int)DateTime.Now.AddDays(i).DayOfWeek]);
                            if (dayCodes.Length > i)
                            {
                                txtDayIcons[i].Text = WeatherCodeToIcon((int)dayCodes[i]);
                            }
                        }
                    });
                }
            }
            catch { }
        }

        private double ExtractJsonDouble(string json, string key, double fallback)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*(-?\\d+(\\.\\d+)?)");
            if (m.Success)
            {
                double v;
                if (double.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out v))
                    return v;
            }
            return fallback;
        }

        private double[] ExtractJsonArrayDoubles(string json, string key)
        {
            List<double> list = new List<double>();
            int dailyIdx = json.IndexOf("\"daily\":");
            string section = dailyIdx >= 0 ? json.Substring(dailyIdx) : json;
            Match m = Regex.Match(section, "\"" + key + "\"\\s*:\\s*\\[([^\\]]+)\\]");
            if (m.Success)
            {
                string[] parts = m.Groups[1].Value.Split(',');
                foreach (string p in parts)
                {
                    double v;
                    if (double.TryParse(p.Trim(), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out v))
                        list.Add(v);
                }
            }
            return list.ToArray();
        }

        private string WeatherCodeToText(int code)
        {
            if (code == 0) return L("Açık", "Clear Sky");
            if (code == 1 || code == 2) return L("Parçalı Bulutlu", "Partly Cloudy");
            if (code == 3) return L("Çok Bulutlu", "Overcast");
            if (code == 45 || code == 48) return L("Sisli", "Foggy");
            if (code >= 51 && code <= 67) return L("Yağmurlu", "Rainy");
            if (code >= 71 && code <= 77) return L("Kar Yağışlı", "Snowy");
            if (code >= 80 && code <= 82) return L("Sağanak Yağışlı", "Rain Showers");
            if (code >= 95) return L("Fırtınalı", "Thunderstorm");
            return L("Parçalı Bulutlu", "Partly Cloudy");
        }

        private string WeatherCodeToIcon(int code)
        {
            if (code == 0) return "☀";
            if (code == 1 || code == 2) return "⛅";
            if (code == 3) return "☁";
            if (code == 45 || code == 48) return "🌫";
            if (code >= 51 && code <= 67) return "🌧";
            if (code >= 71 && code <= 77) return "❄";
            if (code >= 80 && code <= 82) return "💧";
            if (code >= 95) return "⚡";
            return "☀";
        }

        // ==========================================
        // EVENT-DRIVEN CLIPBOARD HISTORY MANAGER
        // ==========================================
        private void CheckClipboardChanges()
        {
            try
            {
                if (Clipboard.ContainsText())
                {
                    string text = Clipboard.GetText().Trim();
                    if (!string.IsNullOrEmpty(text) && text != lastClipboardText)
                    {
                        lastClipboardText = text;
                        clipboardHistory.RemoveAll(x => x.Text == text);
                        clipboardHistory.Insert(0, new ClipboardEntry
                        {
                            Text = text,
                            Time = DateTime.Now.ToString("HH:mm")
                        });
                        if (clipboardHistory.Count > 8)
                            clipboardHistory.RemoveAt(clipboardHistory.Count - 1);

                        RefreshClipboardUi();
                    }
                }
            }
            catch { }
        }

        private void RefreshClipboardUi()
        {
            panelClipItems.Children.Clear();
            txtClipCount.Text = clipboardHistory.Count + L(" öğe", " items");

            if (clipboardHistory.Count == 0)
            {
                Border emptyCard = new Border
                {
                    CornerRadius = new CornerRadius(8),
                    Background = HexBrush("#5526201D"),
                    BorderBrush = HexBrush("#3D322C"),
                    BorderThickness = new Thickness(1),
                    Padding = new Thickness(10, 8, 10, 8)
                };
                emptyCard.Child = new TextBlock
                {
                    Text = L("Henüz kopyalanan metin yok...", "No copied text yet..."),
                    Foreground = HexBrush("#8C7A6B"),
                    FontSize = 11.5,
                    HorizontalAlignment = HorizontalAlignment.Center
                };
                panelClipItems.Children.Add(emptyCard);
                return;
            }

            foreach (var item in clipboardHistory)
            {
                string copyText = item.Text;
                string singleLine = copyText.Replace("\r", " ").Replace("\n", " ");

                Border itemBorder = new Border
                {
                    CornerRadius = new CornerRadius(8),
                    Background = HexBrush("#7728211E"),
                    BorderBrush = HexBrush("#453831"),
                    BorderThickness = new Thickness(1),
                    Padding = new Thickness(10, 7, 10, 7),
                    Margin = new Thickness(0, 0, 0, 5),
                    Cursor = Cursors.Hand,
                    Tag = "Interactive",
                    ToolTip = L("Tekrar kopyalamak için tıklayın:\n", "Click to copy again:\n") + (copyText.Length > 200 ? copyText.Substring(0, 200) + "..." : copyText)
                };

                Grid row = new Grid();
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                row.Children.Add(new TextBlock { Text = "📄", Foreground = HexBrush("#B8A99E"), FontSize = 11, Margin = new Thickness(0, 0, 7, 0), VerticalAlignment = VerticalAlignment.Center });

                TextBlock txtContent = new TextBlock
                {
                    Text = singleLine,
                    Foreground = HexBrush("#FAF6F2"),
                    FontSize = 11.5,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 8, 0)
                };
                Grid.SetColumn(txtContent, 1);
                row.Children.Add(txtContent);

                TextBlock txtTime = new TextBlock
                {
                    Text = item.Time,
                    Foreground = HexBrush("#9E8C7E"),
                    FontSize = 10.5,
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetColumn(txtTime, 2);
                row.Children.Add(txtTime);

                itemBorder.Child = row;
                itemBorder.MouseEnter += (s, e) => itemBorder.Background = HexBrush("#AA382D27");
                itemBorder.MouseLeave += (s, e) => itemBorder.Background = HexBrush("#7728211E");
                itemBorder.MouseLeftButtonDown += (s, e) =>
                {
                    try
                    {
                        lastClipboardText = copyText;
                        Clipboard.SetText(copyText);
                        ShowToast(L("Panoya kopyalandı!", "Copied to clipboard!"));
                    }
                    catch { }
                };

                panelClipItems.Children.Add(itemBorder);
            }
        }

        private void ShowToast(string msg)
        {
            Dispatcher.Invoke(() =>
            {
                txtToastMessage.Text = msg;
                toastPopup.IsOpen = true;
                toastTimer.Stop();
                toastTimer.Start();
            });
        }

        // =========================================================================
        // STANDALONE APPLE-STYLE GOOGLE CALENDAR DESKTOP WIDGET (SEPARATE WINDOW)
        // =========================================================================
        public void SetCalendarWidgetVisible(bool visible)
        {
            showCalendarWidget = visible;
            SaveSettings();
            if (trayCalendarItem != null)
            {
                trayCalendarItem.Text = showCalendarWidget
                    ? L("📅 Takvim Widget'ını Gizle", "📅 Hide Calendar Widget")
                    : L("📅 Takvim Widget'ını Göster", "📅 Show Calendar Widget");
            }
            if (calendarWindow == null && showCalendarWidget)
            {
                InitializeCalendarWidget();
                return;
            }
            if (calendarWindow != null)
            {
                if (showCalendarWidget)
                {
                    calendarWindow.Show();
                    IntPtr calHwnd = cachedCalHwnd != IntPtr.Zero ? cachedCalHwnd : new WindowInteropHelper(calendarWindow).Handle;
                    if (calHwnd != IntPtr.Zero) SendWidgetToDesktopBottom(calHwnd);
                    RefreshCalendarWidgetUi();
                }
                else
                {
                    calendarWindow.Hide();
                }
            }
        }

        private void InitializeCalendarWidget()
        {
            if (calendarWindow != null) return;

            calendarWindow = new Window
            {
                Title = L("OpenWidget • Takvim", "OpenWidget • Calendar"),
                MinWidth = 390,
                MinHeight = 215,
                Width = savedCalWidth,
                Height = savedCalHeight,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                Background = Brushes.Transparent,
                ResizeMode = isDraggable ? ResizeMode.CanResize : ResizeMode.NoResize,
                ShowInTaskbar = false,
                Topmost = false,
                UseLayoutRounding = true,
                SnapsToDevicePixels = true,
                FontFamily = new FontFamily("Segoe UI")
            };
            Program.TryApplyWindowIcon(calendarWindow);
            TextOptions.SetTextFormattingMode(calendarWindow, TextFormattingMode.Display);
            TextOptions.SetTextRenderingMode(calendarWindow, TextRenderingMode.ClearType);
            RenderOptions.SetClearTypeHint(calendarWindow, ClearTypeHint.Enabled);

            if (IsPositionWithinVirtualDesktop(savedCalLeft, savedCalTop, savedCalWidth, savedCalHeight))
            {
                calendarWindow.Left = savedCalLeft;
                calendarWindow.Top = savedCalTop;
            }
            else
            {
                Rect workArea = GetWindowMonitorWorkArea(this);
                double defaultLeft = this.Left - savedCalWidth - 10;
                if (defaultLeft < workArea.Left + 10) defaultLeft = workArea.Left + 14;
                calendarWindow.Left = defaultLeft;
                calendarWindow.Top = this.Top;
                savedCalLeft = calendarWindow.Left;
                savedCalTop = calendarWindow.Top;
            }

            calWindowChrome = new WindowChrome
            {
                CaptionHeight = 0,
                CornerRadius = new CornerRadius(0),
                GlassFrameThickness = new Thickness(0),
                NonClientFrameEdges = NonClientFrameEdges.None,
                ResizeBorderThickness = isDraggable ? new Thickness(8) : new Thickness(0)
            };
            WindowChrome.SetWindowChrome(calendarWindow, calWindowChrome);

            calendarWindow.SizeChanged += (s, e) =>
            {
                if (e.HeightChanged && calendarWindow.ActualHeight >= 210)
                {
                    RebuildCalendarLeftColumn(calendarWindow.ActualHeight);
                }
                if (calendarWindow.ActualWidth >= 380 && calendarWindow.ActualHeight >= 210)
                {
                    savedCalWidth = calendarWindow.ActualWidth;
                    savedCalHeight = calendarWindow.ActualHeight;
                    SaveSettingsDebounced();
                }
            };

            calendarWindow.PreviewMouseLeftButtonDown += (s, e) =>
            {
                if (!isDraggable) return;
                DependencyObject dep = e.OriginalSource as DependencyObject;
                while (dep != null && dep != calendarWindow)
                {
                    if (dep is ButtonBase || dep is Slider || dep is Thumb || dep is TextBox || dep is ScrollBar)
                        return;
                    if (dep is FrameworkElement)
                    {
                        FrameworkElement fe = (FrameworkElement)dep;
                        if (fe.Tag != null && fe.Tag.ToString() == "Interactive") return;
                    }
                    dep = VisualTreeHelper.GetParent(dep);
                }
                try
                {
                    IntPtr calHwnd = cachedCalHwnd != IntPtr.Zero ? cachedCalHwnd : new WindowInteropHelper(calendarWindow).Handle;
                    ReleaseCapture();
                    SendMessage(calHwnd, WM_NCLBUTTONDOWN, (IntPtr)HT_CAPTION, IntPtr.Zero);
                    savedCalLeft = calendarWindow.Left;
                    savedCalTop = calendarWindow.Top;
                    SaveSettingsDebounced();
                    e.Handled = true;
                }
                catch { }
            };

            calendarWindow.LocationChanged += (s, e) =>
            {
                if (isCalWindowInitialized && !double.IsNaN(calendarWindow.Left) && !double.IsNaN(calendarWindow.Top) && calendarWindow.Left > -10000 && calendarWindow.Top > -10000)
                {
                    savedCalLeft = calendarWindow.Left;
                    savedCalTop = calendarWindow.Top;
                    SaveSettingsDebounced();
                }
            };

            calendarWindow.Loaded += (s, e) =>
            {
                IntPtr calHwnd = new WindowInteropHelper(calendarWindow).Handle;
                cachedCalHwnd = calHwnd;
                int exStyle = GetWindowLong(calHwnd, GWL_EXSTYLE);
                SetWindowLong(calHwnd, GWL_EXSTYLE, exStyle | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE);
                AttachToDesktopShell(calHwnd);
                HwndSource src = HwndSource.FromHwnd(calHwnd);
                if (src != null) src.AddHook(WndProc);
                isCalWindowInitialized = true;
            };

            calendarWindow.StateChanged += (s, e) =>
            {
                if (calendarWindow.WindowState == WindowState.Minimized)
                    calendarWindow.WindowState = WindowState.Normal;
            };

            BuildCalendarWidgetUi();
            ApplyCalendarWidgetTheme();

            if (showCalendarWidget)
            {
                calendarWindow.Show();
            }

            Task.Run(() => LoadAndSyncCalendarEventsAsync(false));

            DispatcherTimer calUiTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(45) };
            int calTick = 0;
            calUiTimer.Tick += (s, e) =>
            {
                calTick++;
                if (showCalendarWidget) RefreshCalendarWidgetUi(false);
                if (calTick % 7 == 0 && showCalendarWidget)
                {
                    Task.Run(() => LoadAndSyncCalendarEventsAsync(false));
                }
            };
            calUiTimer.Start();
        }

        private void BuildCalendarWidgetUi()
        {
            calOuterBorder = new Border
            {
                CornerRadius = new CornerRadius(16),
                BorderThickness = new Thickness(1),
                Margin = new Thickness(2),
                Padding = new Thickness(14, 12, 14, 12)
            };

            Grid rootGrid = new Grid();
            Grid twoPaneGrid = new Grid();
            twoPaneGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(182) });
            twoPaneGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(14) });
            twoPaneGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // LEFT PANE
            Grid leftPane = new Grid();
            leftPane.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            leftPane.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            leftPane.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            Grid dateTopRow = new Grid { Margin = new Thickness(2, 0, 2, 6) };
            dateTopRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            dateTopRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel dateLeftStack = new StackPanel();
            txtCalDayOfWeekHeader = new TextBlock
            {
                Text = L("BUGÜN", "TODAY"),
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                Foreground = HexBrush(accentColorHex)
            };
            dateLeftStack.Children.Add(txtCalDayOfWeekHeader);

            StackPanel bigNumRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Bottom };
            txtCalBigDayNum = new TextBlock
            {
                Text = DateTime.Now.Day.ToString(),
                FontSize = 27,
                FontWeight = FontWeights.Bold,
                Foreground = HexBrush("#FAF6F2"),
                Margin = new Thickness(0, -3, 7, -2)
            };
            txtCalMonthYearLabel = new TextBlock
            {
                Text = "",
                FontSize = 11,
                FontWeight = FontWeights.SemiBold,
                Foreground = HexBrush("#B8A99E"),
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, 0, 3)
            };
            bigNumRow.Children.Add(txtCalBigDayNum);
            bigNumRow.Children.Add(txtCalMonthYearLabel);
            dateLeftStack.Children.Add(bigNumRow);
            Grid.SetColumn(dateLeftStack, 0);
            dateTopRow.Children.Add(dateLeftStack);

            StackPanel monthNavBtns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Top };
            Button btnPrevMonth = CreateStyledIconButton("#26201D", "Transparent", L("Önceki Ay", "Previous Month"));
            btnPrevMonth.Width = 20; btnPrevMonth.Height = 20;
            btnPrevMonth.Content = new TextBlock { Text = "‹", Foreground = HexBrush("#C7B9AE"), FontSize = 13, FontWeight = FontWeights.Bold, Margin = new Thickness(0, -2, 0, 0) };
            btnPrevMonth.Click += (s, e) =>
            {
                calDisplayedMonth = calDisplayedMonth.AddMonths(-1);
                RefreshCalendarWidgetUi();
            };

            Button btnGoToday = CreateStyledIconButton("#26201D", "Transparent", L("Bugüne Dön", "Jump to Today"));
            btnGoToday.Width = 20; btnGoToday.Height = 20;
            btnGoToday.Margin = new Thickness(2, 0, 2, 0);
            btnGoToday.Content = new TextBlock { Text = "•", Foreground = HexBrush(accentColorHex), FontSize = 13, FontWeight = FontWeights.Bold, Margin = new Thickness(0, -2, 0, 0) };
            btnGoToday.Click += (s, e) =>
            {
                calSelectedDate = DateTime.Today;
                calDisplayedMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                RefreshCalendarWidgetUi();
            };

            Button btnNextMonth = CreateStyledIconButton("#26201D", "Transparent", L("Sonraki Ay", "Next Month"));
            btnNextMonth.Width = 20; btnNextMonth.Height = 20;
            btnNextMonth.Content = new TextBlock { Text = "›", Foreground = HexBrush("#C7B9AE"), FontSize = 13, FontWeight = FontWeights.Bold, Margin = new Thickness(0, -2, 0, 0) };
            btnNextMonth.Click += (s, e) =>
            {
                calDisplayedMonth = calDisplayedMonth.AddMonths(1);
                RefreshCalendarWidgetUi();
            };

            monthNavBtns.Children.Add(btnPrevMonth);
            monthNavBtns.Children.Add(btnGoToday);
            monthNavBtns.Children.Add(btnNextMonth);
            Grid.SetColumn(monthNavBtns, 1);
            dateTopRow.Children.Add(monthNavBtns);
            Grid.SetRow(dateTopRow, 0);
            leftPane.Children.Add(dateTopRow);

            UniformGrid weekDayHdr = new UniformGrid { Columns = 7, Margin = new Thickness(0, 0, 0, 3) };
            string[] shortDays = IsEn
                ? new string[] { "M", "T", "W", "T", "F", "S", "S" }
                : new string[] { "P", "S", "Ç", "P", "C", "C", "P" };
            for (int i = 0; i < 7; i++)
            {
                weekDayHdr.Children.Add(new TextBlock
                {
                    Text = shortDays[i],
                    Foreground = HexBrush(i >= 5 ? "#8C7A6B" : "#A8988C"),
                    FontSize = 9.5,
                    FontWeight = FontWeights.Bold,
                    HorizontalAlignment = HorizontalAlignment.Center
                });
            }
            Grid.SetRow(weekDayHdr, 1);
            leftPane.Children.Add(weekDayHdr);

            calMiniMonthGrid = new StackPanel
            {
                Orientation = Orientation.Vertical,
                VerticalAlignment = VerticalAlignment.Top,
                ClipToBounds = true
            };
            Grid.SetRow(calMiniMonthGrid, 2);
            leftPane.Children.Add(calMiniMonthGrid);

            Grid.SetColumn(leftPane, 0);
            twoPaneGrid.Children.Add(leftPane);

            Border vDivider = new Border
            {
                Width = 1,
                Background = HexBrush("#3B302A"),
                Margin = new Thickness(6, 2, 6, 2)
            };
            Grid.SetColumn(vDivider, 1);
            twoPaneGrid.Children.Add(vDivider);

            // RIGHT PANE
            Grid rightPane = new Grid();
            rightPane.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            rightPane.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            rightPane.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            Grid rightHeader = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            rightHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            rightHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtCalRightScheduleTitle = new TextBlock
            {
                Text = L("BUGÜN • ETKİNLİKLER", "TODAY • SCHEDULE"),
                Foreground = HexBrush("#C7B9AE"),
                FontSize = 10.5,
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(txtCalRightScheduleTitle, 0);
            rightHeader.Children.Add(txtCalRightScheduleTitle);

            StackPanel rightBtns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

            Button btnQuickAdd = CreateStyledIconButton("#26201D", "Transparent", L("Hızlı Etkinlik / Hatırlatıcı Ekle", "Quick Add Event / Reminder"));
            btnQuickAdd.Width = 22; btnQuickAdd.Height = 22;
            btnQuickAdd.Margin = new Thickness(0, 0, 3, 0);
            btnQuickAdd.Content = new TextBlock { Text = "+", Foreground = HexBrush(accentColorHex), FontSize = 13, FontWeight = FontWeights.Bold, Margin = new Thickness(0, -2, 0, 0) };
            btnQuickAdd.Click += (s, e) =>
            {
                calQuickAddPanel.Visibility = (calQuickAddPanel.Visibility == Visibility.Visible) ? Visibility.Collapsed : Visibility.Visible;
                FitCalendarHeightToContent();
            };
            rightBtns.Children.Add(btnQuickAdd);

            Button btnSyncCal = CreateStyledIconButton("#26201D", "Transparent", L("Takvimi Şimdi Senkronize Et", "Sync Calendar Now"));
            btnSyncCal.Width = 22; btnSyncCal.Height = 22;
            btnSyncCal.Margin = new Thickness(0, 0, 3, 0);
            btnSyncCal.Content = new TextBlock { Text = "↻", Foreground = HexBrush("#C7B9AE"), FontSize = 11.5, FontWeight = FontWeights.Bold };
            btnSyncCal.Click += (s, e) =>
            {
                Task.Run(() => LoadAndSyncCalendarEventsAsync(true));
            };
            rightBtns.Children.Add(btnSyncCal);

            Button btnOpenGCalWeb = CreateStyledIconButton("#26201D", "Transparent", L("Google Takvim'i Tarayıcıda Aç", "Open Google Calendar in Browser"));
            btnOpenGCalWeb.Width = 22; btnOpenGCalWeb.Height = 22;
            btnOpenGCalWeb.Margin = new Thickness(0, 0, 3, 0);
            btnOpenGCalWeb.Content = new TextBlock { Text = "📅", Foreground = HexBrush("#C7B9AE"), FontSize = 10.5 };
            btnOpenGCalWeb.Click += (s, e) =>
            {
                try { Process.Start("https://calendar.google.com/calendar/r"); } catch { }
            };
            rightBtns.Children.Add(btnOpenGCalWeb);

            btnCalLockDrag = CreateStyledIconButton("#26201D", "Transparent", L("Taşıma ve Boyutlandırma Kilidi", "Drag & Resize Lock"));
            btnCalLockDrag.Width = 22; btnCalLockDrag.Height = 22;
            btnCalLockDrag.Click += (s, e) => ToggleDraggableMode();
            rightBtns.Children.Add(btnCalLockDrag);

            Grid.SetColumn(rightBtns, 1);
            rightHeader.Children.Add(rightBtns);
            Grid.SetRow(rightHeader, 0);
            rightPane.Children.Add(rightHeader);

            calQuickAddPanel = new Border
            {
                Visibility = Visibility.Collapsed,
                CornerRadius = new CornerRadius(8),
                Background = HexBrush("#261E1A"),
                BorderBrush = HexBrush("#4A3C34"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(7, 5, 7, 5),
                Margin = new Thickness(0, 0, 0, 6),
                Tag = "Interactive"
            };
            Grid qaGrid = new Grid();
            qaGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(68) });
            qaGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            qaGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            txtCalQuickTime = new TextBox
            {
                Text = "14:00",
                Background = HexBrush("#1C1613"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#3E322B"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(4, 2, 4, 2),
                FontSize = 10.5,
                Margin = new Thickness(0, 0, 4, 0),
                ToolTip = L("Saat (Örn: 14:00 veya 09:30-11:00)", "Time (e.g., 14:00 or 09:30-11:00)")
            };
            Grid.SetColumn(txtCalQuickTime, 0);
            qaGrid.Children.Add(txtCalQuickTime);

            txtCalQuickTitle = new TextBox
            {
                Text = "",
                Background = HexBrush("#1C1613"),
                Foreground = HexBrush("#FAF6F2"),
                BorderBrush = HexBrush("#3E322B"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(5, 2, 5, 2),
                FontSize = 10.5,
                Margin = new Thickness(0, 0, 4, 0),
                ToolTip = L("Etkinlik başlığı yazın", "Enter event title")
            };
            txtCalQuickLoc = new TextBox { Text = "" };
            Grid.SetColumn(txtCalQuickTitle, 1);
            qaGrid.Children.Add(txtCalQuickTitle);

            Button btnSaveQuickEvent = CreateStyledIconButton("#38281E", accentColorHex, L("Seçili güne etkinlik ekle", "Add event to selected day"));
            btnSaveQuickEvent.Padding = new Thickness(8, 2, 8, 2);
            btnSaveQuickEvent.Content = new TextBlock { Text = L("Ekle", "Add"), Foreground = HexBrush("#FAF6F2"), FontSize = 10, FontWeight = FontWeights.Bold };
            btnSaveQuickEvent.Click += (s, e) => AddCustomCalendarEventFromUi();
            Grid.SetColumn(btnSaveQuickEvent, 2);
            qaGrid.Children.Add(btnSaveQuickEvent);

            calQuickAddPanel.Child = qaGrid;
            Grid.SetRow(calQuickAddPanel, 1);
            rightPane.Children.Add(calQuickAddPanel);

            calEventsScroll = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                PanningMode = PanningMode.VerticalOnly
            };
            ApplyThinDarkScrollBarStyle(calEventsScroll);
            calEventsListPanel = new StackPanel { Margin = new Thickness(0, 0, 3, 0) };
            calEventsScroll.Content = calEventsListPanel;
            Grid.SetRow(calEventsScroll, 2);
            rightPane.Children.Add(calEventsScroll);

            Grid.SetColumn(rightPane, 2);
            twoPaneGrid.Children.Add(rightPane);

            rootGrid.Children.Add(twoPaneGrid);

            calResizeGrip = new Border
            {
                Width = 12,
                Height = 12,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, -8, -6),
                Visibility = isDraggable ? Visibility.Visible : Visibility.Collapsed,
                Child = new TextBlock { Text = "◢", FontSize = 9, Foreground = HexBrush("#8C7A6B") }
            };
            rootGrid.Children.Add(calResizeGrip);

            calOuterBorder.Child = rootGrid;
            calendarWindow.Content = calOuterBorder;
            UpdateDraggableButtonUi();
        }

        private void ApplyThinDarkScrollBarStyle(ScrollViewer sv)
        {
            Program.ApplyThinScrollBarStyle(sv, accentColorHex);
        }

        private void ApplyCalendarWidgetTheme()
        {
            if (calOuterBorder == null) return;
            try
            {
                Color accent = ParseColor(accentColorHex);
                byte mainAlpha = (byte)Math.Round((bgOpacityPercent / 100.0) * 255.0);
                Color darkTop = BlendColors(Color.FromRgb(22, 19, 17), accent, 0.08, mainAlpha);
                Color darkBottom = BlendColors(Color.FromRgb(28, 24, 21), accent, 0.12, mainAlpha);
                Color outerBorderCol = BlendColors(Color.FromRgb(56, 48, 42), accent, 0.35, 220);

                LinearGradientBrush grad = new LinearGradientBrush(darkTop, darkBottom, new Point(0, 0), new Point(0, 1));
                grad.Freeze();
                calOuterBorder.Background = grad;

                SolidColorBrush ob = new SolidColorBrush(outerBorderCol);
                ob.Freeze();
                calOuterBorder.BorderBrush = ob;

                if (txtCalDayOfWeekHeader != null)
                    txtCalDayOfWeekHeader.Foreground = HexBrush(accentColorHex);
                if (calEventsScroll != null)
                    ApplyThinDarkScrollBarStyle(calEventsScroll);

                RefreshCalendarWidgetUi();
            }
            catch { }
        }

        private void RefreshCalendarWidgetUi(bool autoShrinkHeight = true)
        {
            if (calendarWindow == null || calMiniMonthGrid == null || calEventsListPanel == null) return;
            try
            {
                string[] dayNamesUpper = IsEn
                    ? new string[] { "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY" }
                    : new string[] { "PAZAR", "PAZARTESİ", "SALI", "ÇARŞAMBA", "PERŞEMBE", "CUMA", "CUMARTESİ" };
                string[] dayNamesShortUpper = IsEn
                    ? new string[] { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" }
                    : new string[] { "PAZ", "PZT", "SAL", "ÇAR", "PER", "CUM", "CMT" };
                string[] monthNames = IsEn
                    ? new string[] { "", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }
                    : new string[] { "", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık" };
                string[] monthNamesUpper = IsEn
                    ? new string[] { "", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER" }
                    : new string[] { "", "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK" };

                DateTime today = DateTime.Today;
                DateTime headerDate = calSelectedDate.Date;

                txtCalDayOfWeekHeader.Text = dayNamesUpper[(int)headerDate.DayOfWeek];
                txtCalDayOfWeekHeader.Foreground = HexBrush(accentColorHex);
                txtCalBigDayNum.Text = headerDate.Day.ToString();
                txtCalMonthYearLabel.Text = monthNames[calDisplayedMonth.Month] + " " + calDisplayedMonth.Year;

                List<CalendarEventItem> snapshot;
                int evVer;
                lock (calEventsLock)
                {
                    snapshot = new List<CalendarEventItem>(allCalendarEvents);
                    evVer = calEventsVersion;
                }

                List<CalendarEventItem> dayEvents = GetEventsForDate(snapshot, calSelectedDate.Date);
                bool isViewingToday = (calSelectedDate.Date == today);
                DateTime now = DateTime.Now;

                int activeStateMask = 0;
                if (isViewingToday)
                {
                    for (int i = 0; i < dayEvents.Count; i++)
                    {
                        CalendarEventItem ev = dayEvents[i];
                        int st = (!ev.AllDay && now >= ev.Start && now <= ev.End) ? 2 : ((!ev.AllDay && now > ev.End) ? 1 : 0);
                        activeStateMask = (activeStateMask * 31) + st;
                    }
                }
                string rightSig = string.Format("{0:yyyyMMdd}|{1:yyyyMMdd}|{2}|{3}|{4}|{5}|{6}",
                    today, calSelectedDate.Date, evVer, accentColorHex, dayEvents.Count, activeStateMask, appLanguage);

                if (autoShrinkHeight || rightSig != lastRightScheduleSignature)
                {
                    lastRightScheduleSignature = rightSig;

                    calEventsListPanel.Children.Clear();

                    if (isViewingToday)
                    {
                        txtCalRightScheduleTitle.Text = string.Format("{0} • {1} {2} ({3})",
                            L("BUGÜN", "TODAY"),
                            today.Day,
                            monthNamesUpper[today.Month],
                            dayEvents.Count > 0 ? (dayEvents.Count + L(" ETKİNLİK", " EVENTS")) : L("BOŞ", "FREE"));
                    }
                    else
                    {
                        txtCalRightScheduleTitle.Text = string.Format("{0} {1} {2} • {3} {4}",
                            calSelectedDate.Day,
                            monthNamesUpper[calSelectedDate.Month],
                            dayNamesShortUpper[(int)calSelectedDate.DayOfWeek],
                            dayEvents.Count,
                            L("ETKİNLİK", "EVENTS"));
                    }

                    if (dayEvents.Count == 0)
                    {
                        Border emptyBox = new Border
                        {
                            CornerRadius = new CornerRadius(8),
                            Background = HexBrush("#4426201D"),
                            BorderBrush = HexBrush("#382E28"),
                            BorderThickness = new Thickness(1),
                            Padding = new Thickness(10, 7, 10, 7),
                            Margin = new Thickness(0, 0, 0, 6)
                        };
                        string emptyMsg = isViewingToday
                            ? (string.IsNullOrEmpty(calendarSecretIcalUrl)
                                ? L("Bugün etkinlik yok. Ayarlar > Ek Widget'lar'dan iCal linki ekleyebilir veya '+' ile etkinlik oluşturabilirsiniz.",
                                    "No events today. Add a Google iCal URL in Settings > Widgets or click '+' to add one.")
                                : L("Bugün için planlanmış etkinlik bulunmuyor.", "No events scheduled for today."))
                            : L("Bu tarihte kayıtlı etkinlik bulunmuyor.", "No events recorded for this date.");
                        emptyBox.Child = new TextBlock
                        {
                            Text = emptyMsg,
                            Foreground = HexBrush("#9E8C7E"),
                            FontSize = 10.5,
                            TextWrapping = TextWrapping.Wrap
                        };
                        calEventsListPanel.Children.Add(emptyBox);
                    }
                    else
                    {
                        foreach (CalendarEventItem ev in dayEvents)
                        {
                            calEventsListPanel.Children.Add(CreateAppleCalendarEventPill(ev, now, isViewingToday));
                        }
                    }

                    if (isViewingToday)
                    {
                        for (int ahead = 1; ahead <= 7; ahead++)
                        {
                            DateTime nextDate = today.AddDays(ahead);
                            List<CalendarEventItem> nextEvents = GetEventsForDate(snapshot, nextDate);
                            if (nextEvents.Count > 0)
                            {
                                string nextHdr = ahead == 1
                                    ? string.Format("{0} ({1} {2})", L("SIRADAKİ • YARIN", "UP NEXT • TOMORROW"), nextDate.Day, monthNamesUpper[nextDate.Month])
                                    : string.Format("{0} • {1} {2} {3}", L("SIRADAKİ", "UP NEXT"), nextDate.Day, monthNamesUpper[nextDate.Month], dayNamesUpper[(int)nextDate.DayOfWeek]);

                                calEventsListPanel.Children.Add(new TextBlock
                                {
                                    Text = nextHdr,
                                    Foreground = HexBrush("#A8988C"),
                                    FontSize = 9.5,
                                    FontWeight = FontWeights.Bold,
                                    Margin = new Thickness(2, 5, 0, 4)
                                });

                                int shownNext = 0;
                                foreach (CalendarEventItem nev in nextEvents)
                                {
                                    calEventsListPanel.Children.Add(CreateAppleCalendarEventPill(nev, now, false));
                                    shownNext++;
                                    if (shownNext >= 3) break;
                                }
                                break;
                            }
                        }
                    }

                    FitCalendarHeightToContent(autoShrinkHeight);
                }

                double effectiveH = (!double.IsNaN(calendarWindow.Height) && calendarWindow.Height > 200)
                    ? calendarWindow.Height
                    : (calendarWindow.ActualHeight > 200 ? calendarWindow.ActualHeight : savedCalHeight);
                RebuildCalendarLeftColumn(effectiveH);
            }
            catch { }
        }

        private void RebuildCalendarLeftColumn(double windowHeight)
        {
            if (calMiniMonthGrid == null) return;
            try
            {
                DateTime today = DateTime.Today;
                double availLeftH = Math.Max(138.0, windowHeight - 90.0);
                const double rowH = 22.0;
                const double subHdrH = 22.0;

                int quantizedSteps = (int)(availLeftH / 11.0);
                Dictionary<DateTime, byte> dotsLookup;
                int evVer;
                lock (calEventsLock)
                {
                    dotsLookup = calEventDotsByDate;
                    evVer = calEventsVersion;
                }

                string leftSig = string.Format("{0:yyyyMM}|{1:yyyyMMdd}|{2:yyyyMMdd}|{3}|{4}|{5}|{6}",
                    calDisplayedMonth, calSelectedDate.Date, today, evVer, accentColorHex, quantizedSteps, appLanguage);
                if (leftSig == lastLeftColumnSignature && calMiniMonthGrid.Children.Count > 0)
                    return;
                lastLeftColumnSignature = leftSig;

                string[] monthNamesUpper = IsEn
                    ? new string[] { "", "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER" }
                    : new string[] { "", "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK" };

                calMiniMonthGrid.Children.Clear();
                double usedH = 0.0;

                for (int m = 0; m < 12; m++)
                {
                    DateTime monthDate = new DateTime(calDisplayedMonth.Year, calDisplayedMonth.Month, 1).AddMonths(m);
                    int firstDayOffset = ((int)monthDate.DayOfWeek + 6) % 7;
                    int daysInMonth = DateTime.DaysInMonth(monthDate.Year, monthDate.Month);
                    int weekRows = (int)Math.Ceiling((firstDayOffset + daysInMonth) / 7.0);
                    DateTime gridStart = monthDate.AddDays(-firstDayOffset);

                    if (m > 0)
                    {
                        if (usedH + subHdrH + rowH > availLeftH)
                            break;

                        Border subMonthHdr = new Border
                        {
                            Height = subHdrH,
                            BorderBrush = HexBrush("#362C26"),
                            BorderThickness = new Thickness(0, 1, 0, 0),
                            Margin = new Thickness(0, 3, 0, 1),
                            Padding = new Thickness(2, 3, 2, 1)
                        };
                        subMonthHdr.Child = new TextBlock
                        {
                            Text = monthNamesUpper[monthDate.Month] + " " + monthDate.Year,
                            Foreground = HexBrush(accentColorHex),
                            FontSize = 9.5,
                            FontWeight = FontWeights.Bold,
                            VerticalAlignment = VerticalAlignment.Center
                        };
                        calMiniMonthGrid.Children.Add(subMonthHdr);
                        usedH += subHdrH + 4.0;
                    }

                    bool willFitNextMonth = (usedH + (weekRows * rowH) + subHdrH + rowH) <= availLeftH;

                    for (int w = 0; w < weekRows; w++)
                    {
                        if (m > 0 && usedH + rowH > availLeftH)
                            break;

                        UniformGrid weekRowGrid = new UniformGrid
                        {
                            Columns = 7,
                            Rows = 1,
                            Height = rowH,
                            VerticalAlignment = VerticalAlignment.Top
                        };

                        for (int d = 0; d < 7; d++)
                        {
                            int cell = w * 7 + d;
                            DateTime cellDate = gridStart.AddDays(cell).Date;
                            bool isCurrentMonth = (cellDate.Month == monthDate.Month);

                            if (!isCurrentMonth && (m > 0 || (willFitNextMonth && cellDate > monthDate)))
                            {
                                weekRowGrid.Children.Add(new Border { Width = 21, Height = 21 });
                                continue;
                            }

                            bool isToday = (cellDate == today);
                            bool isSelected = (cellDate == calSelectedDate.Date);

                            byte dotMask = 0;
                            if (dotsLookup != null) dotsLookup.TryGetValue(cellDate, out dotMask);
                            bool hasPrimaryEvent = (dotMask & 1) != 0;
                            bool hasHolidayEvent = (dotMask & 2) != 0;
                            bool hasExamEvent = (dotMask & 4) != 0;

                            Border dayCell = new Border
                            {
                                Width = 21,
                                Height = 21,
                                CornerRadius = new CornerRadius(10.5),
                                Background = isToday
                                    ? HexBrush(accentColorHex)
                                    : (isSelected ? HexBrush("#38281E") : Brushes.Transparent),
                                BorderBrush = (!isToday && isSelected) ? HexBrush(accentColorHex) : Brushes.Transparent,
                                BorderThickness = new Thickness(!isToday && isSelected ? 1.2 : 0),
                                Cursor = Cursors.Hand,
                                Tag = "Interactive",
                                HorizontalAlignment = HorizontalAlignment.Center,
                                VerticalAlignment = VerticalAlignment.Center
                            };

                            TextBlock txtNum = new TextBlock
                            {
                                Text = cellDate.Day.ToString(),
                                FontSize = 9.5,
                                FontWeight = (isToday || isSelected) ? FontWeights.Bold : FontWeights.Medium,
                                Foreground = isToday
                                    ? Brushes.White
                                    : (isCurrentMonth ? HexBrush("#FAF6F2") : HexBrush("#5E5047")),
                                HorizontalAlignment = HorizontalAlignment.Center,
                                VerticalAlignment = VerticalAlignment.Center,
                                Margin = new Thickness(0, -1, 0, 0)
                            };

                            if (hasPrimaryEvent || hasHolidayEvent || hasExamEvent)
                            {
                                StackPanel cellStack = new StackPanel
                                {
                                    VerticalAlignment = VerticalAlignment.Center,
                                    HorizontalAlignment = HorizontalAlignment.Center
                                };
                                cellStack.Children.Add(txtNum);

                                string dotHex = hasExamEvent ? "#C084FC" : (hasPrimaryEvent ? accentColorHex : "#9A9CFF");
                                Border dot = new Border
                                {
                                    Width = 3.5,
                                    Height = 3.5,
                                    CornerRadius = new CornerRadius(2),
                                    Background = isToday ? Brushes.White : HexBrush(dotHex),
                                    HorizontalAlignment = HorizontalAlignment.Center,
                                    Margin = new Thickness(0, 0.5, 0, 0)
                                };
                                cellStack.Children.Add(dot);
                                dayCell.Child = cellStack;
                            }
                            else
                            {
                                dayCell.Child = txtNum;
                            }
                            DateTime capturedDate = cellDate;
                            dayCell.MouseLeftButtonDown += (s, e) =>
                            {
                                calSelectedDate = capturedDate;
                                if (capturedDate.Month != calDisplayedMonth.Month || capturedDate.Year != calDisplayedMonth.Year)
                                {
                                    calDisplayedMonth = new DateTime(capturedDate.Year, capturedDate.Month, 1);
                                }
                                RefreshCalendarWidgetUi();
                                e.Handled = true;
                            };

                            weekRowGrid.Children.Add(dayCell);
                        }

                        calMiniMonthGrid.Children.Add(weekRowGrid);
                        usedH += rowH;
                    }

                    if (usedH + subHdrH + rowH > availLeftH)
                        break;
                }
            }
            catch { }
        }

        private void FitCalendarHeightToContent(bool allowShrink = true)
        {
            if (calendarWindow == null || calEventsListPanel == null) return;
            try
            {
                double winW = calendarWindow.ActualWidth > 300 ? calendarWindow.ActualWidth : savedCalWidth;
                double rightWidth = Math.Max(210, winW - 234);
                calEventsListPanel.Measure(new Size(rightWidth, double.PositiveInfinity));
                double eventsH = calEventsListPanel.DesiredSize.Height;
                double quickAddH = (calQuickAddPanel != null && calQuickAddPanel.Visibility == Visibility.Visible) ? 38 : 0;
                double neededRightH = eventsH + quickAddH + 68;
                double minLeftH = 246;
                Rect workArea = GetWindowMonitorWorkArea(calendarWindow);
                double targetH = Math.Min(workArea.Height - 40, Math.Max(minLeftH, Math.Ceiling(neededRightH)));
                if ((allowShrink && Math.Abs(calendarWindow.Height - targetH) > 1.0) || (!allowShrink && calendarWindow.Height < targetH - 1.0))
                {
                    calendarWindow.Height = targetH;
                    savedCalHeight = targetH;
                }
            }
            catch { }
        }

        private UIElement CreateAppleCalendarEventPill(CalendarEventItem ev, DateTime now, bool isTodayCard)
        {
            bool isOngoing = !ev.AllDay && isTodayCard && now >= ev.Start && now <= ev.End;
            bool isPastToday = !ev.AllDay && isTodayCard && now > ev.End;

            string customCol = !string.IsNullOrEmpty(ev.ColorHex) ? ev.ColorHex : "#10B981";
            string barHex = ev.Source == "holiday" ? "#9A9CFF" : (isOngoing ? accentColorHex : customCol);
            if (ev.Source == "custom") barHex = accentColorHex;

            Border card = new Border
            {
                CornerRadius = new CornerRadius(8),
                Background = HexBrush(isOngoing ? "#AA382920" : "#8828211E"),
                BorderBrush = HexBrush(isOngoing ? accentColorHex : "#443730"),
                BorderThickness = new Thickness(isOngoing ? 1.2 : 1),
                Padding = new Thickness(7, 5, 8, 5),
                Margin = new Thickness(0, 0, 0, 5),
                Opacity = isPastToday ? 0.62 : 1.0,
                Cursor = Cursors.Hand,
                Tag = "Interactive",
                ToolTip = ev.Title + (string.IsNullOrEmpty(ev.Location) ? "" : ("\n📍 " + ev.Location)) + (string.IsNullOrEmpty(ev.Description) ? "" : ("\n" + ev.Description))
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Border colorBar = new Border
            {
                Width = 3.5,
                CornerRadius = new CornerRadius(2),
                Background = HexBrush(barHex),
                Margin = new Thickness(0, 1, 8, 1)
            };
            Grid.SetColumn(colorBar, 0);
            g.Children.Add(colorBar);

            StackPanel infoStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };

            Grid titleRow = new Grid();
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            TextBlock txtTitle = new TextBlock
            {
                Text = ev.Title,
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                TextTrimming = TextTrimming.CharacterEllipsis,
                Margin = new Thickness(0, 0, 6, 0)
            };
            Grid.SetColumn(txtTitle, 0);
            titleRow.Children.Add(txtTitle);

            string timeBadgeText = ev.AllDay
                ? L("Tüm Gün", "All Day")
                : (ev.Start.ToString("HH:mm") + " – " + ev.End.ToString("HH:mm"));
            if (isOngoing) timeBadgeText = L("● ŞİMDİ (", "● NOW (") + ev.End.ToString("HH:mm") + L("'e kadar)", " end)");

            TextBlock txtTime = new TextBlock
            {
                Text = timeBadgeText,
                Foreground = HexBrush(isOngoing ? accentColorHex : "#C7B9AE"),
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(txtTime, 1);
            titleRow.Children.Add(txtTime);
            infoStack.Children.Add(titleRow);

            string subLine = "";
            if (!string.IsNullOrEmpty(ev.Location)) subLine += "📍 " + ev.Location;
            if (!string.IsNullOrEmpty(ev.Description) && !ev.Description.StartsWith("Bunun gibi otomatik"))
            {
                if (subLine.Length > 0) subLine += "  •  ";
                subLine += ev.Description;
            }
            if (!string.IsNullOrEmpty(subLine))
            {
                infoStack.Children.Add(new TextBlock
                {
                    Text = subLine,
                    Foreground = HexBrush("#9E8E82"),
                    FontSize = 10,
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    Margin = new Thickness(0, 1.5, 0, 0)
                });
            }

            Grid.SetColumn(infoStack, 1);
            g.Children.Add(infoStack);

            if (ev.Source == "custom" && !string.IsNullOrEmpty(ev.RawCustomLine))
            {
                string rawToRemove = ev.RawCustomLine;
                Button btnDel = CreateStyledIconButton("Transparent", "Transparent", L("Bu özel etkinliği sil", "Delete custom event"));
                btnDel.Padding = new Thickness(4, 0, 2, 0);
                btnDel.Content = new TextBlock { Text = "✕", Foreground = HexBrush("#8C7A6B"), FontSize = 9.5 };
                btnDel.Click += (s, e) =>
                {
                    RemoveCustomCalendarEvent(rawToRemove);
                    e.Handled = true;
                };
                Grid.SetColumn(btnDel, 2);
                g.Children.Add(btnDel);
            }

            card.Child = g;
            card.MouseEnter += (s, e) => card.Background = HexBrush("#BB382D27");
            card.MouseLeave += (s, e) => card.Background = HexBrush(isOngoing ? "#AA382920" : "#8828211E");
            card.MouseLeftButtonDown += (s, e) =>
            {
                if (!string.IsNullOrEmpty(ev.HtmlLink))
                {
                    try { Process.Start(ev.HtmlLink); } catch { }
                }
                else
                {
                    ShowToast(ev.Title + (string.IsNullOrEmpty(ev.Location) ? "" : (" • " + ev.Location)));
                }
            };

            return card;
        }

        private bool DoesEventOccurOnDate(CalendarEventItem ev, DateTime date)
        {
            DateTime d = date.Date;
            if (ev.AllDay)
            {
                DateTime s = ev.Start.Date;
                DateTime e = ev.End.Date;
                if (e <= s) e = s.AddDays(1);
                return d >= s && d < e;
            }
            return ev.Start.Date == d;
        }

        private List<CalendarEventItem> GetEventsForDate(List<CalendarEventItem> all, DateTime date)
        {
            List<CalendarEventItem> list = new List<CalendarEventItem>();
            foreach (var ev in all)
            {
                if (DoesEventOccurOnDate(ev, date))
                    list.Add(ev);
            }
            list.Sort((a, b) =>
            {
                if (a.AllDay != b.AllDay) return a.AllDay ? -1 : 1;
                return a.Start.CompareTo(b.Start);
            });
            return list;
        }

        private void AddCustomCalendarEventFromUi()
        {
            try
            {
                string title = txtCalQuickTitle.Text.Trim();
                if (string.IsNullOrEmpty(title))
                {
                    ShowToast(L("Lütfen etkinlik başlığı girin", "Please enter an event title"));
                    return;
                }
                string timePart = txtCalQuickTime.Text.Trim();
                DateTime startDt = calSelectedDate.Date.AddHours(12);
                DateTime endDt = startDt.AddHours(1);
                bool allDay = false;

                if (string.IsNullOrEmpty(timePart) ||
                    timePart.Equals("tüm gün", StringComparison.OrdinalIgnoreCase) ||
                    timePart.Equals("all day", StringComparison.OrdinalIgnoreCase))
                {
                    allDay = true;
                    startDt = calSelectedDate.Date;
                    endDt = startDt.AddDays(1);
                }
                else
                {
                    string[] rangeParts = timePart.Split(new char[] { '-', '–' }, StringSplitOptions.RemoveEmptyEntries);
                    TimeSpan ts1;
                    if (rangeParts.Length >= 1 && TimeSpan.TryParse(rangeParts[0].Trim(), out ts1))
                    {
                        startDt = calSelectedDate.Date.Add(ts1);
                        endDt = startDt.AddHours(1);
                    }
                    TimeSpan ts2;
                    if (rangeParts.Length >= 2 && TimeSpan.TryParse(rangeParts[1].Trim(), out ts2))
                    {
                        endDt = calSelectedDate.Date.Add(ts2);
                    }
                }

                string customFile = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "custom_events.dat");
                string cleanTitle = title.Replace("|", "/");
                string line = string.Format("{0}|{1}|{2}|custom|{3}|{4}|||https://calendar.google.com",
                    allDay ? startDt.ToString("yyyy-MM-dd") : startDt.ToString("yyyy-MM-ddTHH:mm:ss"),
                    allDay ? endDt.ToString("yyyy-MM-dd") : endDt.ToString("yyyy-MM-ddTHH:mm:ss"),
                    allDay ? "True" : "False",
                    accentColorHex,
                    cleanTitle);

                File.AppendAllLines(customFile, new string[] { line }, new UTF8Encoding(false));
                txtCalQuickTitle.Text = "";
                calQuickAddPanel.Visibility = Visibility.Collapsed;
                Task.Run(() => LoadAndSyncCalendarEventsAsync(false));
                ShowToast(L("Etkinlik takvime eklendi: ", "Event added to calendar: ") + cleanTitle);
            }
            catch { }
        }

        private void RemoveCustomCalendarEvent(string rawLine)
        {
            try
            {
                string customFile = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "custom_events.dat");
                if (File.Exists(customFile))
                {
                    List<string> kept = new List<string>();
                    foreach (string l in File.ReadAllLines(customFile, Encoding.UTF8))
                    {
                        if (l.Trim() != rawLine.Trim()) kept.Add(l);
                    }
                    File.WriteAllLines(customFile, kept.ToArray(), new UTF8Encoding(false));
                }
                Task.Run(() => LoadAndSyncCalendarEventsAsync(false));
                ShowToast(L("Etkinlik silindi", "Event deleted"));
            }
            catch { }
        }

        private void LoadAndSyncCalendarEventsAsync(bool showToastOnDone)
        {
            try
            {
                string datPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "calendar_events.dat");
                string customPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "custom_events.dat");

                DateTime datWrite = File.Exists(datPath) ? File.GetLastWriteTimeUtc(datPath) : DateTime.MinValue;
                DateTime customWrite = File.Exists(customPath) ? File.GetLastWriteTimeUtc(customPath) : DateTime.MinValue;
                bool hasLiveIcal = !string.IsNullOrEmpty(calendarSecretIcalUrl) && calendarSecretIcalUrl.StartsWith("http", StringComparison.OrdinalIgnoreCase);

                if (!showToastOnDone && !hasLiveIcal && datWrite == lastCalDatWriteUtc && customWrite == lastCustomDatWriteUtc && allCalendarEvents.Count > 0)
                {
                    return;
                }

                List<CalendarEventItem> loaded = new List<CalendarEventItem>(128);

                if (File.Exists(datPath))
                {
                    foreach (string line in File.ReadAllLines(datPath, Encoding.UTF8))
                    {
                        CalendarEventItem item = ParsePipeEventLine(line, false);
                        if (item != null) loaded.Add(item);
                    }
                }

                if (File.Exists(customPath))
                {
                    foreach (string line in File.ReadAllLines(customPath, Encoding.UTF8))
                    {
                        CalendarEventItem item = ParsePipeEventLine(line, true);
                        if (item != null) loaded.Add(item);
                    }
                }

                if (hasLiveIcal)
                {
                    try
                    {
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(calendarSecretIcalUrl);
                        req.Timeout = 7000;
                        req.UserAgent = "OpenWidgetCalendar/2.2";
                        using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                        {
                            string icsContent = reader.ReadToEnd();
                            List<CalendarEventItem> icsItems = ParseIcsContent(icsContent, "primary", "#10B981");
                            if (icsItems.Count > 0)
                            {
                                loaded.RemoveAll(x => x.Source == "primary");
                                loaded.AddRange(icsItems);
                            }
                        }
                    }
                    catch { }
                }

                Dictionary<DateTime, byte> dotsMap = new Dictionary<DateTime, byte>(loaded.Count + 16);
                for (int i = 0; i < loaded.Count; i++)
                {
                    CalendarEventItem ev = loaded[i];
                    bool isExam = (ev.ColorHex == "#C084FC") || (ev.Title != null &&
                        (ev.Title.IndexOf("Sınav", StringComparison.OrdinalIgnoreCase) >= 0 ||
                         ev.Title.IndexOf("Exam", StringComparison.OrdinalIgnoreCase) >= 0));
                    byte bit = (ev.Source == "holiday") ? (byte)2 : (isExam ? (byte)4 : (byte)1);
                    if (ev.AllDay)
                    {
                        DateTime s = ev.Start.Date;
                        DateTime e = ev.End.Date;
                        if (e <= s) e = s.AddDays(1);
                        for (DateTime d = s; d < e; d = d.AddDays(1))
                        {
                            byte cur;
                            dotsMap.TryGetValue(d, out cur);
                            dotsMap[d] = (byte)(cur | bit);
                        }
                    }
                    else
                    {
                        DateTime d = ev.Start.Date;
                        byte cur;
                        dotsMap.TryGetValue(d, out cur);
                        dotsMap[d] = (byte)(cur | bit);
                    }
                }

                lock (calEventsLock)
                {
                    allCalendarEvents.Clear();
                    allCalendarEvents.AddRange(loaded);
                    calEventDotsByDate = dotsMap;
                    calEventsVersion++;
                    lastCalDatWriteUtc = datWrite;
                    lastCustomDatWriteUtc = customWrite;
                }

                Dispatcher.Invoke(() =>
                {
                    RefreshCalendarWidgetUi();
                    if (showToastOnDone)
                        ShowToast(string.Format(L("Takvim senkronize edildi ({0} etkinlik)", "Calendar synced ({0} events)"), loaded.Count));
                });

                TrimProcessMemory();
            }
            catch { }
        }

        private CalendarEventItem ParsePipeEventLine(string line, bool isCustom)
        {
            if (string.IsNullOrWhiteSpace(line)) return null;
            string[] p = line.Split('|');
            if (p.Length < 6) return null;

            DateTime startDt, endDt;
            if (!DateTime.TryParse(p[0], System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.RoundtripKind, out startDt))
                return null;
            if (!DateTime.TryParse(p[1], System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.RoundtripKind, out endDt))
                endDt = startDt.AddHours(1);

            bool allDay = p[2].Equals("True", StringComparison.OrdinalIgnoreCase);
            return new CalendarEventItem
            {
                Start = startDt.ToLocalTime(),
                End = endDt.ToLocalTime(),
                AllDay = allDay,
                Source = isCustom ? "custom" : p[3],
                ColorHex = string.IsNullOrEmpty(p[4]) ? "#10B981" : p[4],
                Title = p[5],
                Location = p.Length > 6 ? p[6] : "",
                Description = p.Length > 7 ? p[7] : "",
                HtmlLink = p.Length > 8 ? p[8] : "",
                RawCustomLine = isCustom ? line : null
            };
        }

        private List<CalendarEventItem> ParseIcsContent(string ics, string sourceTag, string defaultColor)
        {
            List<CalendarEventItem> results = new List<CalendarEventItem>();
            if (string.IsNullOrEmpty(ics)) return results;

            string unfolded = ics.Replace("\r\n ", "").Replace("\r\n\t", "").Replace("\n ", "").Replace("\n\t", "");
            string[] lines = unfolded.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            bool inEvent = false;
            string summary = "", location = "", desc = "", dtStartRaw = "", dtEndRaw = "", uid = "", rrule = "", recurIdRaw = "", status = "";
            List<string> exdates = new List<string>();

            List<CalendarEventItem> singles = new List<CalendarEventItem>();
            Dictionary<string, HashSet<DateTime>> overriddenStarts = new Dictionary<string, HashSet<DateTime>>();
            List<object[]> masters = new List<object[]>();

            DateTime windowStart = DateTime.Today.AddMonths(-3);
            DateTime windowEnd = DateTime.Today.AddMonths(9);

            foreach (string rawLine in lines)
            {
                if (rawLine == "BEGIN:VEVENT")
                {
                    inEvent = true;
                    summary = ""; location = ""; desc = ""; dtStartRaw = ""; dtEndRaw = ""; uid = ""; rrule = ""; recurIdRaw = ""; status = "";
                    exdates = new List<string>();
                }
                else if (rawLine == "END:VEVENT" && inEvent)
                {
                    inEvent = false;
                    DateTime sDt, eDt;
                    bool isAllDay;
                    if (!TryParseIcsDate(dtStartRaw, out sDt, out isAllDay)) continue;
                    bool dummy;
                    if (!TryParseIcsDate(dtEndRaw, out eDt, out dummy))
                        eDt = isAllDay ? sDt.AddDays(1) : sDt.AddHours(1);

                    string ttl = UnescapeIcsText(summary);
                    bool isExam = ttl.IndexOf("Sınav", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  ttl.IndexOf("Vize", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  ttl.IndexOf("Final", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  ttl.IndexOf("Exam", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  ttl.IndexOf("Midterm", StringComparison.OrdinalIgnoreCase) >= 0;
                    CalendarEventItem item = new CalendarEventItem
                    {
                        Start = sDt,
                        End = eDt,
                        AllDay = isAllDay,
                        Source = sourceTag,
                        ColorHex = isExam ? "#C084FC" : defaultColor,
                        Title = ttl,
                        Location = UnescapeIcsText(location),
                        Description = UnescapeIcsText(desc),
                        HtmlLink = "https://calendar.google.com"
                    };
                    bool cancelled = status.Equals("CANCELLED", StringComparison.OrdinalIgnoreCase);

                    if (!string.IsNullOrEmpty(recurIdRaw))
                    {
                        DateTime rid; bool ridAllDay;
                        if (TryParseIcsDate(recurIdRaw, out rid, out ridAllDay))
                        {
                            HashSet<DateTime> set;
                            if (!overriddenStarts.TryGetValue(uid, out set)) { set = new HashSet<DateTime>(); overriddenStarts[uid] = set; }
                            set.Add(rid);
                        }
                        if (!cancelled) singles.Add(item);
                    }
                    else if (!string.IsNullOrEmpty(rrule))
                    {
                        HashSet<DateTime> exSet = new HashSet<DateTime>();
                        foreach (string exLine in exdates)
                        {
                            foreach (string part in exLine.Split(','))
                            {
                                DateTime ex; bool exAd;
                                if (TryParseIcsDate(part, out ex, out exAd)) exSet.Add(ex);
                            }
                        }
                        if (!cancelled) masters.Add(new object[] { item, rrule, uid, exSet });
                    }
                    else if (!cancelled)
                    {
                        singles.Add(item);
                    }
                }
                else if (inEvent)
                {
                    int colon = rawLine.IndexOf(':');
                    if (colon > 0)
                    {
                        string keyPart = rawLine.Substring(0, colon).ToUpperInvariant();
                        string valPart = rawLine.Substring(colon + 1);
                        if (keyPart.StartsWith("DTSTART")) dtStartRaw = valPart;
                        else if (keyPart.StartsWith("DTEND")) dtEndRaw = valPart;
                        else if (keyPart.StartsWith("SUMMARY")) summary = valPart;
                        else if (keyPart.StartsWith("LOCATION")) location = valPart;
                        else if (keyPart.StartsWith("DESCRIPTION")) desc = valPart;
                        else if (keyPart == "UID") uid = valPart.Trim();
                        else if (keyPart == "RRULE") rrule = valPart.Trim();
                        else if (keyPart.StartsWith("EXDATE")) exdates.Add(valPart.Trim());
                        else if (keyPart.StartsWith("RECURRENCE-ID")) recurIdRaw = valPart.Trim();
                        else if (keyPart == "STATUS") status = valPart.Trim();
                    }
                }
            }

            foreach (object[] mInfo in masters)
            {
                CalendarEventItem master = (CalendarEventItem)mInfo[0];
                string rule = (string)mInfo[1];
                string mUid = (string)mInfo[2];
                HashSet<DateTime> exSet = (HashSet<DateTime>)mInfo[3];
                HashSet<DateTime> ovSet;
                overriddenStarts.TryGetValue(mUid, out ovSet);

                foreach (DateTime occ in ExpandRRule(master.Start, rule, windowStart, windowEnd))
                {
                    if (exSet.Contains(occ)) continue;
                    if (ovSet != null && ovSet.Contains(occ)) continue;
                    TimeSpan dur = master.End - master.Start;
                    results.Add(new CalendarEventItem
                    {
                        Start = occ,
                        End = occ + dur,
                        AllDay = master.AllDay,
                        Source = master.Source,
                        ColorHex = master.ColorHex,
                        Title = master.Title,
                        Location = master.Location,
                        Description = master.Description,
                        HtmlLink = master.HtmlLink
                    });
                }
            }
            results.AddRange(singles);
            return results;
        }

        private IEnumerable<DateTime> ExpandRRule(DateTime dtStart, string rule, DateTime windowStart, DateTime windowEnd)
        {
            string freq = "WEEKLY";
            int interval = 1;
            int count = -1;
            DateTime until = DateTime.MaxValue;
            List<DayOfWeek> byDays = new List<DayOfWeek>();

            foreach (string kv in rule.Split(';'))
            {
                int eq = kv.IndexOf('=');
                if (eq <= 0) continue;
                string k = kv.Substring(0, eq).ToUpperInvariant();
                string v = kv.Substring(eq + 1);
                if (k == "FREQ") freq = v.ToUpperInvariant();
                else if (k == "INTERVAL") { int iv; if (int.TryParse(v, out iv) && iv > 0) interval = iv; }
                else if (k == "COUNT") { int c; if (int.TryParse(v, out c)) count = c; }
                else if (k == "UNTIL") { DateTime u; bool uad; if (TryParseIcsDate(v, out u, out uad)) until = uad ? u.AddDays(1).AddSeconds(-1) : u; }
                else if (k == "BYDAY")
                {
                    foreach (string d in v.Split(','))
                    {
                        string dd = d.Trim().ToUpperInvariant();
                        if (dd.Length > 2) dd = dd.Substring(dd.Length - 2);
                        switch (dd)
                        {
                            case "MO": byDays.Add(DayOfWeek.Monday); break;
                            case "TU": byDays.Add(DayOfWeek.Tuesday); break;
                            case "WE": byDays.Add(DayOfWeek.Wednesday); break;
                            case "TH": byDays.Add(DayOfWeek.Thursday); break;
                            case "FR": byDays.Add(DayOfWeek.Friday); break;
                            case "SA": byDays.Add(DayOfWeek.Saturday); break;
                            case "SU": byDays.Add(DayOfWeek.Sunday); break;
                        }
                    }
                }
            }

            int produced = 0;
            int safety = 0;
            if (freq == "WEEKLY")
            {
                if (byDays.Count == 0) byDays.Add(dtStart.DayOfWeek);
                int startOffset = ((int)dtStart.DayOfWeek + 6) % 7;
                DateTime weekStart = dtStart.Date.AddDays(-startOffset);
                while (safety++ < 2000)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        DateTime day = weekStart.AddDays(i);
                        if (!byDays.Contains(day.DayOfWeek)) continue;
                        DateTime occ = day + dtStart.TimeOfDay;
                        if (occ < dtStart) continue;
                        if (occ > until || (count >= 0 && produced >= count)) yield break;
                        produced++;
                        if (occ > windowEnd) yield break;
                        if (occ >= windowStart) yield return occ;
                    }
                    weekStart = weekStart.AddDays(7 * interval);
                }
            }
            else
            {
                DateTime occ = dtStart;
                while (safety++ < 5000)
                {
                    if (occ > until || (count >= 0 && produced >= count) || occ > windowEnd) yield break;
                    produced++;
                    if (occ >= windowStart) yield return occ;
                    if (freq == "DAILY") occ = occ.AddDays(interval);
                    else if (freq == "MONTHLY") occ = occ.AddMonths(interval);
                    else if (freq == "YEARLY") occ = occ.AddYears(interval);
                    else yield break;
                }
            }
        }

        private bool TryParseIcsDate(string raw, out DateTime dt, out bool allDay)
        {
            dt = DateTime.MinValue;
            allDay = false;
            if (string.IsNullOrEmpty(raw)) return false;
            raw = raw.Trim();
            if (raw.Length == 8 && DateTime.TryParseExact(raw, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt))
            {
                allDay = true;
                return true;
            }
            if (raw.EndsWith("Z") && DateTime.TryParseExact(raw, "yyyyMMdd'T'HHmmss'Z'", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.AdjustToUniversal, out dt))
            {
                dt = dt.ToLocalTime();
                return true;
            }
            if (DateTime.TryParseExact(raw, "yyyyMMdd'T'HHmmss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt))
            {
                return true;
            }
            return false;
        }

        private string UnescapeIcsText(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\n", " ").Replace("\\N", " ").Replace("\\,", ",").Replace("\\;", ";").Trim();
        }

        // =========================================================================
        // STANDALONE TIMER WIDGET (MODES, AUTO GAME MODE, POMODORO & HEATMAP)
        // =========================================================================
        public void SetTimerWidgetVisible(bool visible)
        {
            showTimerWidget = visible;
            SaveSettings();
            if (trayTimerItem != null)
            {
                trayTimerItem.Text = showTimerWidget
                    ? L("⏱ Timer Widgeti'ni Gizle", "⏱ Hide Timer Widget")
                    : L("⏱ Timer Widgeti'ni Göster", "⏱ Show Timer Widget");
            }
            if (timerWindow == null && showTimerWidget)
            {
                InitializeTimerWidget();
                return;
            }
            if (timerWindow != null)
            {
                if (showTimerWidget)
                {
                    timerWindow.Show();
                    IntPtr thwnd = cachedTimerHwnd != IntPtr.Zero ? cachedTimerHwnd : new WindowInteropHelper(timerWindow).Handle;
                    if (thwnd != IntPtr.Zero) SendWidgetToDesktopBottom(thwnd);
                    UpdateTimerWidgetUi();
                }
                else
                {
                    SaveTimerActivityData();
                    timerWindow.Hide();
                }
            }
        }

        private void LoadTimerActivityData()
        {
            try
            {
                activityDataFilePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "timer_activity.dat");
                activityByDate.Clear();
                if (File.Exists(activityDataFilePath))
                {
                    foreach (string line in File.ReadAllLines(activityDataFilePath, Encoding.UTF8))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        string[] p = line.Split('|');
                        DateTime dt;
                        int st, gm, pc;
                        if (p.Length >= 4 &&
                            DateTime.TryParseExact(p[0].Trim(), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt) &&
                            int.TryParse(p[1], out st) &&
                            int.TryParse(p[2], out gm) &&
                            int.TryParse(p[3], out pc))
                        {
                            activityByDate[dt.Date] = new DailyActivityRecord
                            {
                                Date = dt.Date,
                                StudySeconds = Math.Max(0, st),
                                GameSeconds = Math.Max(0, gm),
                                PcSeconds = Math.Max(0, pc)
                            };
                        }
                    }
                }

                DailyActivityRecord todayRec = GetOrCreateActivityRecord(DateTime.Today);
                if (todayRec.PcSeconds == 0)
                {
                    double bootSec = GetTickCount64() / 1000.0;
                    if (DateTime.Now.AddSeconds(-bootSec).Date == DateTime.Today)
                    {
                        todayRec.PcSeconds = (int)Math.Max(0, Math.Min(86400, bootSec));
                    }
                }
            }
            catch { }
        }

        private DailyActivityRecord GetOrCreateActivityRecord(DateTime date)
        {
            DateTime d = date.Date;
            DailyActivityRecord rec;
            if (!activityByDate.TryGetValue(d, out rec))
            {
                rec = new DailyActivityRecord { Date = d };
                activityByDate[d] = rec;
            }
            return rec;
        }

        private void SaveTimerActivityData()
        {
            try
            {
                if (string.IsNullOrEmpty(activityDataFilePath))
                    activityDataFilePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "timer_activity.dat");

                List<DailyActivityRecord> rows = new List<DailyActivityRecord>(activityByDate.Values);
                rows.Sort((a, b) => a.Date.CompareTo(b.Date));

                StringBuilder sb = new StringBuilder(rows.Count * 28);
                DateTime cutoff = DateTime.Today.AddDays(-400);
                for (int i = 0; i < rows.Count; i++)
                {
                    DailyActivityRecord r = rows[i];
                    if (r.Date < cutoff) continue;
                    if (r.StudySeconds == 0 && r.GameSeconds == 0 && r.PcSeconds == 0) continue;
                    sb.Append(r.Date.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture))
                      .Append('|').Append(r.StudySeconds)
                      .Append('|').Append(r.GameSeconds)
                      .Append('|').Append(r.PcSeconds)
                      .AppendLine();
                }
                File.WriteAllText(activityDataFilePath, sb.ToString(), new UTF8Encoding(false));
            }
            catch { }
        }

        private void InitializeTimerWidget()
        {
            if (timerWindow != null) return;

            activeTrackingDate = DateTime.Today;
            pomoRemainingSeconds = pomoFocusMinutes * 60;
            LoadTimerActivityData();

            timerWindow = new Window
            {
                Title = L("OpenWidget • Timer Widgeti", "OpenWidget • Timer Widget"),
                MinWidth = 460,
                MinHeight = 275,
                Width = savedTimerWidth,
                Height = savedTimerHeight,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                Background = Brushes.Transparent,
                ResizeMode = isDraggable ? ResizeMode.CanResize : ResizeMode.NoResize,
                ShowInTaskbar = false,
                Topmost = false,
                UseLayoutRounding = true,
                SnapsToDevicePixels = true,
                FontFamily = new FontFamily("Segoe UI")
            };
            Program.TryApplyWindowIcon(timerWindow);
            TextOptions.SetTextFormattingMode(timerWindow, TextFormattingMode.Display);
            TextOptions.SetTextRenderingMode(timerWindow, TextRenderingMode.ClearType);
            RenderOptions.SetClearTypeHint(timerWindow, ClearTypeHint.Enabled);

            if (IsPositionWithinVirtualDesktop(savedTimerLeft, savedTimerTop, savedTimerWidth, savedTimerHeight))
            {
                timerWindow.Left = savedTimerLeft;
                timerWindow.Top = savedTimerTop;
            }
            else
            {
                Rect workArea = GetWindowMonitorWorkArea(this);
                double baseLeft = !double.IsNaN(savedCalLeft) ? savedCalLeft : (this.Left - savedTimerWidth - 10);
                if (baseLeft < workArea.Left + 10) baseLeft = workArea.Left + 14;
                double baseTop = (!double.IsNaN(savedCalTop) ? savedCalTop : this.Top) + savedCalHeight + 10;
                if (baseTop + savedTimerHeight > workArea.Bottom - 10)
                    baseTop = Math.Max(workArea.Top + 14, workArea.Bottom - savedTimerHeight - 14);
                timerWindow.Left = baseLeft;
                timerWindow.Top = baseTop;
                savedTimerLeft = timerWindow.Left;
                savedTimerTop = timerWindow.Top;
            }

            timerWindowChrome = new WindowChrome
            {
                CaptionHeight = 0,
                CornerRadius = new CornerRadius(0),
                GlassFrameThickness = new Thickness(0),
                NonClientFrameEdges = NonClientFrameEdges.None,
                ResizeBorderThickness = isDraggable ? new Thickness(8) : new Thickness(0)
            };
            WindowChrome.SetWindowChrome(timerWindow, timerWindowChrome);

            timerWindow.SizeChanged += (s, e) =>
            {
                if (timerWindow.ActualWidth >= 460 && timerWindow.ActualHeight >= 275)
                {
                    savedTimerWidth = timerWindow.ActualWidth;
                    savedTimerHeight = timerWindow.ActualHeight;
                    SaveSettingsDebounced();
                }
            };

            timerWindow.PreviewMouseLeftButtonDown += (s, e) =>
            {
                if (!isDraggable) return;
                DependencyObject dep = e.OriginalSource as DependencyObject;
                while (dep != null && dep != timerWindow)
                {
                    if (dep is ButtonBase || dep is Slider || dep is Thumb || dep is TextBox || dep is ScrollBar)
                        return;
                    if (dep is FrameworkElement)
                    {
                        FrameworkElement fe = (FrameworkElement)dep;
                        if (fe.Tag != null && fe.Tag.ToString() == "Interactive") return;
                    }
                    dep = VisualTreeHelper.GetParent(dep);
                }
                try
                {
                    IntPtr thwnd = cachedTimerHwnd != IntPtr.Zero ? cachedTimerHwnd : new WindowInteropHelper(timerWindow).Handle;
                    ReleaseCapture();
                    SendMessage(thwnd, WM_NCLBUTTONDOWN, (IntPtr)HT_CAPTION, IntPtr.Zero);
                    savedTimerLeft = timerWindow.Left;
                    savedTimerTop = timerWindow.Top;
                    SaveSettingsDebounced();
                    e.Handled = true;
                }
                catch { }
            };

            timerWindow.LocationChanged += (s, e) =>
            {
                if (isTimerWindowInitialized && !double.IsNaN(timerWindow.Left) && !double.IsNaN(timerWindow.Top) && timerWindow.Left > -10000 && timerWindow.Top > -10000)
                {
                    savedTimerLeft = timerWindow.Left;
                    savedTimerTop = timerWindow.Top;
                    SaveSettingsDebounced();
                }
            };

            timerWindow.Loaded += (s, e) =>
            {
                IntPtr thwnd = new WindowInteropHelper(timerWindow).Handle;
                cachedTimerHwnd = thwnd;
                int exStyle = GetWindowLong(thwnd, GWL_EXSTYLE);
                SetWindowLong(thwnd, GWL_EXSTYLE, exStyle | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE);
                AttachToDesktopShell(thwnd);
                HwndSource src = HwndSource.FromHwnd(thwnd);
                if (src != null) src.AddHook(WndProc);
                isTimerWindowInitialized = true;
            };

            timerWindow.StateChanged += (s, e) =>
            {
                if (timerWindow.WindowState == WindowState.Minimized)
                    timerWindow.WindowState = WindowState.Normal;
            };

            BuildTimerWidgetUi();
            ApplyTimerWidgetTheme();

            if (showTimerWidget)
            {
                timerWindow.Show();
            }

            timerWidgetTickTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timerWidgetTickTimer.Tick += (s, e) => OnTimerWidgetSecondTick();
            timerWidgetTickTimer.Start();
        }

        private void BuildTimerWidgetUi()
        {
            timerOuterBorder = new Border
            {
                CornerRadius = new CornerRadius(16),
                BorderThickness = new Thickness(1),
                Margin = new Thickness(2),
                Padding = new Thickness(14, 10, 14, 10)
            };

            Grid rootGrid = new Grid();
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1.50, GridUnitType.Star) });
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(0.92, GridUnitType.Star) });

            Grid topBar = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            topBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            StackPanel titleStack = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            titleStack.Children.Add(new TextBlock
            {
                Text = L("⏱ Timer Widgeti", "⏱ Timer Widget"),
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            });
            Grid.SetColumn(titleStack, 0);
            topBar.Children.Add(titleStack);

            StackPanel modeSwitcherPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Tag = "Interactive"
            };
            string[] modeLabels = { L("🖥 Default", "🖥 Default"), L("🎮 Eğlence", "🎮 Gaming"), L("📚 Ders Modu", "📚 Study") };
            string[] modeTips = {
                L("Default Mod (Normal zamanlayıcı)", "Default Mode (Standard stopwatch timer)"),
                L("Eğlence / Oyun Modu (Oyun oynarken geçen süre günlük kaydedilir)", "Gaming Mode (Tracks daily gaming time)"),
                L("Ders / Pomodoro Modu (Pomodoro & günlük çalışma süresi)", "Study Mode (Pomodoro & daily study time)")
            };
            for (int i = 0; i < 3; i++)
            {
                int mIdx = i;
                Button mb = CreateStyledIconButton("#26201D", "#3E322B", modeTips[i]);
                mb.Padding = new Thickness(8, 3, 8, 3);
                mb.Margin = new Thickness(i == 0 ? 0 : 4, 0, 0, 0);
                mb.Content = new TextBlock
                {
                    Text = modeLabels[i],
                    FontSize = 10,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = HexBrush("#C7B9AE")
                };
                mb.Click += (s, e) => SwitchTimerMode(mIdx);
                btnTimerModes[i] = mb;
                modeSwitcherPanel.Children.Add(mb);
            }
            Grid.SetColumn(modeSwitcherPanel, 1);
            topBar.Children.Add(modeSwitcherPanel);

            StackPanel rightUtilBtns = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Tag = "Interactive"
            };
            Button btnPomoSettings = CreateStyledIconButton("#26201D", "Transparent", L("Pomodoro süre ayarlarını aç/kapat", "Toggle Pomodoro duration settings"));
            btnPomoSettings.Padding = new Thickness(7, 3, 7, 3);
            btnPomoSettings.Margin = new Thickness(6, 0, 4, 0);
            btnPomoSettings.Content = new TextBlock { Text = L("⚙ Ayarlar", "⚙ Config"), Foreground = HexBrush("#C7B9AE"), FontSize = 10, FontWeight = FontWeights.SemiBold };
            btnPomoSettings.Click += (s, e) =>
            {
                timerPomoSettingsPopup.Visibility = timerPomoSettingsPopup.Visibility == Visibility.Visible
                    ? Visibility.Collapsed
                    : Visibility.Visible;
            };
            rightUtilBtns.Children.Add(btnPomoSettings);

            btnTimerLockDrag = CreateStyledIconButton("#26201D", "Transparent", L("Sabit / Taşınabilir Modu Değiştir", "Toggle Lock / Draggable Mode"));
            btnTimerLockDrag.Width = 24;
            btnTimerLockDrag.Height = 22;
            btnTimerLockDrag.Content = new TextBlock { Text = isDraggable ? "🔓" : "📌", FontSize = 10.5, Foreground = HexBrush("#C7B9AE") };
            btnTimerLockDrag.Click += (s, e) => ToggleDraggableMode();
            rightUtilBtns.Children.Add(btnTimerLockDrag);

            Grid.SetColumn(rightUtilBtns, 2);
            topBar.Children.Add(rightUtilBtns);

            Grid.SetRow(topBar, 0);
            rootGrid.Children.Add(topBar);

            Grid middleGrid = new Grid { Margin = new Thickness(0, 0, 0, 9) };
            middleGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.42, GridUnitType.Star), MinWidth = 196 });
            middleGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
            middleGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.58, GridUnitType.Star) });

            Border dialCard = new Border
            {
                CornerRadius = new CornerRadius(11),
                Background = HexBrush("#77221B18"),
                BorderBrush = HexBrush("#3E322B"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(10, 8, 10, 8)
            };

            Grid dialLayout = new Grid();
            dialLayout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            dialLayout.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            txtTimerDialPhase = new TextBlock
            {
                Text = L("Zamanlayıcı", "Stopwatch"),
                Foreground = HexBrush("#B8A99E"),
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 4)
            };
            Grid.SetRow(txtTimerDialPhase, 0);
            dialLayout.Children.Add(txtTimerDialPhase);

            Grid dialBody = new Grid();
            dialBody.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(116) });
            dialBody.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Grid dialFace = new Grid { Width = 114, Height = 114 };
            timerDialInnerCircle = new Border
            {
                Width = 108,
                Height = 108,
                CornerRadius = new CornerRadius(54),
                Background = HexBrush("#662E2520"),
                BorderBrush = HexBrush("#443730"),
                BorderThickness = new Thickness(1.2)
            };
            dialFace.Children.Add(timerDialInnerCircle);

            Canvas tickCanvas = new Canvas { Width = 114, Height = 114, IsHitTestVisible = false };
            double cx = 57.0, cy = 57.0;
            for (int t = 0; t < 24; t++)
            {
                double rad = ((t * 15.0) - 90.0) * (Math.PI / 180.0);
                double r1 = 39.0;
                double r2 = 47.0;
                Line tick = new Line
                {
                    X1 = cx + r1 * Math.Cos(rad),
                    Y1 = cy + r1 * Math.Sin(rad),
                    X2 = cx + r2 * Math.Cos(rad),
                    Y2 = cy + r2 * Math.Sin(rad),
                    Stroke = HexBrush("#50433B"),
                    StrokeThickness = 2.0,
                    StrokeStartLineCap = PenLineCap.Round,
                    StrokeEndLineCap = PenLineCap.Round
                };
                timerDialTicks[t] = tick;
                tickCanvas.Children.Add(tick);
            }
            dialFace.Children.Add(tickCanvas);

            StackPanel dialCenterText = new StackPanel
            {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            txtTimerDialCenter = new TextBlock
            {
                Text = "00:00",
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 18.5,
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            txtTimerDialSub = new TextBlock
            {
                Text = L("⏱ Hazır", "⏱ Ready"),
                Foreground = HexBrush("#A8988C"),
                FontSize = 9.5,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -1, 0, 0)
            };
            dialCenterText.Children.Add(txtTimerDialCenter);
            dialCenterText.Children.Add(txtTimerDialSub);
            dialFace.Children.Add(dialCenterText);

            Grid.SetColumn(dialFace, 0);
            dialBody.Children.Add(dialFace);

            StackPanel dialSideBtns = new StackPanel
            {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(8, 0, 0, 0),
                Tag = "Interactive"
            };

            btnPomoPlayPause = new Button
            {
                Width = 34,
                Height = 34,
                Cursor = Cursors.Hand,
                Background = HexBrush("#2EA043"),
                BorderBrush = HexBrush("#56D364"),
                BorderThickness = new Thickness(1.2),
                ToolTip = L("Başlat / Duraklat", "Start / Pause"),
                Tag = "Interactive"
            };
            ControlTemplate circleTpl = new ControlTemplate(typeof(Button));
            FrameworkElementFactory bdFactory = new FrameworkElementFactory(typeof(Border));
            bdFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(17));
            bdFactory.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
            bdFactory.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Button.BorderBrushProperty));
            bdFactory.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Button.BorderThicknessProperty));
            FrameworkElementFactory cpFactory = new FrameworkElementFactory(typeof(ContentPresenter));
            cpFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cpFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            bdFactory.AppendChild(cpFactory);
            circleTpl.VisualTree = bdFactory;
            btnPomoPlayPause.Template = circleTpl;

            txtPomoPlayPauseIcon = new TextBlock
            {
                Text = "▶",
                Foreground = Brushes.White,
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(1, 0, 0, 0)
            };
            btnPomoPlayPause.Content = txtPomoPlayPauseIcon;
            btnPomoPlayPause.Click += (s, e) =>
            {
                if (timerCurrentMode == 0)
                {
                    defaultTimerIsRunning = !defaultTimerIsRunning;
                    ShowToast(defaultTimerIsRunning ? L("▶ Zamanlayıcı başlatıldı", "▶ Timer started") : L("⏸ Zamanlayıcı duraklatıldı", "⏸ Timer paused"));
                }
                else if (timerCurrentMode == 1)
                {
                    gameTimerIsRunning = !gameTimerIsRunning;
                    ShowToast(gameTimerIsRunning ? L("▶ Eğlence sayacı başlatıldı", "▶ Gaming timer started") : L("⏸ Eğlence sayacı duraklatıldı", "⏸ Gaming timer paused"));
                }
                else
                {
                    if (pomoRemainingSeconds <= 0)
                        pomoRemainingSeconds = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;
                    pomoIsRunning = !pomoIsRunning;
                    ShowToast(pomoIsRunning ? L("▶ Pomodoro başlatıldı", "▶ Pomodoro started") : L("⏸ Pomodoro duraklatıldı", "⏸ Pomodoro paused"));
                }
                UpdateTimerWidgetUi();
            };
            dialSideBtns.Children.Add(btnPomoPlayPause);

            btnPomoReset = new Button
            {
                Width = 28,
                Height = 28,
                Margin = new Thickness(0, 8, 0, 0),
                Cursor = Cursors.Hand,
                Background = HexBrush("#2C2420"),
                BorderBrush = HexBrush("#463932"),
                BorderThickness = new Thickness(1),
                ToolTip = L("Süreyi sıfırla (Ders modunda Odak/Mola geçişi için 2 kez tıkla)", "Reset timer (Click twice in Study mode to switch Focus/Break)"),
                Tag = "Interactive",
                Template = circleTpl
            };
            btnPomoReset.Content = new TextBlock
            {
                Text = "↺",
                Foreground = HexBrush("#C7B9AE"),
                FontSize = 13,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, -1, 0, 0)
            };
            btnPomoReset.Click += (s, e) =>
            {
                if (timerCurrentMode == 0)
                {
                    defaultTimerIsRunning = false;
                    defaultTimerSeconds = 0;
                    ShowToast(L("↺ Zamanlayıcı sıfırlandı", "↺ Timer reset"));
                }
                else if (timerCurrentMode == 1)
                {
                    gameTimerIsRunning = false;
                    timerGameSessionSeconds = 0;
                    ShowToast(L("↺ Oyun oturum sayacı sıfırlandı (günlük toplam korundu)", "↺ Session counter reset (daily total preserved)"));
                }
                else
                {
                    int fullSec = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;
                    if (!pomoIsRunning && Math.Abs(pomoRemainingSeconds - fullSec) < 2)
                    {
                        pomoIsBreakPhase = !pomoIsBreakPhase;
                    }
                    pomoIsRunning = false;
                    pomoRemainingSeconds = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;
                    ShowToast(pomoIsBreakPhase
                        ? string.Format(L("☕ Mola süresine geçildi ({0} dk)", "☕ Switched to Break ({0} min)"), pomoBreakMinutes)
                        : string.Format(L("📚 Odak süresine geçildi ({0} dk)", "📚 Switched to Focus ({0} min)"), pomoFocusMinutes));
                }
                UpdateTimerWidgetUi();
            };
            dialSideBtns.Children.Add(btnPomoReset);

            Grid.SetColumn(dialSideBtns, 1);
            dialBody.Children.Add(dialSideBtns);

            Viewbox dialViewbox = new Viewbox
            {
                Stretch = Stretch.Uniform,
                MaxHeight = 190,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Child = dialBody
            };
            Grid.SetRow(dialViewbox, 1);
            dialLayout.Children.Add(dialViewbox);
            dialCard.Child = dialLayout;
            Grid.SetColumn(dialCard, 0);
            middleGrid.Children.Add(dialCard);

            Grid rightStatsGrid = new Grid();
            rightStatsGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            rightStatsGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            rightStatsGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            timerPomoSettingsPopup = new Border
            {
                Visibility = Visibility.Collapsed,
                CornerRadius = new CornerRadius(9),
                Background = HexBrush("#F2241D19"),
                BorderBrush = HexBrush(accentColorHex),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(9, 6, 9, 6),
                Margin = new Thickness(0),
                VerticalAlignment = VerticalAlignment.Top,
                Tag = "Interactive"
            };
            Panel.SetZIndex(timerPomoSettingsPopup, 10);
            StackPanel psStack = new StackPanel();
            Grid psRow = new Grid();
            psRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            psRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            string minUnit = L(" dk", " min");
            StackPanel fAdj = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            fAdj.Children.Add(new TextBlock { Text = L("Odak:", "Focus:"), Foreground = HexBrush("#C7B9AE"), FontSize = 10.5, Margin = new Thickness(0, 0, 5, 0), VerticalAlignment = VerticalAlignment.Center });
            Button bfMinus = CreateStyledIconButton("#221C18", "#4A3C34", L("Odak süresini azalt", "Decrease focus duration"));
            bfMinus.Padding = new Thickness(5, 1, 5, 1);
            bfMinus.Content = new TextBlock { Text = "−", Foreground = HexBrush("#FAF6F2"), FontSize = 10.5 };
            txtPomoFocusSettingVal = new TextBlock { Text = pomoFocusMinutes + minUnit, Foreground = HexBrush("#FAF6F2"), FontSize = 10.5, FontWeight = FontWeights.Bold, Margin = new Thickness(5, 0, 5, 0), VerticalAlignment = VerticalAlignment.Center };
            Button bfPlus = CreateStyledIconButton("#221C18", "#4A3C34", L("Odak süresini artır", "Increase focus duration"));
            bfPlus.Padding = new Thickness(5, 1, 5, 1);
            bfPlus.Content = new TextBlock { Text = "+", Foreground = HexBrush("#FAF6F2"), FontSize = 10.5 };
            bfMinus.Click += (s, e) => AdjustPomodoroSettings(-5, 0);
            bfPlus.Click += (s, e) => AdjustPomodoroSettings(5, 0);
            fAdj.Children.Add(bfMinus); fAdj.Children.Add(txtPomoFocusSettingVal); fAdj.Children.Add(bfPlus);
            Grid.SetColumn(fAdj, 0);
            psRow.Children.Add(fAdj);

            StackPanel bAdj = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Right };
            bAdj.Children.Add(new TextBlock { Text = L("Mola:", "Break:"), Foreground = HexBrush("#C7B9AE"), FontSize = 10.5, Margin = new Thickness(0, 0, 5, 0), VerticalAlignment = VerticalAlignment.Center });
            Button bbMinus = CreateStyledIconButton("#221C18", "#4A3C34", L("Mola süresini azalt", "Decrease break duration"));
            bbMinus.Padding = new Thickness(5, 1, 5, 1);
            bbMinus.Content = new TextBlock { Text = "−", Foreground = HexBrush("#FAF6F2"), FontSize = 10.5 };
            txtPomoBreakSettingVal = new TextBlock { Text = pomoBreakMinutes + minUnit, Foreground = HexBrush("#FAF6F2"), FontSize = 10.5, FontWeight = FontWeights.Bold, Margin = new Thickness(5, 0, 5, 0), VerticalAlignment = VerticalAlignment.Center };
            Button bbPlus = CreateStyledIconButton("#221C18", "#4A3C34", L("Mola süresini artır", "Increase break duration"));
            bbPlus.Padding = new Thickness(5, 1, 5, 1);
            bbPlus.Content = new TextBlock { Text = "+", Foreground = HexBrush("#FAF6F2"), FontSize = 10.5 };
            bbMinus.Click += (s, e) => AdjustPomodoroSettings(0, -1);
            bbPlus.Click += (s, e) => AdjustPomodoroSettings(0, 1);
            bAdj.Children.Add(bbMinus); bAdj.Children.Add(txtPomoBreakSettingVal); bAdj.Children.Add(bbPlus);
            Grid.SetColumn(bAdj, 1);
            psRow.Children.Add(bAdj);
            psStack.Children.Add(psRow);

            StackPanel presetsRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 0) };
            int[,] pPresets = { { 25, 5 }, { 45, 10 }, { 50, 10 }, { 60, 15 } };
            for (int pi = 0; pi < 4; pi++)
            {
                int pf = pPresets[pi, 0];
                int pb = pPresets[pi, 1];
                Button bp = CreateStyledIconButton("#26201D", "#3E322B", pf + L(" dk odak / ", "m focus / ") + pb + L(" dk mola", "m break"));
                bp.Padding = new Thickness(6, 2, 6, 2);
                bp.Margin = new Thickness(0, 0, 4, 0);
                bp.Content = new TextBlock { Text = pf + "/" + pb, Foreground = HexBrush("#D7CBC2"), FontSize = 9.5, FontWeight = FontWeights.SemiBold };
                bp.Click += (s, e) =>
                {
                    pomoFocusMinutes = pf;
                    pomoBreakMinutes = pb;
                    if (!pomoIsRunning) pomoRemainingSeconds = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;
                    txtPomoFocusSettingVal.Text = pomoFocusMinutes + L(" dk", " min");
                    txtPomoBreakSettingVal.Text = pomoBreakMinutes + L(" dk", " min");
                    SaveSettings();
                    UpdateTimerWidgetUi();
                };
                presetsRow.Children.Add(bp);
            }
            psStack.Children.Add(presetsRow);
            timerPomoSettingsPopup.Child = psStack;

            Border statStudyCard = CreateTimerStatCard("#2EA043", L("📚 Bugün Çalışılan", "📚 Studied Today"), out txtTodayStudyVal);
            Border statGameCard = CreateTimerStatCard("#A78BFA", L("🎮 Bugün Oyun Oynanan", "🎮 Played Today"), out txtTodayGameVal);
            Border statPcCard = CreateTimerStatCard(accentColorHex, L("🖥 Bilgisayar Açık Kalma", "🖥 PC Uptime Today"), out txtTodayPcVal, true);
            Grid.SetRow(statStudyCard, 0);
            Grid.SetRow(statGameCard, 1);
            Grid.SetRow(statPcCard, 2);
            rightStatsGrid.Children.Add(statStudyCard);
            rightStatsGrid.Children.Add(statGameCard);
            rightStatsGrid.Children.Add(statPcCard);

            Grid.SetColumn(rightStatsGrid, 2);
            middleGrid.Children.Add(rightStatsGrid);
            Grid.SetColumn(timerPomoSettingsPopup, 2);
            middleGrid.Children.Add(timerPomoSettingsPopup);

            Grid.SetRow(middleGrid, 1);
            rootGrid.Children.Add(middleGrid);

            Border heatmapBorder = new Border
            {
                CornerRadius = new CornerRadius(10),
                Background = HexBrush("#661E1815"),
                BorderBrush = HexBrush("#382E28"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(8, 6, 8, 6)
            };

            timerHeatmapHost = new Grid
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                ClipToBounds = true
            };
            timerHeatmapCanvas = new Canvas
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch
            };
            timerHeatmapHost.Children.Add(timerHeatmapCanvas);
            timerHeatmapHost.SizeChanged += (s, e) =>
            {
                int w = (int)Math.Round(timerHeatmapHost.ActualWidth);
                int h = (int)Math.Round(timerHeatmapHost.ActualHeight);
                if (Math.Abs(w - lastHeatmapLayoutWidth) >= 2 || Math.Abs(h - lastHeatmapLayoutHeight) >= 2)
                {
                    BuildTimerHeatmapGrid();
                }
            };

            heatmapBorder.Child = timerHeatmapHost;
            Grid.SetRow(heatmapBorder, 2);
            rootGrid.Children.Add(heatmapBorder);

            timerResizeGrip = new Border
            {
                Width = 12,
                Height = 12,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0, 0, -8, -4),
                Visibility = isDraggable ? Visibility.Visible : Visibility.Collapsed,
                Child = new TextBlock { Text = "◢", FontSize = 9, Foreground = HexBrush("#8C7A6B") }
            };
            Grid.SetRow(timerResizeGrip, 2);
            rootGrid.Children.Add(timerResizeGrip);

            timerOuterBorder.Child = rootGrid;
            timerWindow.Content = timerOuterBorder;
            UpdateDraggableButtonUi();
        }

        private Border CreateTimerStatCard(string pillHex, string label, out TextBlock valueTextBlock, bool isLast = false)
        {
            Border card = new Border
            {
                CornerRadius = new CornerRadius(9),
                Background = HexBrush("#7728211E"),
                BorderBrush = HexBrush("#3E322B"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(9, 7, 10, 7),
                Margin = new Thickness(0, 0, 0, isLast ? 0 : 6)
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Border bar = new Border
            {
                Width = 3.5,
                Height = 16,
                CornerRadius = new CornerRadius(2),
                Background = HexBrush(pillHex),
                Margin = new Thickness(0, 0, 8, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(bar, 0);
            g.Children.Add(bar);

            TextBlock lbl = new TextBlock
            {
                Text = label,
                Foreground = HexBrush("#D7CBC2"),
                FontSize = 11,
                FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(lbl, 1);
            g.Children.Add(lbl);

            valueTextBlock = new TextBlock
            {
                Text = L("0 dk", "0 min"),
                Foreground = HexBrush("#FAF6F2"),
                FontSize = 11.5,
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(8, 0, 0, 0)
            };
            Grid.SetColumn(valueTextBlock, 2);
            g.Children.Add(valueTextBlock);

            card.Child = g;
            return card;
        }

        private void OnHeatmapCellToolTipOpening(object sender, ToolTipEventArgs e)
        {
            Border cell = sender as Border;
            if (cell != null && cell.Tag is DateTime)
            {
                cell.ToolTip = FormatActivityTooltip((DateTime)cell.Tag);
            }
        }

        private void BuildTimerHeatmapGrid()
        {
            if (timerHeatmapCanvas == null) return;
            try
            {
                double availW = (timerHeatmapHost != null && timerHeatmapHost.ActualWidth > 40)
                    ? timerHeatmapHost.ActualWidth
                    : Math.Max(260.0, savedTimerWidth - 48.0);
                double availH = (timerHeatmapHost != null && timerHeatmapHost.ActualHeight > 25)
                    ? timerHeatmapHost.ActualHeight
                    : Math.Max(68.0, (savedTimerHeight - 54.0) * (0.92 / 2.42) - 14.0);

                lastHeatmapLayoutWidth = (int)Math.Round(availW);
                lastHeatmapLayoutHeight = (int)Math.Round(availH);
                todayHeatmapCell = null;

                string[] shortMonths = IsEn
                    ? new string[] { "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }
                    : new string[] { "", "Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara" };
                DateTime today = DateTime.Today;
                int todayDowOffset = ((int)today.DayOfWeek + 6) % 7;
                DateTime currentWeekMonday = today.AddDays(-todayDowOffset);

                const double headerH = 15.0;
                double gridH = Math.Max(35.0, availH - headerH);
                double rowPitch = gridH / 7.0;
                int weeksCount = Math.Max(14, Math.Min(78, (int)Math.Round(availW / rowPitch)));
                double colPitch = availW / weeksCount;
                double cellStep = Math.Min(colPitch, rowPitch);
                double gap = Math.Max(1.5, Math.Round(cellStep * 0.18));
                double squareSize = Math.Max(4.0, Math.Floor(cellStep - gap));
                double cornerRad = Math.Max(1.4, Math.Round(squareSize * 0.22, 1));
                CornerRadius cellCorner = new CornerRadius(cornerRad);
                Brush todayBorderBrush = HexBrush("#FAF6F2");
                Brush monthLabelBrush = HexBrush("#9E8E82");

                DateTime gridStartMonday = currentWeekMonday.AddDays(-(weeksCount - 1) * 7);
                double[] rowY = new double[7];
                for (int r = 0; r < 7; r++)
                {
                    rowY[r] = headerH + Math.Round(r * (gridH - squareSize) / 6.0);
                }

                int lastLabeledMonth = -1;
                double lastLabelX = -100.0;
                int usedMonthCount = 0;
                int usedCellCount = 0;

                for (int w = 0; w < weeksCount; w++)
                {
                    DateTime colMonday = gridStartMonday.AddDays(w * 7);
                    double x = (weeksCount > 1) ? Math.Round(w * (availW - squareSize) / (weeksCount - 1)) : 0;

                    int mToLabel = -1;
                    for (int d = 0; d < 7; d++)
                    {
                        DateTime dt = colMonday.AddDays(d);
                        if (dt > today) break;
                        if (dt.Day <= 7 && dt.Month != lastLabeledMonth)
                        {
                            mToLabel = dt.Month;
                            break;
                        }
                    }
                    if (w == 0 && mToLabel < 0) mToLabel = colMonday.Month;

                    if (mToLabel > 0 && (x - lastLabelX) >= 28.0 && x <= availW - 22.0)
                    {
                        lastLabeledMonth = mToLabel;
                        lastLabelX = x;

                        TextBlock mLbl;
                        if (usedMonthCount < heatmapMonthPool.Count)
                        {
                            mLbl = heatmapMonthPool[usedMonthCount];
                        }
                        else
                        {
                            mLbl = new TextBlock
                            {
                                FontSize = 9.0,
                                FontWeight = FontWeights.SemiBold
                            };
                            heatmapMonthPool.Add(mLbl);
                            timerHeatmapCanvas.Children.Add(mLbl);
                        }
                        usedMonthCount++;

                        mLbl.Text = shortMonths[mToLabel];
                        mLbl.Foreground = monthLabelBrush;
                        mLbl.Visibility = Visibility.Visible;
                        Canvas.SetLeft(mLbl, x);
                        Canvas.SetTop(mLbl, 0);
                    }

                    for (int r = 0; r < 7; r++)
                    {
                        DateTime cellDate = colMonday.AddDays(r).Date;
                        if (cellDate > today) continue;

                        bool isToday = (cellDate == today);

                        Border cell;
                        if (usedCellCount < heatmapCellPool.Count)
                        {
                            cell = heatmapCellPool[usedCellCount];
                        }
                        else
                        {
                            cell = new Border
                            {
                                Cursor = Cursors.Hand,
                                ToolTip = ""
                            };
                            cell.ToolTipOpening += OnHeatmapCellToolTipOpening;
                            heatmapCellPool.Add(cell);
                            timerHeatmapCanvas.Children.Add(cell);
                        }
                        usedCellCount++;

                        cell.Width = squareSize;
                        cell.Height = squareSize;
                        cell.CornerRadius = cellCorner;
                        cell.Background = GetHeatmapCellBrush(cellDate);
                        cell.BorderBrush = isToday ? todayBorderBrush : Brushes.Transparent;
                        cell.BorderThickness = new Thickness(isToday ? 1.0 : 0);
                        cell.Tag = cellDate;
                        cell.Visibility = Visibility.Visible;

                        Canvas.SetLeft(cell, x);
                        Canvas.SetTop(cell, rowY[r]);
                        if (isToday) todayHeatmapCell = cell;
                    }
                }

                for (int i = usedMonthCount; i < heatmapMonthPool.Count; i++)
                    heatmapMonthPool[i].Visibility = Visibility.Collapsed;
                for (int i = usedCellCount; i < heatmapCellPool.Count; i++)
                    heatmapCellPool[i].Visibility = Visibility.Collapsed;
            }
            catch { }
        }

        private Brush GetHeatmapCellBrush(DateTime date)
        {
            if (cachedHeatmapTierBrushes[0] == null ||
                !string.Equals(cachedHeatmapAccentHex, accentColorHex, StringComparison.OrdinalIgnoreCase))
            {
                Color baseDark = Color.FromRgb(34, 29, 26);
                Color accent = ParseColor(accentColorHex);
                Color[] tierColors = new Color[]
                {
                    baseDark,
                    BlendColors(baseDark, accent, 0.14, 255),
                    BlendColors(baseDark, accent, 0.34, 255),
                    BlendColors(baseDark, accent, 0.58, 255),
                    BlendColors(baseDark, accent, 0.85, 255),
                    BlendColors(accent, Colors.White, 0.20, 255)
                };
                for (int i = 0; i < 6; i++)
                {
                    SolidColorBrush sb = new SolidColorBrush(tierColors[i]);
                    sb.Freeze();
                    cachedHeatmapTierBrushes[i] = sb;
                }
                cachedHeatmapAccentHex = accentColorHex;
            }

            DailyActivityRecord rec;
            if (!activityByDate.TryGetValue(date.Date, out rec))
                return cachedHeatmapTierBrushes[0];

            int activeMins = (rec.StudySeconds + rec.GameSeconds) / 60;
            if (activeMins >= 240) return cachedHeatmapTierBrushes[5];
            if (activeMins >= 120) return cachedHeatmapTierBrushes[4];
            if (activeMins >= 45) return cachedHeatmapTierBrushes[3];
            if (activeMins >= 1 || rec.StudySeconds > 0 || rec.GameSeconds > 0) return cachedHeatmapTierBrushes[2];
            if (rec.PcSeconds >= 60) return cachedHeatmapTierBrushes[1];
            return cachedHeatmapTierBrushes[0];
        }

        private string FormatDurationLocalized(int totalSeconds)
        {
            if (totalSeconds <= 0) return L("0 dk", "0 min");
            if (totalSeconds < 60) return totalSeconds + L(" sn", " sec");
            int totalMin = totalSeconds / 60;
            int hours = totalMin / 60;
            int mins = totalMin % 60;
            if (hours == 0) return totalMin + L(" dk", " min");
            return IsEn
                ? string.Format("{0}h {1:00}m", hours, mins)
                : string.Format("{0}s {1:00}dk", hours, mins);
        }

        private string FormatActivityTooltip(DateTime date)
        {
            string[] months = IsEn
                ? new string[] { "", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }
                : new string[] { "", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık" };
            string[] days = IsEn
                ? new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" }
                : new string[] { "Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi" };
            DailyActivityRecord rec;
            activityByDate.TryGetValue(date.Date, out rec);
            int st = rec != null ? rec.StudySeconds : 0;
            int gm = rec != null ? rec.GameSeconds : 0;
            int pc = rec != null ? rec.PcSeconds : 0;

            return string.Format("{0} {1} {2} {3}\n{4}: {5}\n{6}: {7}\n{8}: {9}",
                date.Day, months[date.Month], date.Year, days[(int)date.DayOfWeek],
                L("📚 Ders Çalışılan", "📚 Studied"), FormatDurationLocalized(st),
                L("🎮 Oyun Oynanan", "🎮 Gaming"), FormatDurationLocalized(gm),
                L("🖥 Bilgisayar Açık", "🖥 PC Uptime"), FormatDurationLocalized(pc));
        }

        private void SwitchTimerMode(int newMode)
        {
            if (newMode < 0 || newMode > 2) newMode = 0;
            if (timerCurrentMode == newMode)
                return;

            if (newMode != 1 && activeGamePid == 0)
            {
                activeGameName = "";
            }

            defaultTimerIsRunning = false;
            gameTimerIsRunning = false;
            pomoIsRunning = false;
            timerCurrentMode = newMode;

            if (timerCurrentMode == 1)
            {
                ShowToast(L("🎮 Eğlence Modu (Başlatmak için ▶ tuşuna basın)", "🎮 Gaming Mode (Press ▶ to start)"));
            }
            else if (timerCurrentMode == 2)
            {
                if (pomoRemainingSeconds <= 0)
                    pomoRemainingSeconds = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;
                ShowToast(L("📚 Ders Modu (Başlatmak için ▶ tuşuna basın)", "📚 Study Mode (Press ▶ to start)"));
            }
            else
            {
                ShowToast(L("🖥 Default Mod (Zamanlayıcı hazır)", "🖥 Default Mode (Timer ready)"));
            }

            SaveTimerActivityData();
            UpdateTimerWidgetUi();
        }

        private bool IsProcessStillAlive(uint pid)
        {
            if (pid == 0) return false;
            IntPtr hProc = IntPtr.Zero;
            try
            {
                hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
                if (hProc == IntPtr.Zero)
                {
                    if (Marshal.GetLastWin32Error() == 5)
                    {
                        IntPtr fg = GetForegroundWindow();
                        if (fg != IntPtr.Zero)
                        {
                            uint fgPid;
                            GetWindowThreadProcessId(fg, out fgPid);
                            if (fgPid == pid) return true;
                        }
                    }
                    return false;
                }
                uint exitCode;
                return GetExitCodeProcess(hProc, out exitCode) && exitCode == STILL_ACTIVE;
            }
            catch
            {
                return false;
            }
            finally
            {
                if (hProc != IntPtr.Zero) CloseHandle(hProc);
            }
        }

        private string TryGetProcessImagePath(uint pid)
        {
            if (pid == 0) return null;
            IntPtr hProc = IntPtr.Zero;
            try
            {
                hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
                if (hProc == IntPtr.Zero) return null;
                procPathSb.Length = 0;
                int size = procPathSb.Capacity;
                if (QueryFullProcessImageName(hProc, 0, procPathSb, ref size) && size > 0)
                    return procPathSb.ToString();
                return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                if (hProc != IntPtr.Zero) CloseHandle(hProc);
            }
        }

        private static bool ExtractSubfolderAfterMarker(string fullPath, string lowerPath, string marker, out string folderName)
        {
            folderName = "";
            int idx = lowerPath.IndexOf(marker, StringComparison.Ordinal);
            if (idx < 0) return false;
            int start = idx + marker.Length;
            if (start >= fullPath.Length) return false;
            int slash = fullPath.IndexOf('\\', start);
            if (slash <= start) return false;
            folderName = fullPath.Substring(start, slash - start).Trim();
            return folderName.Length > 0;
        }

        private bool IsGameExecutable(string fullPath, IntPtr hwnd, out string friendlyName, out bool isJavaProcess)
        {
            friendlyName = "";
            isJavaProcess = false;
            if (string.IsNullOrEmpty(fullPath)) return false;

            string exeStem = System.IO.Path.GetFileNameWithoutExtension(fullPath);
            if (string.IsNullOrEmpty(exeStem)) return false;
            string lowerStem = exeStem.ToLowerInvariant();
            string lowerPath = fullPath.ToLowerInvariant();

            if (ExcludedNonGameExes.Contains(lowerStem)) return false;

            if ((lowerStem.Contains("launcher") && !lowerStem.Contains("minecraft")) ||
                lowerStem.EndsWith("helper") ||
                lowerStem.Contains("crashreporter") ||
                lowerStem.Contains("prereq") ||
                lowerStem.Contains("setup") ||
                lowerStem.Contains("unins") ||
                lowerStem.Contains("redist") ||
                lowerStem.Contains("updater") ||
                lowerStem.Contains("installer"))
            {
                return false;
            }

            if (lowerStem == "javaw" || lowerStem == "java")
            {
                isJavaProcess = true;
                windowTitleSb.Length = 0;
                int tLen = GetWindowText(hwnd, windowTitleSb, windowTitleSb.Capacity);
                if (tLen > 0)
                {
                    string wt = windowTitleSb.ToString().ToLowerInvariant();
                    if (wt.Contains("minecraft") || wt.Contains("lunar client") ||
                        wt.Contains("feather") || wt.Contains("badlion") ||
                        wt.Contains("modrinth") || wt.Contains("curseforge"))
                    {
                        friendlyName = "Minecraft";
                        return true;
                    }
                }
                return false;
            }

            string knownTitle;
            bool hasKnownTitle = KnownGameFriendlyNames.TryGetValue(lowerStem, out knownTitle);

            string folder;
            if (ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\steamapps\\common\\", out folder))
            {
                string lf = folder.ToLowerInvariant();
                if (lf.Contains("steamworks") || lf == "wallpaper_engine" || lf.Contains("steamvr") ||
                    lf.StartsWith("proton") || lf == "soundpad" || lf.Contains("controller"))
                    return false;
                friendlyName = hasKnownTitle ? knownTitle : folder;
                return true;
            }
            if (ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\epic games\\", out folder))
            {
                string lf = folder.ToLowerInvariant();
                if (lf == "launcher" || lf == "epic online services" || lf == "directxredist")
                    return false;
                friendlyName = hasKnownTitle ? knownTitle : folder;
                return true;
            }
            if (ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\riot games\\", out folder))
            {
                string lf = folder.ToLowerInvariant();
                if (lf == "riot client" || lf == "riot vanguard")
                    return false;
                friendlyName = hasKnownTitle ? knownTitle : folder;
                return true;
            }
            if (ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\xboxgames\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\gog galaxy\\games\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\gog games\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\ubisoft game launcher\\games\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\ea games\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\origin games\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\battle.net\\games\\", out folder))
            {
                if (folder.Equals("GamingServices", StringComparison.OrdinalIgnoreCase))
                    return false;
                friendlyName = hasKnownTitle ? knownTitle : folder;
                return true;
            }
            if (ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\games\\", out folder) ||
                ExtractSubfolderAfterMarker(fullPath, lowerPath, "\\oyunlar\\", out folder))
            {
                string lf = folder.ToLowerInvariant();
                if (lf == "launcher" || lf == "riot client")
                    return false;
                friendlyName = hasKnownTitle ? knownTitle : folder;
                return true;
            }

            if (hasKnownTitle)
            {
                friendlyName = knownTitle;
                return true;
            }

            return false;
        }

        private void CheckAutoGameDetection()
        {
            if (activeGamePid != 0)
            {
                if (!IsProcessStillAlive(activeGamePid))
                {
                    string closedGame = string.IsNullOrEmpty(activeGameName) ? L("Oyun", "Game") : activeGameName;
                    activeGamePid = 0;
                    activeGameName = "";
                    lastCheckedNonGamePid = 0;
                    lastCheckedWasJava = false;

                    timerCurrentMode = 0;
                    defaultTimerIsRunning = false;
                    gameTimerIsRunning = false;
                    pomoIsRunning = false;
                    SaveTimerActivityData();
                    UpdateTimerWidgetUi();

                    try
                    {
                        if (trayIcon != null)
                        {
                            trayIcon.ShowBalloonTip(4000, L("🖥 Oyun Kapatıldı", "🖥 Game Closed"),
                                string.Format(L("{0} kapatıldı. Otomatik olarak Default Moda geçildi.", "{0} closed. Switched back to Default Mode."), closedGame),
                                System.Windows.Forms.ToolTipIcon.Info);
                        }
                    }
                    catch { }
                    ShowToast(string.Format(L("🖥 Oyun kapatıldı ({0}) • Default Moda geçildi", "🖥 Game closed ({0}) • Default Mode active"), closedGame));
                }
                return;
            }

            IntPtr fg = GetForegroundWindow();
            if (fg == IntPtr.Zero || fg == cachedMainHwnd || fg == cachedCalHwnd || fg == cachedTimerHwnd)
                return;

            uint pid;
            GetWindowThreadProcessId(fg, out pid);
            if (pid == 0 || (pid == lastCheckedNonGamePid && !lastCheckedWasJava))
                return;

            string fullPath = TryGetProcessImagePath(pid);
            if (string.IsNullOrEmpty(fullPath))
                return;

            string detectedName;
            bool isJava;
            if (!IsGameExecutable(fullPath, fg, out detectedName, out isJava))
            {
                lastCheckedNonGamePid = pid;
                lastCheckedWasJava = isJava;
                return;
            }

            activeGamePid = pid;
            activeGameName = detectedName;
            lastCheckedNonGamePid = 0;
            lastCheckedWasJava = false;

            int prevMode = timerCurrentMode;
            timerCurrentMode = 1;
            defaultTimerIsRunning = false;
            pomoIsRunning = false;
            gameTimerIsRunning = true;
            if (prevMode != 1)
            {
                timerGameSessionSeconds = 0;
            }

            SaveTimerActivityData();
            UpdateTimerWidgetUi();

            if (prevMode == 2)
            {
                try { System.Media.SystemSounds.Hand.Play(); } catch { }
                try
                {
                    if (trayIcon != null)
                    {
                        trayIcon.ShowBalloonTip(6000, L("⚠️ Ders Modunda Oyun Algılandı!", "⚠️ Game Detected During Study Mode!"),
                            string.Format(L("{0} açıldığı için Pomodoro duraklatıldı ve otomatik olarak Eğlence Moduna geçildi!", "{0} launched! Pomodoro paused and switched to Gaming Mode."), detectedName),
                            System.Windows.Forms.ToolTipIcon.Warning);
                    }
                }
                catch { }
                ShowToast(string.Format(L("⚠️ Ders modundayken oyun açıldı ({0})! Eğlence moduna geçildi.", "⚠️ Game opened in Study Mode ({0})! Switched to Gaming Mode."), detectedName));
            }
            else if (prevMode == 0)
            {
                try
                {
                    if (trayIcon != null)
                    {
                        trayIcon.ShowBalloonTip(4000, L("🎮 Oyun Algılandı", "🎮 Game Detected"),
                            string.Format(L("{0} algılandı. Otomatik olarak Eğlence Moduna geçildi.", "{0} detected. Automatically switched to Gaming Mode."), detectedName),
                            System.Windows.Forms.ToolTipIcon.Info);
                    }
                }
                catch { }
                ShowToast(string.Format(L("🎮 Oyun algılandı ({0}) • Eğlence Modu aktif", "🎮 Game detected ({0}) • Gaming Mode active"), detectedName));
            }
        }

        private void AdjustPomodoroSettings(int deltaFocus, int deltaBreak)
        {
            pomoFocusMinutes = Math.Max(1, Math.Min(180, pomoFocusMinutes + deltaFocus));
            pomoBreakMinutes = Math.Max(1, Math.Min(60, pomoBreakMinutes + deltaBreak));
            if (!pomoIsRunning)
            {
                pomoRemainingSeconds = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;
            }
            string unit = L(" dk", " min");
            if (txtPomoFocusSettingVal != null) txtPomoFocusSettingVal.Text = pomoFocusMinutes + unit;
            if (txtPomoBreakSettingVal != null) txtPomoBreakSettingVal.Text = pomoBreakMinutes + unit;
            SaveSettings();
            UpdateTimerWidgetUi();
        }

        private void OnTimerWidgetSecondTick()
        {
            DateTime today = DateTime.Today;
            if (today != activeTrackingDate)
            {
                activeTrackingDate = today;
                SaveTimerActivityData();
                BuildTimerHeatmapGrid();
            }

            autoGameCheckTick++;
            if (autoGameCheckTick >= 2)
            {
                autoGameCheckTick = 0;
                CheckAutoGameDetection();
            }

            DailyActivityRecord todayRec = GetOrCreateActivityRecord(today);
            todayRec.PcSeconds++;

            if (timerCurrentMode == 0 && defaultTimerIsRunning)
            {
                defaultTimerSeconds++;
            }
            else if (timerCurrentMode == 1 && gameTimerIsRunning)
            {
                todayRec.GameSeconds++;
                timerGameSessionSeconds++;
            }
            else if (timerCurrentMode == 2 && pomoIsRunning)
            {
                if (!pomoIsBreakPhase)
                {
                    todayRec.StudySeconds++;
                }
                pomoRemainingSeconds--;

                if (pomoRemainingSeconds <= 0)
                {
                    bool finishedFocus = !pomoIsBreakPhase;
                    pomoIsBreakPhase = !pomoIsBreakPhase;
                    pomoRemainingSeconds = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60;

                    string title = finishedFocus
                        ? L("Odaklanma Oturumu Tamamlandı!", "Focus Session Complete!")
                        : L("Mola Süresi Bitti!", "Break Time Over!");
                    string msg = finishedFocus
                        ? string.Format(L("{0} dk odaklanma bitti! {1} dk mola başlıyor.", "{0}m focus finished! {1}m break ready."), pomoFocusMinutes, pomoBreakMinutes)
                        : string.Format(L("{0} dk mola bitti! Yeni {1} dk odaklanma oturumu hazır.", "{0}m break finished! {1}m focus ready."), pomoBreakMinutes, pomoFocusMinutes);

                    try { System.Media.SystemSounds.Exclamation.Play(); } catch { }
                    try { if (trayIcon != null) trayIcon.ShowBalloonTip(5000, title, msg, System.Windows.Forms.ToolTipIcon.Info); } catch { }
                    ShowToast("⏱ " + msg);
                }
            }

            timerSaveTickCounter++;
            if (timerSaveTickCounter >= 30)
            {
                timerSaveTickCounter = 0;
                SaveTimerActivityData();
            }

            bool anyTimerRunning = (timerCurrentMode == 0 && defaultTimerIsRunning) ||
                (timerCurrentMode == 1 && gameTimerIsRunning) ||
                (timerCurrentMode == 2 && pomoIsRunning);

            if (anyTimerRunning)
            {
                int totalActive = todayRec.StudySeconds + todayRec.GameSeconds;
                if (todayHeatmapCell != null && (totalActive <= 2 || (totalActive % 30) == 0))
                {
                    todayHeatmapCell.Background = GetHeatmapCellBrush(today);
                }

                if (showTimerWidget)
                {
                    UpdateTimerWidgetUi();
                }
            }
            else
            {
                if (showTimerWidget && txtTodayPcVal != null && (todayRec.PcSeconds < 60 || (todayRec.PcSeconds % 60) == 0))
                {
                    txtTodayPcVal.Text = FormatDurationLocalized(todayRec.PcSeconds);
                }
            }
        }

        private string FormatClockMMSS(int totalSeconds)
        {
            int sec = Math.Max(0, totalSeconds);
            if (sec >= 3600)
                return string.Format("{0}:{1:00}:{2:00}", sec / 3600, (sec % 3600) / 60, sec % 60);
            return string.Format("{0:00}:{1:00}", sec / 60, sec % 60);
        }

        private void UpdateTimerWidgetUi()
        {
            if (timerWindow == null) return;
            try
            {
                string[] modeHighlightHex = { accentColorHex, "#A78BFA", "#2EA043" };
                for (int i = 0; i < 3; i++)
                {
                    Button mb = btnTimerModes[i];
                    if (mb == null) continue;
                    bool isActive = (timerCurrentMode == i);
                    mb.Background = HexBrush(isActive ? "#38281E" : "#221C18");
                    mb.BorderBrush = HexBrush(isActive ? modeHighlightHex[i] : "#3A2F29");
                    TextBlock tb = mb.Content as TextBlock;
                    if (tb != null) tb.Foreground = HexBrush(isActive ? "#FAF6F2" : "#9E8E82");
                }

                string activeTickHex = "#56D364";
                string dialCenterStr = "00:00";
                int litTicks = 0;
                bool activeRunning = false;

                if (timerCurrentMode == 0)
                {
                    activeRunning = defaultTimerIsRunning;
                    txtTimerDialPhase.Text = L("Zamanlayıcı", "Stopwatch");
                    dialCenterStr = FormatClockMMSS(defaultTimerSeconds);
                    txtTimerDialSub.Text = defaultTimerIsRunning
                        ? L("⏱ Sayılıyor", "⏱ Running")
                        : (defaultTimerSeconds > 0 ? L("⏸ Duraklatıldı", "⏸ Paused") : L("⏱ Hazır", "⏱ Ready"));
                    activeTickHex = accentColorHex;
                    if (defaultTimerSeconds == 0 && !defaultTimerIsRunning)
                        litTicks = 0;
                    else
                    {
                        int secInMin = defaultTimerSeconds % 60;
                        litTicks = (secInMin == 0 && defaultTimerSeconds > 0) ? 24 : Math.Max(1, (secInMin * 24) / 60);
                    }
                }
                else if (timerCurrentMode == 1)
                {
                    activeRunning = gameTimerIsRunning;
                    txtTimerDialPhase.Text = L("Eğlence / Oyun Modu", "Gaming Mode");
                    dialCenterStr = FormatClockMMSS(timerGameSessionSeconds);
                    if (gameTimerIsRunning)
                    {
                        string subText = L("🎮 Kaydediliyor", "🎮 Recording");
                        if (!string.IsNullOrEmpty(activeGameName))
                        {
                            string dispName = activeGameName.Length > 18 ? activeGameName.Substring(0, 16) + ".." : activeGameName;
                            subText = "🎮 " + dispName;
                        }
                        txtTimerDialSub.Text = subText;
                    }
                    else
                    {
                        txtTimerDialSub.Text = timerGameSessionSeconds > 0 ? L("⏸ Duraklatıldı", "⏸ Paused") : L("🎮 Hazır", "🎮 Ready");
                    }
                    activeTickHex = "#A78BFA";
                    litTicks = (timerGameSessionSeconds == 0 && !gameTimerIsRunning) ? 0 : Math.Max(1, ((timerGameSessionSeconds % 3600) * 24) / 3600);
                }
                else
                {
                    activeRunning = pomoIsRunning;
                    txtTimerDialPhase.Text = pomoIsBreakPhase ? L("Mola Oturumu", "Break Session") : L("Odaklanma oturumu", "Focus Session");
                    int totalPhaseSec = Math.Max(1, (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) * 60);
                    if (pomoRemainingSeconds == totalPhaseSec && !pomoIsRunning)
                    {
                        dialCenterStr = (pomoIsBreakPhase ? pomoBreakMinutes : pomoFocusMinutes) + L(" dk", " min");
                        txtTimerDialSub.Text = pomoIsBreakPhase ? L("☕ Hazır", "☕ Ready") : L("📚 Hazır", "📚 Ready");
                    }
                    else
                    {
                        dialCenterStr = FormatClockMMSS(pomoRemainingSeconds);
                        txtTimerDialSub.Text = pomoIsRunning
                            ? (pomoIsBreakPhase ? L("☕ Dinlen", "☕ Break") : L("📚 Çalışılıyor", "📚 Focusing"))
                            : L("⏸ Duraklatıldı", "⏸ Paused");
                    }

                    activeTickHex = pomoIsBreakPhase ? accentColorHex : "#56D364";
                    double frac = Math.Max(0.0, Math.Min(1.0, (double)pomoRemainingSeconds / totalPhaseSec));
                    litTicks = (int)Math.Ceiling(frac * 24.0);
                }

                txtTimerDialCenter.Text = dialCenterStr;
                txtTimerDialCenter.FontSize = dialCenterStr.Length >= 7 ? 15.0 : 18.5;

                if (litTicks != lastRenderedLitTicks || !string.Equals(activeTickHex, lastRenderedTickHex, StringComparison.Ordinal))
                {
                    Brush litBrush = HexBrush(activeTickHex);
                    Brush dimBrush = HexBrush("#443730");
                    for (int t = 0; t < 24; t++)
                    {
                        if (timerDialTicks[t] != null)
                            timerDialTicks[t].Stroke = (t < litTicks) ? litBrush : dimBrush;
                    }
                    lastRenderedLitTicks = litTicks;
                    lastRenderedTickHex = activeTickHex;
                }
                if (timerDialInnerCircle != null)
                {
                    timerDialInnerCircle.BorderBrush = HexBrush(activeRunning ? activeTickHex : "#443730");
                }

                if (txtPomoPlayPauseIcon != null && btnPomoPlayPause != null)
                {
                    txtPomoPlayPauseIcon.Text = activeRunning ? "⏸" : "▶";
                    txtPomoPlayPauseIcon.Margin = new Thickness(activeRunning ? 0 : 1.5, 0, 0, 0);

                    string playBtnKey = timerCurrentMode + "|" + (activeRunning ? "1" : "0") + "|" + accentColorHex + "|" + appLanguage;
                    if (!string.Equals(playBtnKey, lastPlayBtnBrushKey, StringComparison.Ordinal))
                    {
                        Color modeBase = timerCurrentMode == 0
                            ? ParseColor(accentColorHex)
                            : (timerCurrentMode == 1 ? Color.FromRgb(139, 92, 246) : Color.FromRgb(46, 160, 67));
                        Color btnBgCol = activeRunning
                            ? modeBase
                            : BlendColors(Color.FromRgb(26, 22, 19), modeBase, 0.72, 255);
                        Color btnBdCol = BlendColors(modeBase, Colors.White, activeRunning ? 0.38 : 0.25, 255);

                        SolidColorBrush bgBr = new SolidColorBrush(btnBgCol);
                        bgBr.Freeze();
                        SolidColorBrush bdBr = new SolidColorBrush(btnBdCol);
                        bdBr.Freeze();
                        cachedPlayBtnBg = bgBr;
                        cachedPlayBtnBd = bdBr;
                        lastPlayBtnBrushKey = playBtnKey;

                        btnPomoPlayPause.ToolTip = timerCurrentMode == 0
                            ? L("Zamanlayıcıyı Başlat / Duraklat", "Start / Pause Timer")
                            : (timerCurrentMode == 1 ? L("Eğlence Sayacını Başlat / Duraklat", "Start / Pause Gaming Timer") : L("Pomodoro'yu Başlat / Duraklat", "Start / Pause Pomodoro"));
                    }
                    btnPomoPlayPause.Background = cachedPlayBtnBg;
                    btnPomoPlayPause.BorderBrush = cachedPlayBtnBd;
                }

                DailyActivityRecord rec = GetOrCreateActivityRecord(DateTime.Today);
                if (txtTodayStudyVal != null) txtTodayStudyVal.Text = FormatDurationLocalized(rec.StudySeconds);
                if (txtTodayGameVal != null) txtTodayGameVal.Text = FormatDurationLocalized(rec.GameSeconds);
                if (txtTodayPcVal != null) txtTodayPcVal.Text = FormatDurationLocalized(rec.PcSeconds);
            }
            catch { }
        }

        private void ApplyTimerWidgetTheme()
        {
            if (timerOuterBorder == null) return;
            try
            {
                Color accent = ParseColor(accentColorHex);
                byte mainAlpha = (byte)Math.Round((bgOpacityPercent / 100.0) * 255.0);
                Color darkTop = BlendColors(Color.FromRgb(22, 19, 17), accent, 0.08, mainAlpha);
                Color darkBottom = BlendColors(Color.FromRgb(28, 24, 21), accent, 0.12, mainAlpha);
                Color outerBorderCol = BlendColors(Color.FromRgb(56, 48, 42), accent, 0.35, 220);

                LinearGradientBrush grad = new LinearGradientBrush(darkTop, darkBottom, new Point(0, 0), new Point(0, 1));
                grad.Freeze();
                timerOuterBorder.Background = grad;

                SolidColorBrush ob = new SolidColorBrush(outerBorderCol);
                ob.Freeze();
                timerOuterBorder.BorderBrush = ob;

                if (timerPomoSettingsPopup != null)
                    timerPomoSettingsPopup.BorderBrush = HexBrush(accentColorHex);

                if (timerHeatmapCanvas != null && (heatmapCellPool.Count == 0 ||
                    !string.Equals(cachedHeatmapAccentHex, accentColorHex, StringComparison.OrdinalIgnoreCase)))
                {
                    BuildTimerHeatmapGrid();
                }
                UpdateTimerWidgetUi();
            }
            catch { }
        }
    }
}
